function get_hist(data, title_name, file_name, sample_idx, sample_ex)

% get_hist(data, title_name, file_name, sample_idx, sample_ex)
%
% bar plot of data vector
% 
% IN:
% - data: create one vertical bar per element
% - title_name: (string) name of plot
% - file_name: (string) name of generated PDF file
% - sample_idx: vector of original sample indices
% - sample_ex: vector of sample indices which are excluded
%
% OUT:
% - PDF file with bar plot of data matrix


%%  figure
figure('visible','off');

% plot values
bar(data);


%% plot settings

% title
title(title_name)

% axes
axis tight

% xticks
% ensure that for all bars have xticks set
% matlab could leave out some ticks of bar plots e.g. sets an xtick for every
% other bar
% if more than 48 samples: use xticks set by matlab

if size(data,1) <= 48
    set(gca,'XTick',1:1:size(data,1))    
end

% change lables if samples excluded to keep original sample index
sample_ex = unique(sample_ex);

if all(sample_ex > 0)
    
    if size(data,1) <= 48
        set(gca,'XTickLabel',sample_idx)        
    else
        xtick_ori = get(gca, 'XTick'); 
        
        % find all positions where the sequence is interrupted due to
        % exclusion
        pos = zeros(1, length(sample_ex));
        label = zeros(1, length(sample_ex));     

        for i=1:length(sample_ex)          
            pos(i) = sample_ex(i) - i + 1;
            label(i) = sample_ex(i) + 1;
        end 
        % take last position if several positions (if adjacent exclusions occur)
        [pos_u, m, ~] = unique(pos);    
        label = label(m); 
        
        % merge potential new labels and adjusted labels at given xticks
        label = unique([label, sample_idx(xtick_ori)]);
        xtick = unique([pos_u, xtick_ori]);
        
        set(gca,'XTick', xtick)
        set(gca,'XTickLabel',label)        
    end
end

% axes labels
xlabel('Sample index')
% ylabel('Frequency')

% grid
set(gca,'YGrid','on')


%% save figure as PDF file

set(gcf, 'PaperType','A4','PaperOrientation','landscape', 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');

set(gcf, 'PaperPosition', [-3.5 -1.2 36.2 23.2]);

saveas(gcf,file_name)

close all


end