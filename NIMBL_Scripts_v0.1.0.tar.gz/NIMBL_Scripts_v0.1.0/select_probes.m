function select = select_probes(probe_annot, header, grouping, sample_ex, group_names, sample_names, pval_all, beta_all, pval_cut, pval_qc, miss_beta_qc, chr_sel, cpg_reg, cpg_user, fid_rep)

% select = select_probes(probe_annot, header, grouping, sample_ex, group_names, sample_names, pval_all, beta_all, pval_cut, pval_qc, miss_beta_qc, chr_sel, cpg_reg, cpg_user)
% 
% Select CpG sites (probes) based on quality control and user's choice
% 
% IN:
% - probe_annot: cell array of annotation data
% - header: header (column names) of annotation data
% - grouping: (integer) column vector defining two groups of samples
% - sample_ex: indices of samples to be removed
% - group_names: cell array of names of two groups
% - sample_names: extracted sample names
% - pval_all: matrix of detection pvalues of all samples
% - beta_all: matrix of beta values of all samples
% - pval_cut: cut-off for low quality probe
% - pval_qc: cut-off for percent of low quality samples per CpG site
% - miss_beta_qc: column vector with allowed fraction of samples with missing
%   beta value in each group
% - chr_sel: (integer) select chromosomes
% - cpg_reg: (integer) select CpG region (island, shore, shelf,...)
% - cpg_user: (inetger) select user annotation
% - fid_rep: file identifier for nimbl report
%
% OUT:
% - binary selection matrix, columns:
%   1: chromosome selection
%   2: pval QC (each CpG site tested for low quality measurements)
%   3: missing beta values QC
%   4: CpG region
%   5: user annotation
% - TAB-delimited text file with summary about selectd CpG sites and sample
%   names in each group



%% selection criteria

% number of selection criteria
n_s = 5;

% which selection crieria - used for printing later
sel = {'QC p-value', 'QC missing beta value', 'Select chromosome', 'Select CpG region', 'Select user annotation'};


%% regular expressions for probe annotation columns

% chr
c_chr = '^chr$';

% cpg region
c_regio = 'cpg.?region';

% additional annotation
c_user = 'user.?annotation';


%% binary filter matrix to select probes

% entry of 1: keep this site according to selected criterium
% default: all probes chosen (value '1')


% pval-based QC based only on samples of current comparison
% TODO: however this could be user defined option:
% - choose samples that are used for the current comparison of g1 vs g2
% - or choose all samples (whole pval matrix of samples that are not excluded)
pval_all = pval_all(:,grouping>0);


% number of probes/array sites
n = size(pval_all,1);

select = true(n,5);

%% probes with high pvalues

a = pval_all > pval_cut;
%%% select(:,1) = not(any(a,2));

% number of high pvalues per CpG site
hp = sum(a,2) * 100 / size(beta_all,2);

%%% select(:,1) = ~(hp > pval_qc);
select(:,1) = hp <= pval_qc;

% fprintf(1, '\n# Quality control of CpG sites:');
% fprintf(1, '\n- number of CpG sites with P-value > %3.2f in >= 1 sample: %u', pval_cut, sum(sum(a,2) > 0));
% fprintf(1, '\n- number of CpG sites with P-value > %3.2f in 1 sample: %u', pval_cut, sum(sum(a,2) == 1));


%% probes with missing beta values

% keep probes if missing beta values are in ignored samples
%%% a = isnan(beta_all);
% a = isnan(beta_all(:,grouping > 0));
%%% select(:,2) = not(any(a,2));

% consider user specified cut-off
s1 = sum(grouping == 1);
s2 = sum(grouping == 2);

mb1 = sum(isnan(beta_all(:, grouping == 1)), 2) / s1;
mb2 = sum(isnan(beta_all(:, grouping == 2)), 2) / s2;

% in each group not more missing beta values than max number allowed
select(:,2) = (mb1 <= miss_beta_qc(1)) & (mb2 <= miss_beta_qc(2));

% fprintf(1, '\n- number of CpG sites with missing beta value in >= 1 sample: %u', sum(sum(a,2) >= 1));
% fprintf(1, '\n- number of CpG sites with missing beta value in 1 sample: %u\n', sum(sum(a,2) == 1));


%% select chromosomes

% column idx with chromosome information
chr_idx = not(cellfun(@isempty, regexpi(header,c_chr)));

if sum(chr_idx) ~= 1
    fprintf(1, '\nfollowing pattern not found or not unique within probe annotation file: %s\n', c_chr);
    error('Selection of chromsome failed')
end

chr_all = probe_annot(:,chr_idx);

% if all no selection based on chromosome, sum == 4
if sum(chr_sel) < 4

    % create selection matrix with 4 columns
    chr_sel_mat = false(length(chr_all), 4);

    % autosomes
    if chr_sel(1)
        chr_sel_mat(:,1) = not(cellfun(@isempty, regexpi(chr_all,'[0-9]')));
    end

    % X
    if chr_sel(2)
        chr_sel_mat(:,2) = not(cellfun(@isempty, regexpi(chr_all,'x')));
    end

    % Y
    if chr_sel(3)
        chr_sel_mat(:,3) = not(cellfun(@isempty, regexpi(chr_all,'y')));    
    end 

    % unspecified
    if chr_sel(4)
        chr_sel_mat(:,4) = cellfun(@isempty, chr_all);
    end
    
    select(:,3) = any(chr_sel_mat,2);

end



%% filter CpG region

if cpg_reg ~= 0
        
    % column idx with CpG region information
    cpg_idx = not(cellfun(@isempty, regexpi(header,c_regio)));
    
    if sum(cpg_idx) ~= 1
        fprintf(1, '\nfollowing pattern not found or not unique within probe annotation file: %s\n', c_regio);
        error('see above')
    end    

    cpg = probe_annot(:,cpg_idx);

    d = false(n,1);
    % test for each CpG region
    for i=1:length(cpg_reg) 
        d = d | not(cellfun(@isempty, regexpi(cpg,num2str(cpg_reg(i)))));
    end

    select(:,4) = d;
end



%% filter user annotation

if cpg_user ~= 0
    
    % column idx with user defined information
    cpg_idx = not(cellfun(@isempty, regexpi(header,c_user)));
    
    if sum(cpg_idx) ~= 1
        fprintf(1, '\nfollowing pattern not found or not unique within probe annotation file: %s\n', c_user);
        error('see above')
    end    

    cpg = probe_annot(:,cpg_idx);

    d = false(n,1);    
    for i=1:length(cpg_user) 
        d = d | not(cellfun(@isempty, regexpi(cpg,num2str(cpg_user(i)))));
    end

    select(:,5) = d;
end


 
%% summary of selected sites

% compute number of sites selected and excluded
stats = zeros(n_s, 4);

stats(:,1) = sum(select);
stats(:,2) = stats(:,1)*100/n;
stats(:,3) = n - stats(:,1);
stats(:,4) = stats(:,3)*100/n;

fprintf(fid_rep, '\n# Selection of array sites\n');
d_header = 'Selection criterium\tNumber of sites selected\tPercent of total sites\tNumber of sites excluded\tPercent of total sites\n';
fprintf(fid_rep, d_header);

d_num = '%s\t%u\t%3.2f\t%u\t%3.2f\n';

for i=1:n_s
    fprintf(fid_rep, d_num, sel{i}, stats(i,:)); 
end

% total number of selected sites
sel_total = sum(all(select,2));
fprintf(fid_rep, d_num, 'Total', sel_total, sel_total*100/n, n - sel_total, (n - sel_total)*100/n);


%% summary of chosen samples in each group

% original sample index/number
ori_idx = 1:size(beta_all,2)+length(sample_ex);

if (any(sample_ex))
    ori_idx(sample_ex) = [];        
end

idx1 = grouping == 1;
idx2 = grouping == 2;

n1 = sum(idx1);
n2 = sum(idx2);

% groups can have different lengths
group_members = cell(max(n1, n2), 4);

% group1
group_members(1:n1,1) = sample_names(idx1);
group_members(1:n1,2) = num2cell(ori_idx(idx1));
% group2
group_members(1:n2,3) = sample_names(idx2);
group_members(1:n2,4) = num2cell(ori_idx(idx2));


fprintf(fid_rep, '\n# Groups compared\n');
fprintf(fid_rep, 'Running index\tSamples in group1: ''%s'' (%u)\tOriginal sample index\tSamples in group2: ''%s'' (%u)\tOriginal sample index\n',group_names{1}, n1, group_names{2}, n2);

for i=1:size(group_members,1)
    fprintf(fid_rep, '%u\t%s\t%u\t%s\t%u\n', i, group_members{i,:});
end


end

