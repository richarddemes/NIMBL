function [gene_symbols, gene_symbols_expanded, chr_info, map_info] = preprocess_array_annotation(input_script)

% function [gene_symbols, gene_symbols_expanded, chr_info, map_info] = preprocess_array_annotation(input_script)
% 
% find all array sites with gene annotation and collect all [ID - gene -
% gene region] combinations
% gene regions are given within the 450k manifest: TSS1500, TSS200,...

% saves 3 variables that can be loaded within other scripts that deal with
% gene information:
% - ID_info: array Target IDs for which gene annotation is provided (strings)
% - cg_info: matrix, each row corresponds to the array ID given in
%            ID_info, stores all gene - gene region combinations 
% - gene_symbols: list of all gene symbols, position in list (row)
%                 corresponds to the index in cg_info
% 
% TODO:
% - support 27k annotation file


%% include user-defined input

eval(input_script);


if platform == 1
    error('This script currently only works for 450k annotation data.');
end

% 450k values

% 4.8
% column index of gene symbols in annotation file
% 27k default = 1
% 450k default = 22
col_mult = 22;

% 4.9
% column index of 'UCSC RefGene Group' (specifies gene region: TSS1500,...)
% only applys to 450k
col_gene_reg = 24;

% column index of chromosome ('CHR')
col_chr = 12;

% column index of position of array site in hg19 ('MAPINFO')
col_mapinfo = 13;


%% read annotation

% [probe_annot, header, cgID_col, type_col] = read_annotation(annot_file, input_del, platform);
[probe_annot, ~, cgID_col, ~] = read_annotation(annot_file, input_del, platform);


%% get all gene symbols

g = probe_annot(:, col_mult);    

% 450k gene symbols are separated by ';'
g_u = regexp(g, ';', 'split');

% keep length of each set (vector of gene symbols)
g_length = cellfun(@length, g_u);

% one vector of strings
g_all = (horzcat(g_u{:}))';

% keep length of this vector: upper limit of table with gene information of
% every array site
cg_limit = length(g_all);

% number of array sites with no gene symbol
no_gene = sum(strcmp('', g_all));

% only uniqe gene symbols
% keep index of every gene 
[gene_symbols,~,g_idx] = unique(g_all);

fprintf(1, '\nNumber of array sites found: %u\n', size(probe_annot,1));

% first item in gene_symbols should be the empty string (unless every site
% is annotated in input file)
g_nbr = length(gene_symbols);
if strcmp('', gene_symbols{1})
    g_nbr = g_nbr - 1;
end
fprintf(1, 'Number of gene symbols found: %u\n', g_nbr);
fprintf(1, 'Number of array sites with no gene annotation (intergenic sites): %u\n', no_gene);


%% information about gene regions

greg = probe_annot(:, col_gene_reg);

% translate every gene region into an index, alphabetically sorted
% 1: '' (no gene region)
% 2: '1stExon'
% 3: '3''UTR'
% 4: '5''UTR'
% 5: 'Body'
% 6: 'TSS1500'
% 7: 'TSS200'

% 450k gene regions are separated by ';'
greg_u = regexp(greg, ';', 'split');

% keep length of each set (vector of gene regions)
greg_length = cellfun(@length, greg_u);

% this vector should have the same length as the vector for gene symbols
if ~isequal(g_length, greg_length)
    fprintf(1, 'Each gene symbol (given in column: %u) should have a corresponding gene region (given in column: %u) in the annotation data\n', col_mult, col_gene_reg);
    error('Check annotation file and or column assignment for gene and gene region annotation');
end

% one vector of strings
greg_all = (horzcat(greg_u{:}))';


% [greg_u,~,greg_idx] = unique(greg_u);
% [greg_u,~,greg_idx] = unique(greg_all);
[~,~,greg_idx] = unique(greg_all);



%% collect gene information from every array site

fprintf(1, '\n- Collecting gene information from array sites ...\n');

%  every array site has either:
%  - no gene annotation (intergenic site)
%  - gene annotation 
%  if gene annotation is given:
%  - one or several gene names are given, which correspond to different or
%  the same transcripts and also gene regions (TSS1500,...)

% store for each array site all different combinations of gene and gene
% region annotations
% 3 columns:
% - 1: gene index
% - 2: gene region index
% - 3: number of entries of this array site in this table
cg_info = zeros(cg_limit,3);

% store positions that are intergenic
interg = false(size(probe_annot,1), 1);

% position in total vector of gene information
p1 = 1;

% position in cg_info table
p2 = 1;

for i=1:size(probe_annot,1)
    
    if g_length(i) == 1 
        % if ~strcmp('', g_all{p1}) % only one gene symbol
        if ~(g_idx(p1)==1)            
            cg_info(p2,:) = [g_idx(p1), greg_idx(p1), 1];
            
            p2 = p2 + 1; 
            
        else % no gene symbol, not annotated, assume intergenic            
            interg(i) = true;                        
        end  
        
    else % more than one gene symbol, but gene symbol can be the same and there can be several same combinations
        
        % map gene symbol to gene region and take unique combinations
        g_test = [g_idx(p1:p1+g_length(i)-1),greg_idx(p1:p1+g_length(i)-1)];
        
        g_test_u = unique(g_test, 'rows');
        
        n = size(g_test_u,1);
        
        % cg_info(p2:p2+n-1,:) = [g_test_u,repmat(n,n,1)];
        % loop is faster than repmat
        for j=1:n
            cg_info(p2+j-1,:) = [g_test_u(j,:),n];            
        end
        
        p2 = p2 + n;     
        
    end
        
    % start of new set of gene information
    p1 = p1 + g_length(i);
    
end

% delete the empty rows of the table
cg_info(p2:end,:) = [];


%% generate corresponding ID list of array sites and extract location and chr 

ID_info = cell(size(cg_info,1),1);

map_info = cell(size(cg_info,1),1);

chr_info = cell(size(cg_info,1),1);

% position in cg_info table
p=1;


for i=1:size(probe_annot,1)    
    
    if ~interg(i)
        
        for j=1:cg_info(p,3)
            ID_info(p+j-1) = probe_annot(i, cgID_col);
            chr_info(p+j-1) = probe_annot(i, col_chr);            
            map_info(p+j-1) = probe_annot(i, col_mapinfo);
        end
        p = p + cg_info(p,3);
    end
end

% quickly convert cell array to numbers
% str2double is very slow
% map_info = sscanf(sprintf('%s*', map_info{:}), '%d*');

% replace X and Y in chr table with numbers 23 and 24
chr_info = regexprep(chr_info, 'x', '23', 'ignorecase');
chr_info = regexprep(chr_info, 'y', '24', 'ignorecase');


%% write text file with results

%  columns:
%  textdata
%  - 1: array identifier (cgID in most cases)
%  - 2: gene symbol found in array annot file (include empty name as '' at start)
%  numeric data:
%  - 3: index of gene symbol
%  - 4: gene region (1..7)
%  - 5: nmber of entries for this array site within this table (1..)


if platform == 1
    % TODO
elseif platform == 2
    file_out = '450k_gene_annot.txt';
end

fprintf(1, '- Writing results to file: %s ...\n', file_out);
fid = fopen(file_out , 'w');

% unique list of gene symbols is shorter, copy to a list of length of the
% other tables
gene_symbols_expanded = cell(length(ID_info), 1);
gene_symbols_expanded(1:length(gene_symbols)) = gene_symbols;
gene_symbols_expanded{1} = ''''''; % generate "''" in output file


for i=1:length(ID_info)
    fprintf(fid, '%s\t%s\t%u\t%u\t%u\t%s\t%s\n', ID_info{i}, gene_symbols_expanded{i}, cg_info(i,:), chr_info{i}, map_info{i});
end

fclose(fid);




end