function get_beta_box(data, title_name, file_name, labels, grouping, boxplot_option)

% get_beta_box(data, title_name, file_name, labels, grouping)
%
% generate boxplot of each column of data that is selected by grouping
%
% TODO: support more than two sample groups (g1, g2, g3, g4,...)


%figure
figure('visible','off');

%% create all box plots at once

% g1: red color (r)
% g2: blue color (b)
my_color_order = 'rb';

% grouping contains only 1s and 2s
n = length(grouping);

% cell array of strings needed for color of groups
group_plot = cell(1, n);

% consider grouping only for the color, but original order of samples
if boxplot_option == 1     
    
    group_plot(grouping==1) = {'1'};
    group_plot(grouping==2) = {'2'};
            
    % check if first sample is '2', then start with color blue
    if grouping(1) == 2
        my_color_order = 'br';
    end

% g1 samples left, g2 samples right
else % assume boxplot_option == 2
    
    labels = labels([find(grouping == 1), find(grouping == 2)]);    
    data = data(:, [find(grouping == 1), find(grouping == 2)]);
    
    group_plot(1:sum(grouping==1)) = {'1'};
    group_plot((sum(grouping==1)+1):end) = {'2'};
        
end

boxplot(data, 'notch', 'on', 'colorgroup', group_plot, 'colors', my_color_order);


%% plot settings

set(gca,'YGrid','on')

% highlight median
set(findobj(gcf,'Tag','Median'),'Color',[0 0 0], 'LineWidth',1.5);

% xtick labels on x-axis (sample idx)
if n <= 32
    xticks = 0:n;
elseif n <= 50
    xticks = 0:2:n;
elseif n <= 100
    xticks = 0:5:n;
elseif n <= 200  
    xticks = 0:10:n;
else
    xticks = 0:20:n;
end

% do not use xtick at position 0
set(gca,'XTick', xticks(2:end))

% use xtick labels according to the index of samples in g1 vs g2
set(gca,'XTickLabel', labels(xticks(2:end)))

% title
title(title_name)

% axes labels
xlabel('Sample Index')
ylabel('Beta Value')


%% save figure in pdf file

set(gcf, 'PaperType','A4','PaperOrientation','landscape');
set(gcf, 'PaperUnits', 'centimeters');

% set(gcf, 'PaperPosition', [-3.5 -1 36.5 21]);
% set(gcf, 'PaperPosition', [-3.5 0 36.5 21]);
set(gcf, 'PaperPosition', [-3.5 -1.2 36.2 23.2]);

saveas(gcf,file_name)

close all

end
