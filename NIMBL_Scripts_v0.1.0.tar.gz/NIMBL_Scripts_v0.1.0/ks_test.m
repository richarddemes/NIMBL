function ks_test(betas, sample_idx, platform, fid_rep, prefix)

% ks_test(betas, sample_idx, platform, fid_rep, prefix)
% 
% Kolmogorov-Smirnov test to detect aberrant beta-value distribution
%
% IN:
% - betas: matrix of beta values
% - sample_idx: vector of integers representing position of sample in input
% - platform: integer (1 or 2) specifying 27k or 450k array
% - fid_rep: file identifier for nimbl qc report
% - prefix: prefix for all output files
%
% OUT:
% - PDF with CDF plot of all samples
% - PDF with CDF plot of all samples based on a reduced subset
% - PDF with CDF plot of all samples highlighting samples that were
%   detected as aberrant (if any)
% - PDF with beta value distribution of of all samples highlighting samples
%   that were detected as aberrant (if any)


%% variables 

% significance level
alpha = 1E-5;

% heuristic values
% fraction of original dataset - generate reduced dataset
% the fraction could be dependent on the number of actual input sites

if platform == 1 % 27k array    
    
    frac = 1/100; % i.e. sample 1 percent of the data 
    
elseif platform == 2 % 450k array        
    
    frac = 1/1000; % i.e. sample 0.1 percent of the data 
    
    % safety check if input set is small
    % then sample 1 percent of the data
    % - but the KS test makes not much sense for a heavily reduced dataset
    if size(betas,1) < 50000
        frac = 1/100;
    end
end

% number of samples
nbr = size(betas,2);


%% CDF plots of all samples

% use sample idx for legend
get_beta_cdf(betas, [prefix, '_beta_CDF.pdf'], arrayfun(@num2str, sample_idx, 'UniformOutput', 0), 0);


%% Kolmogorov-Smirnov test

fprintf(1, '\n- Kolmogorov-Smirnov Test...');

% Bonferroni correction
% divide by the number of tests performed
alpha_bon = alpha / nbr;

% cdfplots of reduced datasets
figure('visible','off');


% reduce the datasets according to their distribution

% number of bins
edges = 0:0.01:1; % 101 bins, last bin (1) counts any values that match 1, so should be empty
e = length(edges);


% store all results from KS-test
ks_all = zeros(nbr,7);

% original sample index
ks_all(:,7) = sample_idx;

% median beta values of each site across all samples
% if NaN values in row - median will be NaN
% potential solution: nanmedian.m, which is slower
y_ori = median(betas,2);


% reference sample is constant for all samples
% choose a subset from the median values of all array sites

% binary vector: select CpG sites
y_idx = false(size(betas,1),1);
 
for j=1:e % for every bin: choose a fraction of values 
    
    % histogram
    [y_hist, y_bin] = histc(y_ori, edges);
    
    y_nbr = round(y_hist(j)*frac);      
    if y_nbr > 0
        y_idx_1 = find(y_bin==j);
        % choose first y_nbr values
        y_idx(y_idx_1(1:y_nbr)) = 1;
    end        
end

% reference sample
y = y_ori(y_idx);


for i=1:nbr
    
    % one sample   
    x = betas(:,i);
    
    % binary vector: select CpG sites
    x_idx = false(length(x),1);
           
    % histogram
    [x_hist, x_bin] = histc(x, edges);
       
    for j=1:e % for every bin: choose a fraction of values 
                
        x_nbr = round(x_hist(j)*frac);        
        if x_nbr > 0
            x_idx_1 = find(x_bin==j);
            % choose first x_nbr values
            x_idx(x_idx_1(1:x_nbr)) = 1;
        end    
    end
    
    % choose subset of values
    x = x(x_idx);
        
    % 2-sample KS test
    [h,p,s] = kstest2(x, y, alpha);       
        
    % KS-test results
    ks_all(i,1) = h;
    ks_all(i,2) = p;
    ks_all(i,3) = s;    
       
    % reduced sample sizes
    ks_all(i,4) = length(x);
    ks_all(i,5) = length(y);
       
    
    %% Bonferroni correction    
    % compare observed P-value against corrected value
    ks_all(i,6) = p <= alpha_bon; 
    
         
    %% cdfplots: highlight 'problematic' samples in red
          
    h = cdfplot(x);
    
    if ks_all(i,6) == 1
        set(h, 'Color', 'red')
    else
        set(h, 'Color', 'blue')
    end    
    hold on    
    
            
end

fprintf(1, ' done\n');


%% add cdfplot of reference sample - reduced data set

h2 = cdfplot(y);
set(h2, 'Color', 'green')

% cdfplot of reference sample - all data points
h2 = cdfplot(y_ori);
set(h2, 'Color', 'cyan')

% select font size
if nbr < 20
    fs = 8;
elseif nbr < 85
    fs = 5;
else 
    fs = 3;
end

% use the indices as sample names
sample_names = arrayfun(@num2str, sample_idx, 'UniformOutput', 0);

sample_names{end+1} = 'median-subset';
sample_names{end+1} = 'median-all';

legend(sample_names, 'Location', 'NorthEastOutside', 'FontSize',fs)

sample_names(end-1:end) = [];

set(gcf, 'PaperType','A4','PaperOrientation','landscape');
set(gcf, 'PaperUnits', 'centimeters');
set(gcf, 'PaperPosition', [-3.5 0 36.5 21]);

file_name = horzcat(prefix, '_beta_CDF_subset_KS.pdf');

saveas(gcf,file_name)


%% report summary of KS-test results

fprintf(fid_rep, '\n# Kolmogorov-Smirnov test results\n');

fprintf(fid_rep, 'number of comparisons\t%u\n', nbr);
fprintf(fid_rep, 'significance level\t %E\n', alpha);
fprintf(fid_rep, 'Bonferroni corrected significance level\t%E\n', alpha_bon);   
fprintf(fid_rep, 'number of samples with aberrant distribution\t%u\n\n', sum(ks_all(:,6)));


%% report overview of KS-test results

% keep sample idx before sorting
idx = ks_all(:,6)==1;

% sort according to P-value
ks_all = sortrows(ks_all, 2);

d_header = 'Sample index\tP-value\tKS-test statistic\tsize of reduced sample\tsize of median of samples\treject H0\n';
fprintf(fid_rep, d_header);

d_num = '%u\t%E\t%6.4f\t%u\t%u\t%u\n';

% rearrange columns as in output
ks_all = ks_all(:,[7,2,3,4,5,6,1]);
for i=1:nbr
    fprintf(fid_rep, d_num, ks_all(i,1:6));
end


%% if any aberrant samples: show them in distribution plots

if any(ks_all(:,6)==1)
    
    % CDF plots of all samples - mark aberrant samples

    % color maps: red-yellow color map: abberant sample, blue: normal sample
    color_matrix = zeros(nbr,3);
    %%% color_matrix(ks_all(:,6)==1,:) = colormap(autumn(sum(ks_all(:,6)==1)));
    %%% color_matrix(ks_all(:,6)==0,3) = 1;    
            
    color_matrix(idx,:) = colormap(autumn(sum(idx)));
    color_matrix(~idx,3) = 1;    

    get_beta_cdf(betas, [prefix, '_beta_CDF_KS.pdf'], sample_names, color_matrix);


    % beta value distribution - mark aberrant samples
    get_beta_kde(betas, [prefix, '_beta_distribution_KS.pdf'], sample_names, color_matrix);
end



end