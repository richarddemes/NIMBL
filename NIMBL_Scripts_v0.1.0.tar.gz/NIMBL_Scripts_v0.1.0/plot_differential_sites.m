function plot_differential_sites(group_names, grouping, betas, s_all, hits, file_name)

% plot_differential_sites(group_names, grouping, betas, s_all, hits, file_name)
%
% summary plot of methylation levels of CpG sites: group1 vs group2 , flag
% masked samples with 'x'
% 
% IN:
% - group_names: cell array with two group names
% - grouping: (integer) column vector defining two groups of samples
% - betas: beta values
% - s_all: binary matrix storing which samples were masked (0) for each CpG
%          site and which were kept (1)
% - hits: plot subset of CpG sites, row vector of size 2 - plot range of
%         sites, column vector - plot individual sites given by row position
%         in betas matrix
% - file_name: (string) PDF file name of plot
% OUT:
% - PDF file of plot


% figure window invisible
figure('visible','off');

% appearence
markers = {'o', 's'};
color= {'red', 'blue'};

% for legend 
handles_all = zeros(1,2);

% for legend
% escape underscores within names
group_names_print = regexprep(group_names, '_','\\_');


%% choose range of candidates if specified

n = size(betas,1);

% test if offset needs to be calculated
xtick_range = 0;

% test if individual sites chosen
xtick_ind = 0;

hits_title_info = '';

% individual sites
if (size(hits,1) > 1)
    
    
    % order of beta values as specified in hits
    % the order is compleetely specified by the user
    betas = betas(hits,:);
    s_all = s_all(hits,:);
    
    hits_title_info = ': [';
    
    fprintf(1, '- Candidates plotted: ');
    for i=1:size(hits,1)-1
        fprintf(1, '%u, ', hits(i));
        hits_title_info = [hits_title_info, num2str(hits(i)), ','];
    end
    fprintf(1, '%u\n', hits(end));
    
    xtick_ind = 1;
    
    hits_title_info = [hits_title_info, num2str(hits(end)), ']'];
    
% range of sites   
else
    
    if (hits(1) > n || hits(2) > n || hits(1) > hits(2) || hits(1) < 1)
        fprintf(1, '- Selection of candidates for plotting ignored, all plotted\n\n');    
    else
        betas = betas(hits(1):hits(2),:);
        s_all = s_all(hits(1):hits(2),:);

        fprintf(1, '- Candidates plotted: %u - %u\n', hits(1), hits(2));
        
        hits_title_info = [': [', num2str(hits(1)), ' - ', num2str(hits(2)),']'];
        
        if hits(1) ~= 1
            xtick_range = 1;
        end
    end
end

%% generate plot

% size of the markers depending on the number of plotted sites
% 2 sizes for circles/squares and masked samples

s = size(betas, 1);
if s <= 50
    marker_size_1 = 60;
    marker_size_2 = 55;
elseif s <= 100
    marker_size_1 = 40;
    marker_size_2 = 35;
elseif s <= 150
    marker_size_1 = 20;
    marker_size_2 = 15;
elseif s <= 200
   marker_size_1 = 10; 
   marker_size_2 = 7; 
else
   marker_size_1 = 5;
   marker_size_2 = 3;    
end


for i=1:2 % group 1 and 2                
    
    idx = grouping == i;        
        
    % coordinates as row vectors
    x = repmat(1:size(betas,1),1,sum(idx));
    y = reshape(betas(:,idx), 1, size(betas,1) * sum(idx));    
        
    handles_all(i) = scatter(x, y, markers{i}, 'SizeData', marker_size_1, 'MarkerEdgeColor', color{i});
    hold on
    
    % print values to file:
    %%% mix_mat = [x', y', repmat(i,size(x,2),1)];
    %%% dlmwrite('tester_results_print.txt', mix_mat, '-append', 'delimiter', '\t');
    
    
    % include size of group (number of samples) within the legend
    group_names_print{i} = [group_names_print{i}, ' (', num2str(sum(idx)), ')'];
    
    
    % masked samples ('x')        
    mask = s_all(:,idx) == 0;

    if (any(any(mask)))

        % row numbers / CpG site
        dummy_idx = repmat(1:size(betas,1), 1, sum(idx));
        betas_mask = betas(:,idx);

        x = dummy_idx(mask);
        y = betas_mask(mask);

        scatter(x,y, 'x', 'SizeData', marker_size_2, 'MarkerEdgeColor', color{i})
        
        % print values to file:
        %%% mix_mat = [x', y, repmat(-i,size(x,2),1)];
        %%% dlmwrite('tester_results_print.txt', mix_mat, '-append', 'delimiter', '\t');
        
    end  
end

hold off


%% plot settings

box on

% legend
lh = legend(handles_all, group_names_print, 'Location', 'NorthOutside', 'Orientation', 'horizontal');
% use 1 as default linewidth of legend entries
h = findobj(lh,'Type','patch');
set(h,'LineWidth', 1); % also works for vector of handles


% axes limits
xlim([0 size(betas, 1)+0.5]) 
ylim([0 1])

set(gca,'YGrid','on')

% set tick for each site
if xtick_ind 
    
    xticks = 1:size(betas,1);
    set(gca,'XTick', xticks)
        
    % chosen sites as labels
    xTicks_labels = hits'; 
    set(gca, 'xticklabel', xTicks_labels);     

else
    
    s = size(betas,1);

    if s <= 25
        xticks = 0:size(betas,1);
    elseif s <= 50
        xticks = 0:2:s;
    elseif s <= 100
        xticks = 0:5:s;
    elseif s <= 200  
        xticks = 0:10:s;
    else
        xticks = 0:20:s;
    end

    set(gca,'XTick', xticks)
end


% change xticks if not started with 1st candidate
if xtick_range

    xTicks = get(gca, 'xtick');
    
    % new numbers as labels, add offset
    xTicks_labels = xTicks + hits(1) - 1; 
        
    set(gca, 'xticklabel', xTicks_labels);    
end


% axes labels
xlabel(gca, 'Array Site')
ylabel(gca, 'Beta Value')

% title
title(['Differential methylation (', num2str(size(betas,1)), ' array sites', hits_title_info, ')']);


%% save as PDF

set(gcf, 'PaperUnits', 'centimeters');
set(gcf, 'PaperType','A4','PaperOrientation','landscape');
% set(gcf, 'PaperPosition', [-2 0 34.5 20]);
set(gcf, 'PaperPosition', [-3.5 -1.2 36.2 23.2]);


saveas(gcf,file_name)

close all

end

