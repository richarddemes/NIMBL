function [pos_found_idx, out_file_print_txt] = probe_alignment(platform, probe_annot, header, chr_all, mapinfo_all, cgID_col, beta_all, pval_all, pval_cut_p, grouping, group_names, number_groups, ...
    collect_names, collect_coords, extra_upstream, extra_downstream, extra_bases, align_probes, label_sites, zoom_in, S_extra, S_extra_header,...
    prefix, fid_rep)

% function [pos_found_idx, out_file_print_txt] = probe_alignment_new(platform, probe_annot, header, chr_all, mapinfo_all, cgID_col, beta_all, pval_all, pval_cut_p, grouping, group_names, number_groups, ...
%     collect_names, collect_coords, extra_upstream, extra_downstream, extra_bases, align_probes, label_sites, zoom_in, S_extra,...
%     prefix, fid_rep)
%
% - find all probes of one genomic region (gene or intergenic)
% - align each probe sequence to the chromosomal sequence and generate multifasta
%   file
% - generate overview plot of all CpG sites in the gene and measured array sites


%% file names

% file name stems for output files
if collect_coords(5) == 0    
    % use user-specified name for region or NIMBL constructed region name
    file_name_stem = collect_names{4};
        
else % gene, use input as file name, this may contain ';'
   file_name_stem = collect_names{1};
end

% file name for fasta alignment file
if align_probes
    output_file = horzcat(prefix, '_probe_alignment_', file_name_stem,'.fa');
end

% file name of methylation overview plot (stem plot)
% - measurements according to genomic position
output_file_plot = horzcat(prefix, '_methylation_overview_',file_name_stem,'.pdf');
output_file_plot_zoom = horzcat(prefix, '_methylation_overview_',file_name_stem,'_zoom.pdf');

% file name of methylation profile plot
% - equidistant measurements independent of genomic position, but in the same order 
output_file_plot_2 = horzcat(prefix, '_methylation_profile_', file_name_stem, '.pdf');
output_file_plot_zoom_2 = horzcat(prefix, '_methylation_profile_',file_name_stem,'_zoom.pdf');

% file name of methylation levels, pvals and annotation info
% - text file of all plotted array sites
% - within zoomed region or outside
output_file_txt = horzcat(prefix, '_methylation_profile_', file_name_stem, '.txt');
output_file_txt_zoom = horzcat(prefix, '_methylation_profile_',file_name_stem,'_zoom.txt');



%% genomes

% TODO: support 27k array
if platform==1
              
    % genome build hg18
    % repeats masked with lower case
    % chr fasta files concatenated (1,2,3,...,21,22,x,y)
    hg_repeat_lower = 'hg18_genome_repeat_lower.fa';
    
    % repeats masked with upper case
    % hg_repeat_N = 'hg18_genome_repeat_N.fa';

    % hg19 chromosome sizes (1,2,3,...,22,x,y)
    hg_chr_size = 'hg18_chr_size.txt'; 
    
elseif platform == 2
    
    % genome build hg19
    % repeats masked with lower case
    % chr fasta files concatenated (1,2,3,...,21,22,x,y)
    hg_repeat_lower = 'hg19_genome_repeat_lower.fa';
    
    % repeats masked with upper case
    % hg_repeat_N = 'hg19_genome_repeat_N.fa';

    % hg19 chromosome sizes (1,2,3,...,22,x,y)
    hg_chr_size = 'hg19_chr_size.txt';
end



%% regular expressions of column names within annotation file

% UCSC_RefGene_Accession
% r_access = 'refgene(\s|-|_)?accession';
r_access = 'accession';

% forward seq: 122 bases
% r_fseq = 'forward(\s|-|_)?sequence';

% source sequence: 50 bases
r_sseq = 'source(\s|-|_)?seq';

% strand match of probe
r_strand_probe = 'strand';

% UCSC_RefGene_Group: TSS1500, TSS200, 5'UTR, 1stExon, Body, 3'UTR
r_probe_site = 'refgene(\s|-|_)?group';

% Infinium_Design_Type
r_design = 'infinium(\s|-|_)?design';


%% find within defined gene regions corresponding array sites
%  - use location of array sites independent of array annotation

% TODO:
% handle non-CpG sites extra
% 3091 non-CpG sites, ID: "ch.[chr number].number"
% 65 random SNPs, ID: "rs[number]" 


% find corresponding chromosome in annot file
chr_search = chr_all == collect_coords(1);


% adjust txS and txE if user-defined
% usually at least 1500 more bases upstream of txS
% adjust only if transcript is chosen (not relevant for genomic region)

% UCSC:
% txS is always smaller than txE, independent of strand
% - this schema applies to add bases up or downstream:
%       txs  <  txE
% plus  -1500   +100
% minus -100    +1500
%
% - to add 1500 more bases upstream (beyond txS), the txE value needs to be
%   changed for negative strand
% - to add 100 more bases downstream (beyond txE), the txS value needs to
%   be changed for negative strand

% CAUTION: tables do report txStart as TSS-1 (due to UCSC coordinate scheme), but
% txEnd is reported according to 1-based scheme
% the start coordinates txS and cdsS are changed to 1-based scheme in
% get_genmic_coords

% no adjustment if abritrary chromosomal region
if collect_coords(5) == 0
    
    s = collect_coords(3);
    e = collect_coords(4);
    
else % specific transcript

    % positive strand
    if collect_coords(2) == 1

        % decrease the UCSC txS value        
        s = collect_coords(3) - extra_upstream;

        % increase the UCSC txE value    
        e = collect_coords(4) + extra_downstream;

    else % negative strand    
        % decrease the UCSC txS value, which is actually the biological txE
        s = collect_coords(3) - extra_downstream;

        % increase the UCSC txE value, which is actually the biological txS
        e = collect_coords(4) + extra_upstream;
    end
end

% find all potential positions (independent of chromosome)
% mapinfo is 1-based
pos_search_start = mapinfo_all  >= s;
pos_search_end =  mapinfo_all <= e;


% all positions on the right chromosome
pos_found = chr_search & pos_search_start & pos_search_end;


%% sort all found array sites according to mapinfo

strand = logical(collect_coords(2));

if strand
    strand_char = '+';
    [mapinfo_sort, IX] = sort(mapinfo_all(pos_found));
else
    strand_char = '-';    
    [mapinfo_sort, IX] = sort(mapinfo_all(pos_found), 'descend');
end


%% get genomic sequence
%  - repeats in lower case letters

% s is always smaller than e
S1 = get_genomic_sequence(hg_repeat_lower, hg_chr_size, collect_coords(1), s - extra_bases, e + extra_bases, []);

% reverse complement if region on negative strand
% so only CG sites need to be checked
if ~strand
    S1 = seqrcomplement(S1);
end

n=length(S1);

% consistency check
if ((e-s+1 + 2*extra_bases) ~= n)
    fprintf(1, 'WARNING: specified chromosomal range (%u - %u) in obtained sequence is not consistent with length of sequence extracted (%u)\n', s-extra_bases, e+extra_bases, n);
end

%% all CpG sites in genomic sequence

% CpG sites in input sequence
% do NOT consider the extra bases, which were only added to ensure alignment
% of probes close to the edge
% if a 'C' is exactly on the ends of the region, add one extra base to
% 'look ahead' or 'look behind'  if next base is a 'G' or 'C'

if strand
    n_cpg1 = length(regexpi(S1(1+extra_bases:end-extra_bases + 1), 'cg'));
else
    % n_cpg1 = length(regexpi(S1(1+extra_bases:end-extra_bases), 'cg')); 
    n_cpg1 = length(regexpi(S1(1+extra_bases - 1:end-extra_bases), 'cg'));
end

% replace all non-CG sites with gaps
% probably more elegant with lookaround operators
% - highlight also CG sites within extra bases
cpg_all = regexprep(S1,'cg','11','ignorecase');
cpg_all = regexprep(cpg_all,'[a-z]','-','ignorecase');
cpg_all = regexprep(cpg_all,'11','CG','ignorecase');

% position of Cs
% including the ones within extra_bases
cpg_all_pos = regexpi(cpg_all, 'c');
%%% cpg_all_pos = regexpi(cpg_all(1+extra_bases:end-extra_bases), 'c');


%% Report results

fprintf(1, '\n# %s:\n- Number of array sites detected: %u\n', collect_names{4}, sum(pos_found));

% header of table in report file
% fprintf(fid_rep, 'Input value\tChrom\tStrand\tStart genomic region\tEnd genomic region\tLength genomic region\tNumber of array sites\tTotal number of CpG sites within region');

fprintf(fid_rep, '%s\t%s\t%s\t%u\t%u\t%u\t%u\t%u', collect_names{1}, chr_to_string(collect_coords(1)), strand_char, s, e, e-s+1, sum(pos_found), n_cpg1);

% report chromosomal start and end coordinates of complete fasta sequence
% this includes the extra_bases!
if align_probes
    fprintf(fid_rep, '\t%u\t%u\n', s - extra_bases, e + extra_bases);
else
    fprintf(fid_rep, '\n');
end


%% test if any array sites found
%  do not continue if no array sites are found for this gene or intergenic
%  region

if sum(pos_found) == 0    
    pos_found_idx = [];
    out_file_print_txt = [];
    return
end


%% print genomic sequence to fasta file
    
% write original sequence(s) in new file
% if fasta file already exists fastawrite gives a warning at this first
% call of fastawrite and appends the sequences to the previous file
% therefore, delete the file (if already created) and create a new empty
% file and switch off the warning before the first call of fastawrite

if align_probes

    fid_fasta  = fopen(output_file, 'w');
    fclose(fid_fasta);

    % proposed workaround for appending sequences to existing files
    warnState = warning; %Save the current warning state
    warning('off','Bioinfo:fastawrite:AppendToFile');
    
    genomic_seq_tag = ['chr',   chr_to_string(collect_coords(1)),':', human_readable(s - extra_bases) ,'-', human_readable(e + extra_bases),', ', strand_char, ' strand'];
   
    % genomic sequence in 5' -> 3'
    fastawrite(output_file, genomic_seq_tag, S1);
end


%% collect annotation data from annotation file


if align_probes
    
    % cgIDs
    cgID = probe_annot(pos_found, cgID_col);

    % source sequence
    sseq_idx = not(cellfun(@isempty, regexpi(header,r_sseq)));
    sseq = probe_annot(pos_found, sseq_idx);

    % strand probe match
    strand_p_idx = not(cellfun(@isempty, regexpi(header,r_strand_probe)));
    strand_probe = probe_annot(pos_found, strand_p_idx);

    % UCSC_RefGene_Accession: NM_... NR_...
    access_idx = not(cellfun(@isempty, regexpi(header,r_access)));
    access = probe_annot(pos_found, access_idx);

    % genomic function - location relative to TSS (TSS1500,...)
    probe_site_idx = not(cellfun(@isempty, regexpi(header,r_probe_site)));
    probe_site = probe_annot(pos_found, probe_site_idx);

    % Infinium design type (I or II)
    design_idx = not(cellfun(@isempty, regexpi(header,r_design)));
    design = probe_annot(pos_found, design_idx);

end


%% all array measured CpG positions
%  - scale for plot
%  - consider the extra bases added to the ends of the sequence

cpg_array_pos = zeros(1,length(mapinfo_sort));

for i= 1:length(mapinfo_sort)
    if strand
        cpg_array_pos(i) = mapinfo_sort(i) - s + 1 + extra_bases;
    else
        cpg_array_pos(i) = e - mapinfo_sort(i) + extra_bases;
        % cpg_array_pos(i) = e - mapinfo_sort(i) + extra_bases + 1;
    end
end


%% semiglobal alignment
%  - align each probe sequence to genomic sequence
%  - all lower case letters are converted to upper case letters in alignment
%    sequence

% alignment only if chosen
if align_probes
       
    % all CpG array sites along the sequence
    cpg_array = repmat('-', 1, n);

    % align "source sequence"
    fprintf(1, '- Alignment of probes ...\n');
    
    % each probe
    for i=1:length(mapinfo_sort)
        
        % align each probe twice
        % earlier runs did not reveal a consitent pattern when only forward
        % sequence from annotation file was used
        % hence, this sub-optimal workaround with 2 alignments
        [score1, alignment1] = nwalign(S1, sseq{IX(i)}, 'alphabet', 'NT', 'glocal', 1);
        [score2, alignment2] = nwalign(S1, seqrcomplement(sseq{IX(i)}), 'alphabet', 'NT', 'glocal', 1);
        
        % choose better alignment
        if score1 > score2
            alignment = alignment1;
        else
            alignment = alignment2;
        end
    
        % aligned probe sequence
        alignment = alignment(3,:);

        % check for perfect matches
        t = regexpi(alignment, '[ACGT].*[ACGT]', 'match');
        if length(t{:}) ~= 50
            fprintf(1, '- imperfect alignment of probe %u: %s\n', i, cgID{IX(i)});
        end
                       
        
        % running index of array site
        c = cpg_array_pos(i);

        % flag CpG site: add running index to measured C position
        % length is 1,2 or 3 according to the number of digits for the
        % position
        % - non-cpg site also gets this tag
        cpg_array(c:c+length(num2str(i))) = horzcat('C',num2str(i));
        
        % add extra bases to sequence if design type II (does not match C in CpG site, so one base longer at opposite end)
        if strcmp(design{IX(i)}, 'II')
            if strcmp(alignment(c-1),'-')
                alignment(c+50)=upper(S1(c+50));
            else
                alignment(c-49)=upper(S1(c-49));
            end
        end

        % print probe alignment    
        % header of each probe alignment with probe information from
        % annotation file

        if platform == 1
            fastawrite(output_file,  horzcat(num2str(i),'_',cgID{IX(i)},'_',num2str(mapinfo_sort(i)),'_',...
                access{IX(i)},'_',design{IX(i)},'_',strand_probe{IX(i)}), alignment);

        elseif platform == 2

            fastawrite(output_file,  horzcat(num2str(i),'_',cgID{IX(i)},'_',num2str(mapinfo_sort(i)),'_',...
            probe_site{IX(i)},'_',access{IX(i)},'_',design{IX(i)},'_',strand_probe{IX(i)}), alignment);
        end


        % write gene sequence and CpG sites information for better visualisation
        % obsolete if alignment viewer would allow split screen
        if mod(i,40)==0
            fastawrite(output_file,  horzcat('CpG sites in total: ', num2str(n_cpg1)), cpg_all);
            fastawrite(output_file,  horzcat('Array sites on array: ', num2str(length(mapinfo_sort))), cpg_array);
            % genomic sequence again
            fastawrite(output_file, genomic_seq_tag, S1);
        end

    end

    % all CpG sites in gene sequence
    % append to end of fasta file
    fastawrite(output_file,  horzcat('CpG sites in total: ', num2str(n_cpg1)), cpg_all);


    % sequence with all CpG sites measured on array
    % append to end of fasta file
    fastawrite(output_file,  horzcat('CpG sites on array: ', num2str(length(cpg_array_pos))), cpg_array);

    warning(warnState) %Reset warning state to previous settings
end



%% generate increasing positions, consider strand direction and gene or genomic region

if collect_coords(5) == 0 % genomic region
    
    positions = collect_coords([3,4]);
        
    % set two labels
    lab = [' Start  '; '   End  ']; % length 8
        
    % negative strand
    if ~strand
        positions = fliplr(positions);
        % also flip the labels
        lab = flipud(lab);
    end
    
else % gene

    % highlight gene regions with vertical bars within plot
    % all strings of labels of same length (8)
    lab = [' txStart'; 'cdsStart'; '  cdsEnd';'   txEnd'];

    % 1st check for non-protein coding gene (NR...: cdsStart = cdsEnd = txE)
    % coordinates already changed to 1-based format in get_genomic_coords,
    % so remove 1 position before comparison (here, start and end is compared)
    if (collect_coords(5)-1) == collect_coords(6)    

        positions = collect_coords([3,4]);
        % do not display cdsS and cdsE as labels
        lab([2,3],:) = [];
        fprintf(1, '- non-protein coding gene (cdsStart = cdsEnd)\n');

        % negative strand UCSC txS corresponds to biological txE
        if ~strand
            positions = fliplr(positions);
        end
    else
        % 'biological' order: txS - cdsS - cdsE - txE    
        % collect doords: col 3: txS, 4: txE, 5: cdsS, 6: cdsE

        if strand % positive strand
            positions = collect_coords([3,5,6,4]);
        else % negative strand
            positions = collect_coords([4,6,5,3]);
        end


        % 2nd check for no UTRs
        if positions(1) == positions(2) % txS = cdsS, both are now 1-based
            positions(2) = [];
            lab(1,:) = 'txS+cdsS'; % length 8
            lab(2,:) = [];
            fprintf(1, '- no 5'' UTR (txStart = cdsStart)\n');
            % example: 
            % input gene	#bin	name	chrom	strand	txStart	txEnd	cdsStart	cdsEnd	
            % OR10T2	1793	NM_001004475	chr1	-	158368311	158369256	158368311	158369256

            % additionally(!) cdsE = txE, both were already 1-based
            % example: 
            % input gene	#bin	name	chrom	strand	txStart	txEnd	cdsStart	cdsEnd	
            % OR10T2	1793	NM_001004475	chr1	-	158368311	158369256	158368311	158369256
            if positions(2) == positions(3);

                positions(3) = [];
                lab(2,:) = 'txE+cdsE'; % length 8
                lab(3,:) = [];
                fprintf(1, '- no 3'' UTR (cdsE = txE)\n');            
            end
        else        
            % only no 3' UTR 
            if positions(3) == positions(4);

                positions(4) = [];
                lab(3,:) = 'txE+cdsE'; % length 8
                lab(4,:) = [];
                fprintf(1, '- no 3'' UTR (cdsE = txE)\n'); 
            end
        end
    end
end

% create increasing positions of coordinates and scale it to its length
% for plotting independent of chromosomal coordinates
% collected positions are currently:
% - increasing for positive strand
% - decreasing for negative strand

for i=1:length(positions)
    
    if strand % positive strand                
        positions(i) = positions(i) - s + 1 + extra_bases;
    else % negative strand        
        positions(i) = e - positions(i) + 1 + extra_bases;
    end    
end


% add two extra positions, due to Infinium annotation (TSS200 and TSS1500)
% but check if at least 200 or 1500 bases are added upstream of TSS by user

if collect_coords(5) ~= 0 % for genes only
    
    if extra_upstream >= 200
        lab = vertcat(' TSS-200', lab); % label of length 8
        positions = [positions(1)-200, positions];
    end
    
    if extra_upstream >= 1500
        lab = vertcat('TSS-1500', lab); % label of length 8
        % use second position which is the original TSS
        positions = [positions(2)-1500, positions];
    end
    
end

%% stem plot

fprintf(1, '- Generating overview plot ...\n');

% figure window invisible
figure('visible','off');
hold on

% number of groups
g = grouping(grouping>0);
g = unique(g);
% number of groups to plot
m2 = length(g);

% use number of specified group variables within the input file
% a group might be masked (e.g.g2=[]) or all samples within a group are
% excluded by the user

% color for each group
% use the full set of possible groups so that colors are kept for each
% group
color = get_color_code(1:number_groups, number_groups);

% for legend 
handles_all = zeros(1, m2);
handles_all_high_pval = zeros(1, m2);

% group names for legend
% escape underscores within names
group_names_print = regexprep(group_names, '_','\\_');
% exclude names of ignored groups
group_names_print = group_names_print(g);


% convert logical vector of orginal positions to numeric index
pos_found_idx = find(pos_found);

% order these array sites according to mapinfo
% (ascending or descending depending on strand)
pos_found_idx = pos_found_idx(IX);


% line_width = 0.5; % default
line_width = 0.6;

% color of stems
stem_color = [0.6  0.6  0.6]; % gray


%% zoom analysis

% consider user-specified zoom
%  - consider extra bases at the begining of the plotted region
%  - get positions within beta value matrix of sites that are actually
%    plotted (for these sites beta values are plotted)


% if region is specified without a name, do not use the generated long name
% for the title
% regionname is specified
if length(strfind(collect_names{1}, ';')) == 3
    title_info_1 = 'Region';
else
    title_info_1 = regexprep(collect_names{4}, '_','\\_');
end

title_info = [title_info_1, ' (chr',   chr_to_string(collect_coords(1)),':', human_readable(s) ,'-', human_readable(e), '; ' strand_char, ' strand'];

zoom_on = false;

if (length(zoom_in) == 1 && zoom_in > 0) && n >= zoom_in
    
    % which array sites are within zoomed region
    idx_array_site = find(cpg_array_pos <= (zoom_in + extra_bases));
    pos_found_idx = pos_found_idx(idx_array_site);
        
    % add extra bases to the end coordinate
    xlim_val = [0, zoom_in + extra_bases];
    title_name = horzcat(title_info, '; zoom first ', human_readable(zoom_in),' bp, ',    num2str(length(pos_found_idx)),' array sites)');
       
    fprintf(1, '- Zoomed-in plot (first %s bp) with %u array sites\n', human_readable(zoom_in), length(pos_found_idx));
    zoom_on = true;
    
elseif (length(zoom_in) == 2 && sum(zoom_in) > 0) && (n >= zoom_in(2) && zoom_in(1) < zoom_in(2))
    
    % which array sites are within zoomed region
    idx_array_site = find((cpg_array_pos >= (zoom_in(1) + extra_bases)) & (cpg_array_pos <= (zoom_in(2) + extra_bases)));
    pos_found_idx = pos_found_idx(idx_array_site);
            
    % add extra bases to both coordinates
    xlim_val = zoom_in + extra_bases;
    title_name = horzcat(title_info, '; zoom region ', human_readable(zoom_in(1)) ,' - ', human_readable(zoom_in(2)), ' bp; ',    num2str(length(pos_found_idx)),' array sites)');
       
    fprintf(1, '- Zoomed-in plot (region %s - %s bp) with %u array sites\n', human_readable(zoom_in(1)),  human_readable(zoom_in(2)), length(pos_found_idx));
    zoom_on = true;
    
else % no zoom (complete region) OR zoom_in parameters not correct
    xlim_val = [0 n+1];
    idx_array_site = 1:length(pos_found_idx);
    title_name = horzcat(title_info, '; ',human_readable(e-s+1),' bp; ',    num2str(length(pos_found_idx)),' array sites)'); 
end 


cpg_array_pos = cpg_array_pos(idx_array_site);


%% test if no array sites are left after the zoom
%  - do not continue if no array sites within zoomed region

if isempty(pos_found_idx)
    pos_found_idx = [];
    out_file_print_txt = [];
    return
end


%% collect individual plots

% 1.
% all CpG sites stems of low height on negative y-axis, gray
stem(cpg_all_pos, -(repmat(0.1,1,length(cpg_all_pos))), 'MarkerEdgeColor', stem_color, 'Color', stem_color, 'Marker', 'none');


% delete labels if not within zoomed region
% ticks are removed, but labels are not deleted at the edges
if (length(zoom_in) == 1 && zoom_in > 0) && n >= zoom_in
    
    idx_del = (positions > (zoom_in + extra_bases));
    positions(idx_del) = [];
    lab(idx_del, :) = [];
    
elseif (length(zoom_in) == 2 && sum(zoom_in) > 0) && (n >= zoom_in(2) && zoom_in(1) < zoom_in(2))
    
    idx_del = (positions < (zoom_in(1) + extra_bases)) | (positions > (zoom_in(2) + extra_bases));    
    positions(idx_del) = [];
    lab(idx_del, :) = [];
end


% ylim([-0.15 1.05])
ylim([-0.13 1.05])
yL = get(gca,'YLim');


% 2. 
% plot vertical bars of genomic region (e.g. 'TSS' or 'start') in the background
% light gray
if ~isempty(lab)        
    for i = 1:size(lab,1)
        line([positions(i) positions(i)], yL, 'Color', [0.8 0.8 0.8]);
    end
end


% 3.
% draw one stem plot with the maximum methylation level at each site
% do not consider the grouping here
% - stem will be in the background behind the markers indicating the
%   individual sample measurements
test_max = max(beta_all(pos_found_idx, grouping > 0), [], 2);
stem(cpg_array_pos, test_max, 'Marker', 'none', 'Color', stem_color, 'LineWidth', line_width);


% 4.
% highlight specific groups of array sites

if ~isempty(S_extra)
    
    n_extra = size(S_extra,2);
    
    % mask underscores
    S_extra_header = regexprep(S_extra_header, '_','\\_');
    
    % which colors to highlight stems
    if n_extra == 1
        stem_color_extra = [0 1 0]; % only green
    else
        stem_color_extra = get_color_code(1:n_extra, n_extra);
    end
    
    % collect handles of all extra groups for the legend
    handles_extra = zeros(1, n_extra);
        
    % all identified array sites
    cgID_plot = probe_annot(pos_found_idx, cgID_col);
    
    % store the last column/group membership of each array site   
    % - one array site can be in several groups/columns
    group_member_extra = zeros(1, length(pos_found_idx));
    
    % overlap with each column/group
    for j=1:n_extra
        
        [~, idx_extra, ~] = intersect(cgID_plot, S_extra(:,j));
        
        if ~isempty(idx_extra)
            handles_extra(j) = stem(cpg_array_pos(idx_extra), test_max(idx_extra), 'Marker', 'none', 'Color', stem_color_extra(j,:), 'LineWidth', line_width);
                        
            % include number of extra sites for this group
            % BUT groups can have overlap and some colors/groups disappear
            % in the plot, this can be confusing if provided in legend
            % S_extra_header{j} = [S_extra_header{j}, ' (', num2str(length(idx_extra)), ')'];
            
            group_member_extra(idx_extra) = j;        
        end        
    end    
    
    
    
    % include the number of array sites for each group
    % - if a site is in multiple groups only the membership within the last
    %   group is counted
    % - some groups might be 'overwritten' and not any array site is visible
    % within the plot, only last membership of each site is visible
    % - and some groups might not contain any corresponding array site
    test_del = false(1,n_extra);
    
    for j=1:n_extra
        S_extra_header{j} = [S_extra_header{j}, ' (', num2str(sum(group_member_extra==j)), ')'];
        
        if isempty(intersect(j, group_member_extra))
            test_del(j) = true;
        end
    end
    
    % remove groups that are 'overwritten' or no members at all
    S_extra_header(test_del) = [];
    handles_extra(test_del) = [];
    
else    
    handles_extra = [];    
    S_extra_header = [];
    group_member_extra = [];
    stem_color_extra = [];
end


% 5.
% plot markers for each methylation level
% highlight measurements with lower confidence/high pval with 'x'
for i=1:m2 % each group
        
    idx = grouping == g(i);
    
    % relevant beta values
    beta_plot = beta_all(pos_found_idx, idx);
    
    x = repmat(cpg_array_pos, 1, sum(idx));
    y = reshape(beta_plot, 1, length(cpg_array_pos) * sum(idx));
    
    % keep the same color for each group index    
    handles_all(i) = scatter(x, y, 'o', 'MarkerEdgeColor', color(g(i),:), 'LineWidth', line_width);
    
    % test for pval above threshold
    pval_test = pval_all(pos_found_idx, idx) > pval_cut_p;        
    beta_high_pval = NaN(length(pos_found_idx), sum(idx));    
    beta_high_pval(pval_test) = beta_plot(pval_test);
    y = reshape(beta_high_pval, 1, length(cpg_array_pos) * sum(idx));
    
    % keep the same color for each group index    
    handles_all_high_pval(i) = scatter(x, y, 'x', 'MarkerEdgeColor', color(g(i),:), 'LineWidth', line_width);
        
    % include size of group (number of samples) within the legend
    group_names_print{i} = [group_names_print{i}, ' (', num2str(sum(idx)), ')'];    
end


% legend
% lh = legend(handles_all, group_names_print, 'Location', 'NorthOutside', 'Orientation', 'horizontal');
lh = legend([handles_all, handles_extra], [group_names_print, S_extra_header], 'Location', 'NorthOutside', 'Orientation', 'horizontal');

% the linewidth of the legend markers is not automatically adjusted
h = findobj(lh,'Type','patch');
% h = findobj(lh,'Type','Line'); % if stem plots are used
set(h,'LineWidth', 1); % also works for vector of handles

% repeat for stems
% BUT this does not work if handles are combined!?!
% any solution!?
% h = findobj(ltest,'Type','Line'); % if stem plots are used
% set(h,'LineWidth', 1);


% it can happen that the legend box is too small, which seems to be
% anannoying matlab bug


% box
box on

% Set the tick locations and remove the labels
set(gca,'XTick',positions,'XTickLabel','')

yticks = 0:0.1:1;
set(gca,'YTick', yticks)
set(gca,'YGrid','on')
ylabel('     Beta-Value')

% Estimate the location of the labels based on the position
% of the xlabel
hx = get(gca,'XLabel'); % Handle to xlabel
set(hx,'Units','data');
pos = get(hx,'Position');
y = pos(2);

% print extra labels (TSS1500,...)
if ~isempty(lab)    
    q = zeros(1, size(lab,1));
    % Place the new/rotated labels
    for i = 1:size(lab,1)    
        q(i) = text(positions(i),y,lab(i,:));
    end
    set(q,'Rotation',90,'HorizontalAlignment','right')    
end


% set xticks of array positions
set(gca, 'XTick', cpg_array_pos)

% label each array measurement with its index number if chosen
if label_sites    
    % set(gca, 'XTickLabel',1:length(cpg_array_pos))
    set(gca, 'XTickLabel', idx_array_site)
end

% set xlim at the end
xlim(xlim_val)


%% set size of markers
%  - number of plotted sites are now final after zoom handling

s_test = length(pos_found_idx);
if s_test <= 50
    marker_size = 40;
elseif s_test <= 100
    marker_size = 30;
elseif s_test <= 150
    marker_size = 20;
elseif s_test <= 200
   marker_size = 10; 
else
   marker_size = 5;
end

set(handles_all, 'SizeData', marker_size)
set(handles_all_high_pval, 'SizeData', marker_size)


%% save PDF

title(title_name)

set(gcf, 'PaperUnits', 'centimeters');
set(gcf, 'PaperType','A4','PaperOrientation','landscape');
% set(gcf, 'PaperPosition', [-3 0 35.5 21]);
set(gcf, 'PaperPosition', [-3.5 0 36 22]);

if zoom_on
   saveas(gcf, output_file_plot_zoom) 
else
   saveas(gcf, output_file_plot) 
end

close all


%% plot gene methylation levels in the same order as in genomic region
%  - same distance between array sites
%  - a zoomed-in region might not contain any array measurements

if ~isempty(pos_found_idx)
    if zoom_on
        plot_beta_overview(group_names, grouping, beta_all(pos_found_idx,:), pval_all(pos_found_idx,:), pval_cut_p, output_file_plot_zoom_2, title_name, idx_array_site, number_groups, group_member_extra, test_max, stem_color_extra, S_extra_header);
    else
        plot_beta_overview(group_names, grouping, beta_all(pos_found_idx,:), pval_all(pos_found_idx,:), pval_cut_p, output_file_plot_2, title_name, idx_array_site, number_groups, group_member_extra, test_max, stem_color_extra, S_extra_header);
    end
end


%% print beta values, pvals and annotation of plotted array sites to txt file
%  - performed within main module (nimbl_gene)

if zoom_on
    out_file_print_txt = output_file_txt_zoom;
else
    out_file_print_txt = output_file_txt;
end


end


%% convert number into readable string with commas

function out_string = human_readable(input_number)

out_string = sprintf(',%c%c%c',fliplr(num2str(input_number)));
out_string = fliplr(out_string(2:end));

end

%% convert numeric chr index to string

function out_string = chr_to_string(chr_number)

if chr_number == 23
    out_string = 'X';
elseif chr_number == 24
    out_string = 'Y';
else
    out_string = num2str(chr_number);
end

end


