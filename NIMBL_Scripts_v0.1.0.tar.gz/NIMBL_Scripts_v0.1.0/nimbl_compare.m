function nimbl_compare(input_script)

% nimbl_compare(input_script)

% module: compare two or three sets of array sites, for example, CpG sites
% found as differentially methylated sites by one method with different
% parameter settings or by two or three different methods
%
% - read in array sites (IDs) from 2 or 3 files
% - read in beta value matrix with cgIDs (assume cgIDs in 1st column)
% 
% OUT:
% - report file
% - scatter plot with mean/median diff between two groups analysed
% - lists of IDs for all possible overlaps
% - lists of genes for all possible overlaps
% - gene enrichment table for all IDs found in input lists
% - individual gene enrichment tables of unique set of genes for each
%   combination of input lists (3 or 7 sets)

% internal functions:
% - get_stats_groups
% - get_scatter_groups
% - print_stats
% - print_IDs


%% version
nimbl_version = 'v0.1.0';

fprintf(1, '\nNIMBL-compare module (%s):\n------------------------------\n', nimbl_version);

%%
% avoid re-reading of methylation input file (table with beta values)
% re-reading is checked by file name, so if the user changes the input file
% during a MATLAB session the old data will be used

persistent B;
persistent cgID;
persistent INPUT_BETA_FILE;

%% include global settings

eval(input_script);


%%%%%%%%%%%%%%%%
if platform == 1
    error('NIMBL-compare currently only works for 450k array data.');
end
%%%%%%%%%%%%%%%%


% check if number of input lists corresponds to the length of the
% post-filtering vector
if n ~= length(f_on)
    error('The specified number of input lists (''n'') is not consistent with the vector specifyig the post-filter of each list (''f_on'')');
end


%% filenames

% nimbl compare report
fid_rep = fopen([nimbl_comp_prefix, '_report.txt'], 'w');

% nimbl compare scatter plot
fn_scatter_compare = [nimbl_comp_prefix, '_scatter_plot'];


%% load gene annotation information
%  - generated with preprocess_annotation.m
%  - 3 variables:
%       - ID_info
%       - cg_info
%       - gene_symbols

if platform == 2

    % read from tab-delimited text file:
    gene_annot_450k = importdata('450k_gene_annot.txt', '\t', 0);

    ID_info = gene_annot_450k.textdata(:,1);
    % first three columns are relevant here
    % col 4 and 5 represent chr and mapinfo
    cg_info = gene_annot_450k.data(:,1:3);
    gene_symbols = gene_annot_450k.textdata(~cellfun(@isempty, gene_annot_450k.textdata(:,2)),2);
    gene_symbols(1) = {''};
    
end


%% lists of array IDs

fprintf(1, '\nReading 1st list of array IDs from: %s\n', list1);
c1 = importdata(list1);

fprintf(1, 'Reading 2nd list of array IDs from: %s\n', list2);
c2 = importdata(list2);

if n==3    
    fprintf(1, 'Reading 3rd list of array IDs from: %s\n', list3);
    c3 = importdata(list3);
else
    c3=0;
end

fprintf(fid_rep, 'NIMBL comparison report (%s)\n\n', nimbl_version);
fprintf(fid_rep, '# Lists compared:\n');
fprintf(fid_rep, 'List 1 (%s)\t%s\n', m1, list1);
fprintf(fid_rep, 'List 2 (%s)\t%s\n', m2, list2);
if n==3
    fprintf(fid_rep, 'List 3 (%s)\t%s\n', m3, list3);
end


% collect names of lists
% m1, m2, m3: names for the the lists, e.g. different methods or settings
if n==2
    m3='';
end
list_names={m1,m2,m3};


%% input data 
%  this should only include 1st col: array IDs, other columns: beta values

% only read data if file name is not known or changed


if ~strcmp(beta_file, INPUT_BETA_FILE)
    
    fprintf(1, 'Reading array IDs and beta values from: %s\n', beta_file);

    fid = fopen(beta_file);
    
    % assume cgIDs in first column
    % read first column, skip rest of the line
    cgID = textscan(fid, '%s %*[^\n]');
    
    fclose(fid);

    cgID = [cgID{:}];
    % skip header of column
    cgID(1) = [];
        
    % beta values
    % assume TAB delimited
    % assume one header row and one column (array IDs)
    B = dlmread(beta_file, '\t',1, 1);
    
    % reset persistent variable with latest input file
    INPUT_BETA_FILE = beta_file;
    
else
    fprintf(1, 'Use array IDs and beta values again from: %s\n', beta_file);
end


%% statistics for each site

% fprintf(1, 'Compute statistics (including mean, median) of each CpG site and each group...\n');
stats = get_stats_groups(B, g1, g2);


%% position of array IDs in beta table

idx1 = get_ori_pos2(c1, cgID);
idx2 = get_ori_pos2(c2, cgID);

if n==3
    idx3 = get_ori_pos2(c3, cgID);
else
    idx3 = 0;
end


%% filtering according to mean or median difference
%  filtering cutoff user defined (f, e.g. 0.1)

% overview information about mean and median difference between groups
fprintf(fid_rep, '\n# Group differences:\n');

filter_overview = zeros(n,4);

% columns:
% 1: total number of sites provided
% 2: # sites with mean diff >= f
% 3: # sites with median diff >= f
% 4: # sites with mean diff >= f AND median diff >= f

% set 1
filter_overview(1,1) = length(c1);
filter_overview(1,2) = sum(stats(idx1,3) >= f);
filter_overview(1,3) = sum(stats(idx1,6) >= f);
filter_overview(1,4) = sum(stats(idx1,3) >= f & stats(idx1,6) >= f);

% set 2
filter_overview(2,1) = length(c2);
filter_overview(2,2) = sum(stats(idx2,3) >= f);
filter_overview(2,3) = sum(stats(idx2,6) >= f);
filter_overview(2,4) = sum(stats(idx2,3) >= f & stats(idx2,6) >= f);


% set 3
if n==3
    filter_overview(3,1) = length(c3);
    filter_overview(3,2) = sum(stats(idx3,3) >= f);
    filter_overview(3,3) = sum(stats(idx3,6) >= f);
    filter_overview(3,4) = sum(stats(idx3,3) >= f & stats(idx3,6) >= f);
end

fprintf(fid_rep, 'List\tTotal sites\tmean diff >= %3.2f (%%)\tmedian diff >= %3.2f (%%)\tmean AND median diff >= %3.2f (%%)\n', f,f,f);
for i=1:n    
    fprintf(fid_rep, '%s\t%u\t%u (%3.2f)\t%u (%3.2f)\t%u (%3.2f)\n', list_names{i}, filter_overview(i,1),...
        filter_overview(i,2), filter_overview(i,2)*100/filter_overview(i,1),...
        filter_overview(i,3), filter_overview(i,3)*100/filter_overview(i,1),...
        filter_overview(i,4), filter_overview(i,4)*100/filter_overview(i,1));
end

if any(f_on)
    fprintf(fid_rep, '\n# Post-filtering: ');
        
    % choose mean or median difference
    if filter_method == 1
        % column 3 in stats table with mean difference
        f_col = 3;
        fprintf(fid_rep, 'mean difference between groups >= ');
    else
        % column 6 in stats table with median difference
        f_col = 6;    
        fprintf(fid_rep, 'median difference between groups >= ');
    end
    
    fprintf(fid_rep, '%3.2f\n', f);
        
    % actual filtering
    % some sites might be excluded from filtering
    
    if f_on(1)    
        f1 = stats(idx1,f_col) >= f;
        fprintf(1, '\n%s: selected %u sites from total of %u\n', m1, sum(f1), length(idx1));        
        idx1 = idx1(f1);
        c1 = c1(f1);    
    end


    if f_on(2)
        f2 = stats(idx2,f_col) >= f;
        fprintf(1, '%s: selected %u sites from total of %u\n', m2, sum(f2), length(idx2));        
        idx2 = idx2(f2);
        c2 = c2(f2);    
    end

    if n==3
        if f_on(3)
            f3 = stats(idx3,f_col) >= f;
            fprintf(1, '%s: selected %u sites from total of %u\n', m3, sum(f3), length(idx3));            
            idx3 = idx3(f3);
            c3 = c3(f3);        
        end
    else
        idx3 = 0;
    end
    
else
    fprintf(1, '\n# Post-filtering: none\n');
    fprintf(fid_rep, '\n# Post-filtering: none\n');
    
    for i=1:n
        fprintf(1, 'number of sites within list %s: %u\n', list_names{i}, filter_overview(i,1));
    end
end


% print final length of lists to report file
c_lengths_new = [length(c1), length(c2), length(c3)];

fprintf(fid_rep, 'List\tFilter on/off\tTotal sites\tSelected sites\t%% Selected\n');
for i=1:n
    fprintf(fid_rep, '%s\t%u\t%u\t%u\t%3.2f\n', list_names{i}, f_on(i), filter_overview(i,1), c_lengths_new(i), c_lengths_new(i)*100/filter_overview(i,1));
end


%% compute intersections and create scatterplot

names = {'mean', 'median'};

% filename for scatter plot
if n==2
    % fn_scatter_compare = [fn_scatter_compare, '_', m1, '_', num2str(length(idx1)),'_', m2, '_', num2str(length(idx2)),'.pdf'];
    fn_scatter_compare = [fn_scatter_compare, '_', names{m}, '_', m1, '_', m2, '.pdf'];
else
    % fn_scatter_compare = [fn_scatter_compare, '_', m1, '_', num2str(length(idx1)),'_', m2, '_', num2str(length(idx2)),'_',m3 , '_', num2str(length(idx3)),'.pdf'];
    fn_scatter_compare = [fn_scatter_compare, '_', names{m}, '_', m1, '_', m2, '_', m3, '.pdf'];
end

set_names = get_scatter_groups(B, n, g1, g2, idx1, idx2, idx3, m, list_names, group_names, fn_scatter_compare, cgID, fid_rep, nimbl_comp_prefix);



%% gene-based comparison

fprintf(1, '\ngene-based comparison...\n');


%% translate original ID lists (2 or 3) into corresponding gene sets

% possible idea: provide gene table output of each ID list

% c1, c2, c3
[g_idx1, ~, ig1] = get_genes(c1, ID_info, cg_info);
[g_idx2, ~, ig2] = get_genes(c2, ID_info, cg_info);


if n==3
    [g_idx3, ~, ig3] = get_genes(c3, ID_info, cg_info);    
else
    g_idx3 = 0;
    ig3 = 0;
end

g_lengths = [length(g_idx1), length(g_idx2), length(g_idx3)];

g_idx_collect_all = zeros(max(g_lengths), 3); 
g_idx_collect_all(1:g_lengths(1),1) = g_idx1;
g_idx_collect_all(1:g_lengths(2),2) = g_idx2;
g_idx_collect_all(1:g_lengths(3),3) = g_idx3;


%% print 2 or 3 translated gene lists to file

print_IDs(g_idx_collect_all, g_lengths, gene_symbols, n, list_names, [nimbl_comp_prefix, '_genes_total.txt']);


%% intersection of gene sets
%  use numeric indices to compute overlaps

% number of possible sets
if n==2
    a = 3;
else
    a = 7;
end

% collect length of each set
set_length = zeros(1,a);

% common among all sets
if n==3
    % common between all elements
    g_idx_all = intersect(intersect(g_idx1,g_idx2), g_idx3);
    set_length(1) = length(g_idx_all);
        
    % 1 & 2 only
    g_idx1_2 = setdiff(intersect(g_idx1,g_idx2),g_idx_all);
    set_length(2) = length(g_idx1_2);
    
    % 1 & 3 only
    g_idx1_3 = setdiff(intersect(g_idx1,g_idx3),g_idx_all);
    set_length(3) = length(g_idx1_3);
        
    % 2 & 3 only
    g_idx2_3 = setdiff(intersect(g_idx2,g_idx3),g_idx_all);
    set_length(4) = length(g_idx2_3);
    
    % 1 only
    g_idx1_0 = setdiff(setdiff(g_idx1, g_idx2), g_idx3);
    set_length(5) = length(g_idx1_0);
        
    % 2 only
    g_idx2_0 = setdiff(setdiff(g_idx2, g_idx1), g_idx3);
    set_length(6) = length(g_idx2_0);
        
    % 3 only
    g_idx3_0 = setdiff(setdiff(g_idx3, g_idx1), g_idx2);
    set_length(7) = length(g_idx3_0);
    
    % combine all indices
    g_idx_collect = zeros(max(set_length), a);    
    g_idx_collect(1:set_length(1),1) = g_idx_all;
    g_idx_collect(1:set_length(2),2) = g_idx1_2;
    g_idx_collect(1:set_length(3),3) = g_idx1_3;
    g_idx_collect(1:set_length(4),4) = g_idx2_3;
    g_idx_collect(1:set_length(5),5) = g_idx1_0;
    g_idx_collect(1:set_length(6),6) = g_idx2_0;
    g_idx_collect(1:set_length(7),7) = g_idx3_0;
    
else
    g_idx_all = intersect(g_idx1,g_idx2); 
    set_length(1) = length(g_idx_all);
    
    % 1 only
    g_idx1_0 = setdiff(g_idx1, g_idx2);
    set_length(2) = length(g_idx1_0);
    
    % 2 only
    g_idx2_0 = setdiff(g_idx2, g_idx1);
    set_length(3) = length(g_idx2_0);
        
    % combine all indices
    g_idx_collect = zeros(max(set_length), a);    
    g_idx_collect(1:set_length(1),1) = g_idx_all;
    g_idx_collect(1:set_length(2),2) = g_idx1_0;
    g_idx_collect(1:set_length(3),3) = g_idx2_0;
    
end



%% print number of overlapping sites to report

% write the original length to report file and the number of intergenic
% sites

fprintf(fid_rep, '\n# Translation into gene lists:\n');
fprintf(fid_rep, 'Set\tsize ID list\tsize gene list\tnumber of intergenic sites\n');
ig_numbers = [ig1, ig2, ig3];
g_idx_length = [length(g_idx1), length(g_idx2), length(g_idx3)];
ori_size = [length(c1), length(c2), length(c3)];

for i=1:n        
    fprintf(fid_rep, '%s\t%u\t%u\t%u\n', list_names{i}, ori_size(i), g_idx_length(i), ig_numbers(i));
end

fprintf(fid_rep, '\n# Overlap between gene lists:\n');
fprintf(fid_rep, 'Set\tsize\n');
for i=1:a    
    fprintf(fid_rep, '%s\t%u\n', set_names{i}, set_length(i));
end


%% print all gene sets to file
%  one column of gene symbols per set

if n==2
    leg = {['overlap all (',num2str(set_length(1)),')'],...
           [set_names{2}, ' (',num2str(set_length(2)),')'],...
           [set_names{3} ,' (',num2str(set_length(3)),')']};    
else
    leg = {['overlap all (',num2str(set_length(1)),')'],...
           [set_names{2},' (',num2str(set_length(2)),')'],...
           [set_names{3},' (',num2str(set_length(3)),')'],...
           [set_names{4},' (',num2str(set_length(4)),')'],...
           [set_names{5},' (',num2str(set_length(5)),')'],...
           [set_names{6},' (',num2str(set_length(6)),')'],...
           [set_names{7},' (',num2str(set_length(7)),')']};    
end

print_IDs(g_idx_collect, set_length, gene_symbols, a, leg, [nimbl_comp_prefix, '_genes.txt']);

fclose(fid_rep);


%% gene table of all genes associated to any sites of the input lists

fprintf(1, 'gene enrichment analysis...\n');

% compute number of total sites within one gene set once
% ID_info contains all sites for which gene annotation is provided
[g_hits_idx_all, g_hits_all, ~] = get_genes(unique(ID_info), ID_info, cg_info);

% sites analysed
% use these numbers for the sites within gene regions, % values are
% calculated based on these
[g_hits_idx_sel, g_hits_sel, ~] = get_genes(cgID, ID_info, cg_info);

% rearrange gene regions in 5' -> 3' order
g_hits_sel = g_hits_sel(:,[1,6,7,4,2,5,3]);

% combine all sites given from the input
if n==2
    diff_sites = union(c1,c2);
else
    diff_sites = union(union(c1,c2), c3);
end

[g_hits_idx_diff, g_hits_diff, ~] = get_genes(diff_sites, ID_info, cg_info);
    
% overlap with original lists (might be filtered by mean or median cut-off) 
d1 = intersect(diff_sites, c1);
d2 = intersect(diff_sites, c2);

% all sites found in total across all methods
%%% d4 = union(d1,d2);

if n==3
    d3 = intersect(diff_sites, c3);
    %%% d4 = union(d3,d4);            
end


% collect length of each set
set_length2 = zeros(1,a);

if n==3
    % common between all elements
    d_all = intersect(intersect(d1,d2), d3);
    set_length2(1) = length(d_all);

    % 1 & 2 only
    d1_2 = setdiff(intersect(d1,d2),d_all);
    set_length2(2) = length(d1_2);

    % 1 & 3 only
    d1_3 = setdiff(intersect(d1,d3),d_all);
    set_length2(3) = length(d1_3);

    % 2 & 3 only
    d2_3 = setdiff(intersect(d2,d3),d_all);
    set_length2(4) = length(d2_3);

    % 1 only
    d1_0 = setdiff(setdiff(d1, d2), d3);
    set_length2(5) = length(d1_0);

    % 2 only
    d2_0 = setdiff(setdiff(d2, d1), d3);
    set_length2(6) = length(d2_0);

    % 3 only
    d3_0 = setdiff(setdiff(d3, d1), d2);
    set_length2(7) = length(d3_0);

    % combine all IDs
    d_collect = cell(max(set_length2), a);

    % isempty check is necessary, otherwise error:
    % "Assignment has more non-singleton rhs dimensions than
    % non-singleton subscripts"

    if ~isempty(d_all)
        d_collect(1:set_length2(1),1) = d_all;
    end            
    if ~isempty(d1_2)
        d_collect(1:set_length2(2),2) = d1_2;
    end
    if ~isempty(d1_3)
        d_collect(1:set_length2(3),3) = d1_3;
    end
    if ~isempty(d2_3)
        d_collect(1:set_length2(4),4) = d2_3;
    end
    if ~isempty(d1_0)
        d_collect(1:set_length2(5),5) = d1_0;
    end
    if ~isempty(d2_0)
        d_collect(1:set_length2(6),6) = d2_0;
    end
    if ~isempty(d3_0)
        d_collect(1:set_length2(7),7) = d3_0;
    end

else
    d_all = intersect(d1,d2); 
    set_length2(1) = length(d_all);

    % 1 only
    d1_0 = setdiff(d1, d2);
    set_length2(2) = length(d1_0);

    % 2 only
    d2_0 = setdiff(d2, d1);
    set_length2(3) = length(d2_0);

    % combine all indices
    d_collect = cell(max(set_length), a);

    if ~isempty(d_all)
        d_collect(1:set_length2(1),1) = d_all;
    end
    if ~isempty(d1_0)
        d_collect(1:set_length2(2),2) = d1_0;
    end
    if ~isempty(d2_0)
        d_collect(1:set_length2(3),3) = d2_0;
    end

end


% comprehensive gene table

    %  1: gene idx
    %  2: # sites on chip
    %  3: # sites excluded
    %  4: # sites analysed
    %  5: # total sites diff. methylated
    %  6: % total diff methylated 

    %%% methods alone
    %  7: # sites diff methylated m1
    %  8: % diff methylated m1 (compared to col5)
    %  9: # sites diff methylated m2
    % 10: % diff methylated m2
    % 11: # sites diff methylated m3
    % 12: % diff methylated m3

    %%% overlap of methods
    % 13: # sites found by m1+m2+m3
    % 14: % diff methylated
    % 15: # sites found by m1+m2
    % 16: % diff methylated
    % 17: # sites found by m1+m3
    % 18: % diff methylated
    % 19: # sites found by m2+m3
    % 20: % diff methylated
    % 21: # sites found by m1
    % 22: % diff methylated
    % 23: # sites found by m2
    % 24: % diff methylated
    % 25: # sites found by m3
    % 26: % diff methylated

    %%% gene regions based on sites found by any method
    % 27: # sites analysed TSS1500
    % 28: # sites found diff methylated
    % 29: % diff methylated for prev. gene region
    % 30: # sites analysed TSS200
    % 31: # sites found diff methylated
    % 32: % diff methylated for prev. gene region
    % 33: # sites analysed 5'UTR
    % 34: # sites found diff methylated
    % 35: % diff methylated for prev. gene region
    % 36: # sites analysed 1st exon
    % 37: # sites found diff methylated
    % 38: % diff methylated for prev. gene region
    % 39: # sites analysed body
    % 40: # sites found diff methylated
    % 41: % diff methylated for prev. gene region
    % 42: # sites analysed 3'UTR
    % 43: # sites found diff methylated
    % 44: % diff methylated for prev. gene region
    % 45: # sites analysed promoter (TSS1500, TSS200, 3'UTR)
    % 46: # sites found diff methylated
    % 47: % diff methylated for prev. gene region


first_cols = 6;
gene_table = zeros(length(g_hits_idx_diff), first_cols + 2*n + 2*a + 3*7);

% gene indices
gene_table(:,1) = g_hits_idx_diff;

%%% 1. sites in total
[~, ~, ib] = intersect(gene_table(:,1), g_hits_idx_all);
gene_table(:,2) = g_hits_all(ib,1); 


%%% 2. sites analysed
% use these numbers for the gene regions

[~, ~, ib] = intersect(gene_table(:,1), g_hits_idx_sel);
gene_table(:,4) = g_hits_sel(ib,1);          

% which columns for gene region information
s1 = first_cols + 2*n + 2*a + 1;
col_greg_total = [s1, s1+3, s1+6, s1+9, s1+12, s1+15, s1+18];
gene_table(:,col_greg_total) = [g_hits_sel(ib,2:end), sum(g_hits_sel(ib,[2,3,4]),2)];


%%% sites excluded
gene_table(:,3) = gene_table(:,2) - gene_table(:,4);


%%% 4. sites within any of the lists related to that gene set,
%%% that is total sites diff. methylated
gene_table(:,5) = g_hits_diff(:,1);

% percent diff methylated in total
gene_table(:,6) = (gene_table(:,5)*100)./gene_table(:,4);

% rearrange gene regions in 5' -> 3' order
% columns in table are alphabetically ordered
g_hits_diff = g_hits_diff(:,[1,6,7,4,2,5,3]);

% save gene region info
s1 = s1+1;
col_greg_diff = [s1, s1+3, s1+6, s1+9, s1+12, s1+15, s1+18];
% include promoter
gene_table(:,col_greg_diff) = [g_hits_diff(:,2:end), sum(g_hits_diff(:,[2,3,4]),2)];


%%% percent of diff methylated sites found in gene regions
s1 = s1+1;
col_greg_perc = [s1, s1+3, s1+6, s1+9, s1+12, s1+15, s1+18];
gene_table(:,col_greg_perc) = (gene_table(:,col_greg_diff).*100) ./ gene_table(:,col_greg_total);


%%% sites within lists, independent of other lists

% m1:
if ~isempty(d1) % for some gene sets this is empty 
        
    [g_hits_idx, g_hits, ~] = get_genes(d1, ID_info, cg_info);
    [~, ia, ib] = intersect(g_hits_idx, gene_table(:,1));
    gene_table(ib,first_cols+1) = g_hits(ia,1); 
        
    % % value
    gene_table(:,first_cols+2) = (gene_table(:,first_cols+1)*100)./gene_table(:,5);
end

% m2:
if ~isempty(d2)
    
    [g_hits_idx, g_hits, ~] = get_genes(d2, ID_info, cg_info);
    [~, ia, ib] = intersect(g_hits_idx, gene_table(:,1));
    gene_table(ib,first_cols+3) = g_hits(ia,1);
    
    % % value
    gene_table(:,first_cols+4) = (gene_table(:,first_cols+3)*100)./gene_table(:,5);
end

% m3:
if n==3            
    if ~isempty(d3)
        
        [g_hits_idx, g_hits, ~] = get_genes(d3, ID_info, cg_info);
        [~, ia, ib] = intersect(g_hits_idx, gene_table(:,1));
        gene_table(ib,first_cols+5) = g_hits(ia,1);  
                
        % % value
        gene_table(:,first_cols+6) = (gene_table(:,first_cols+5)*100)./gene_table(:,5);
    end
end


%%% sites in individual sets (3 or 7 sets)
for j=1:a              

    if set_length2(j) > 0

        [g_hits_idx, g_hits, ~] = get_genes(d_collect(1:set_length2(j),j), ID_info, cg_info);
                
        [~, ia, ib] = intersect(g_hits_idx, gene_table(:,1));
        gene_table(ib, first_cols + 2*n + 2*j - 1) = g_hits(ia,1);
        
        % % value
        gene_table(:,first_cols + 2*n + 2*j) = (gene_table(:,first_cols + 2*n + 2*j - 1)*100) ./ gene_table(:,5);        
    end
end


% replace all NaN with 0
gene_table(isnan(gene_table)) = 0;


% sort gene table by descending order of total sites diff methylated and
% corresponding per cent value
gene_table = sortrows(gene_table, [-5, -6]);


%% write gene table to file

gtable_name = [nimbl_comp_prefix, '_gene_table.txt'];
fid_gtable = fopen(gtable_name,'w');

% header
header = '';
header = [header,'gene symbol\tsites on array\tsites excluded\tsites analysed\ttotal sites diff methyl\t%%\t']; 

for j=1:n
    header = [header, 'sites diff methyl ',list_names{j},'\t%%\t'];
end

for j=1:a
    header = [header, 'sites in ',set_names{j},'\t%%\t']; 
end

gene_regions = {'TSS1500', 'TSS200', '5''UTR', '1st Exon', 'Body', '3''UTR'};

for j=1:length(gene_regions)
    header = [header, 'sites ', gene_regions{j},'\tsites diff methyl\t%%\t'];
end
% promoter: TSS1500+TSS200+5'UTR
header = [header, 'sites promoter\tsites diff methyl\t%%\n'];

% print header
fprintf(fid_gtable, header);


gtable_format1 = repmat('%u\t',1,first_cols-2);
gtable_format2 = repmat('%u\t%4.3f\t',1,n);
gtable_format3 = repmat('%u\t%4.3f\t',1,a);
gtable_format4 = repmat('%u\t%u\t%4.3f\t',1,6);

gtable_format_all = ['%s\t', gtable_format1, '%4.3f\t' gtable_format2, gtable_format3, gtable_format4, '%u\t%u\t%4.3f\n'];

for j=1:size(gene_table,1)
    fprintf(fid_gtable, gtable_format_all, gene_symbols{gene_table(j,1)}, gene_table(j,2:end));
end        

fclose(fid_gtable);


%% write gene tables of genes that are unique for each set

if gene_table_sep
    
    for i=1:a

        if set_length(i) > 0 % at least one gene within gene set

            gtable_name = horzcat(nimbl_comp_prefix, '_gene_table_',set_names{i},'.txt');
            fid_gtable = fopen(gtable_name,'w');

            % header
            fprintf(fid_gtable, header);
            
            % find genes specific for this set
            [~,~,ib] = intersect(g_idx_collect(1:set_length(i),i), gene_table(:,1));
            
            % sort gene table according to diff methylated sites
            gene_table_sorted = sortrows(gene_table(ib,:),[-5,-6]);
            
            for j=1:length(ib)
                % fprintf(fid_gtable, gtable_format_all, gene_symbols{gene_table(ib(j),1)}, gene_table(ib(j),2:end));
                fprintf(fid_gtable, gtable_format_all, gene_symbols{gene_table_sorted(j,1)}, gene_table_sorted(j,2:end));
            end        

            fclose(fid_gtable);
        end
    end
end
 

end


function idx = get_ori_pos2(ID, ID_all)


% all IDs in orginal list
[~, idx1, idx2] = intersect(ID, ID_all);

% keep original order of probes as in ID list
idx = zeros(length(ID),1);
idx(idx1) = idx2;

end


function overview = get_stats_groups(beta_all, g1, g2)

% collect mean and median information for two groups 

%  - 1: mean group 1
%  - 2: mean group 2
%  - 3: absolute mean difference group 1 vs 2
%  - 4: median group 1
%  - 5: median group 2
%  - 6: absolute median difference group 1 vs 2
%  - 7: 1-flag if NaN value given for CpG site

%% compute statistics for one grouping
    
overview = zeros(size(beta_all,1), 8);

b1 = beta_all(:,g1);
b2 = beta_all(:,g2);

% mean
m1 = nanmean(b1, 2);
m2 = nanmean(b2, 2);

% m1 = geomean(b1, 2);
% m2 = geomean(b2, 2);

overview(:,1) = m1;
overview(:,2) = m2;
overview(:,3) = abs(m1-m2);


% median for the rest of calculations
m1 = nanmedian(b1, 2);
m2 = nanmedian(b2, 2);

overview(:,4) = m1;
overview(:,5) = m2;


% report absolute difference
overview(:,6) = abs(m1 - m2);

% report if at least one sample has no beta value given
overview(:,7) = any(isnan(beta_all),2);


% check if m1 > m2
overview(:,8) = overview(:,6) > 0;


end


function set_names = get_scatter_groups(beta_all, n, g1, g2, idx1, idx2, idx3, m, list_names, group_names, file_name, cgID, fid_rep, prefix)

% highlight every methylation site of two or three input lists in scatter
% plot comparing two groups based on their mean oder median difference
% overlapping and unique sites within the lists are highlighted with a
% different color
%
% - 2 lists as input -> 3 sets in total
% - 3 lists as input -> 7 sets in total


% columns of mean or median of group1 and group2 in stats_overview table
% m: mean (1) or median (2) 
cols = [1,2;4,5];
col = cols(m,:);


%% intersections
%  use numeric indices to compute overlaps

% number of possible sets
if n==2
    a = 3;
else
    a = 7;
end

% collect length of each set
set_length = zeros(1,a);

% common among all sets
if n==3
    % common between all elements
    idx_all = intersect(intersect(idx1,idx2), idx3);
    set_length(1) = length(idx_all);
        
    % 1 & 2 only
    idx1_2 = setdiff(intersect(idx1,idx2),idx_all);
    set_length(2) = length(idx1_2);
    
    % 1 & 3 only
    idx1_3 = setdiff(intersect(idx1,idx3),idx_all);
    set_length(3) = length(idx1_3);
        
    % 2 & 3 only
    idx2_3 = setdiff(intersect(idx2,idx3),idx_all);
    set_length(4) = length(idx2_3);
    
    % 1 only
    idx1_0 = setdiff(setdiff(idx1, idx2), idx3);
    set_length(5) = length(idx1_0);
        
    % 2 only
    idx2_0 = setdiff(setdiff(idx2, idx1), idx3);
    set_length(6) = length(idx2_0);
        
    % 3 only
    idx3_0 = setdiff(setdiff(idx3, idx1), idx2);
    set_length(7) = length(idx3_0);
    
    % combine all indices
    idx_collect = zeros(max(set_length), a);    
    idx_collect(1:set_length(1),1) = idx_all;
    idx_collect(1:set_length(2),2) = idx1_2;
    idx_collect(1:set_length(3),3) = idx1_3;
    idx_collect(1:set_length(4),4) = idx2_3;
    idx_collect(1:set_length(5),5) = idx1_0;
    idx_collect(1:set_length(6),6) = idx2_0;
    idx_collect(1:set_length(7),7) = idx3_0;
    
else
    idx_all = intersect(idx1,idx2); 
    set_length(1) = length(idx_all);
    
    % 1 only
    idx1_0 = setdiff(idx1, idx2);
    set_length(2) = length(idx1_0);
    
    % 2 only
    idx2_0 = setdiff(idx2, idx1);
    set_length(3) = length(idx2_0);
        
    % combine all indices
    idx_collect = zeros(max(set_length), a);    
    idx_collect(1:set_length(1),1) = idx_all;
    idx_collect(1:set_length(2),2) = idx1_0;
    idx_collect(1:set_length(3),3) = idx2_0;
    
end


% corresponding set names (combine list names)
if n==2
    set_names = {[list_names{1},'+',list_names{2}], list_names{1}, list_names{2}};    
else
    set_names = {[list_names{1},'+',list_names{2},'+',list_names{3}],...
                [list_names{1},'+',list_names{2}],...
                [list_names{1},'+',list_names{3}],...
                [list_names{2},'+',list_names{3}],...
                list_names{1}, list_names{2}, list_names{3}};
end


% store info for legend
handles_all = zeros(1,a);

% color code of each set
if n==2
    % 3 colors if two sets are compared
    color = {'black', 'red', 'blue'};
else % 7 colors if two sets are compared
    color = {'black','red','blue','green','cyan','yellow','magenta'};
end


%% scatter plot

figure('visible','off');


% plot constant boundaries for orientation
line([0.1,0.2,0.3,0.4,0.5,0.6; 1,1,1,1,1,1], [0,0,0,0,0,0; 0.9,0.8,0.7,0.6,0.5,0.4], 'Color','black')
hold on
line([0,0,0,0,0,0; 0.9,0.8,0.7,0.6,0.5,0.4], [0.1,0.2,0.3,0.4,0.5,0.6; 1,1,1,1,1,1], 'Color','black')


%%% test_idx = 1:a;

% plot largest set first
[~, IX] = sort(set_length, 'descend');


for i=1:a
        
    %%% stats = get_stats_groups(beta_all(nonzeros(idx_collect(:,i)),:), g1, g2);
    %%% handles_all(i) = scatter(stats(:,col(1)), stats(:,col(2)), 'filled', 'MarkerFaceColor', color{i});
    
    
    stats = get_stats_groups(beta_all(nonzeros(idx_collect(:,IX(i))),:), g1, g2);
    handles_all(IX(i)) = scatter(stats(:,col(1)), stats(:,col(2)), 'filled', 'MarkerFaceColor', color{IX(i)});
    
    
    hold on
    
    
    
    % possibly quicker: dlmwrite
    %%% print_stats(fid, stats(:, [col(1), col(2)]), i);
    
end

hold off
%%% fclose(fid);


%% plot settings


% legend
if n==2
    leg = {['overlap all (',num2str(set_length(1)),')'],...
           [set_names{2}, ' (',num2str(set_length(2)),')'],...
           [set_names{3} ,' (',num2str(set_length(3)),')']};
    % legend_h = legend(handles_all,  {['overlap (',num2str(set_length(1)),')'] , [set_names{1}, ' (',num2str(set_length(2)),')'], [set_names{2} ,' (',num2str(set_length(3)),')']}, 'Location', 'NorthEastOutside');    
else
    %{
    leg = {['overlap all (',num2str(set_length(1)),')'],...
           [set_names{2},' (',num2str(set_length(2)),')'],...
           [set_names{3},' (',num2str(set_length(3)),')'],...
           [set_names{4},' (',num2str(set_length(4)),')'],...
           [set_names{5},' (',num2str(set_length(5)),')'],...
           [set_names{6},' (',num2str(set_length(6)),')'],...
           [set_names{7},' (',num2str(set_length(7)),')']};           
      %}
    
       leg = {[set_names{1}, ' (',num2str(set_length(1)),')'],...
           [set_names{2},' (',num2str(set_length(2)),')'],...
           [set_names{3},' (',num2str(set_length(3)),')'],...
           [set_names{4},' (',num2str(set_length(4)),')'],...
           [set_names{5},' (',num2str(set_length(5)),')'],...
           [set_names{6},' (',num2str(set_length(6)),')'],...
           [set_names{7},' (',num2str(set_length(7)),')']};    
       
end

legend_h = legend(handles_all, leg, 'Location', 'NorthEastOutside');
set(legend_h, 'Interpreter','none')


% axes limits
xlim([0 1]) 
ylim([0 1])

set(gca,'YGrid','on')

set(gca, 'FontSize', 17);

% axes labels
names = {'mean', 'median'};
xlabel(gca, [names{m}, ' beta value: ', group_names{1}])
ylabel(gca, [names{m}, ' beta value: ', group_names{2}])

%%% title(plot_title);


%% save as PDF

set(gcf, 'PaperUnits', 'centimeters');
set(gcf, 'PaperType','A4','PaperOrientation','landscape');

% set(gcf, 'PaperPosition', [0 0 29 20]);
% set(gcf, 'PaperPosition', [-4 -1 37 21]);
set(gcf, 'PaperPosition', [-2 0 34.5 20]);

saveas(gcf,file_name)

close all


%% print number of overlapping sites to report

fprintf(fid_rep, '\n# Overlap between ID lists:\n');
fprintf(fid_rep, 'Set\tsize\n');
for i=1:a
    fprintf(fid_rep, '%s\n', regexprep(leg{i}, ' \((.*)\)$', '\t$1'));
end


%% print identifiers of all sets to file
%  one column of IDs per set (3 or 7 sets in total)

print_IDs(idx_collect, set_length, cgID, a, leg, [prefix, '_IDs.txt']);



end

function print_stats(fid, data, set_number)

% format string
format = '%11.9f\t%11.9f\t%u\n';

for i=1:size(data,1)
    fprintf(fid, format, data(i,:), set_number);
end

end


function print_IDs(idx_collect, set_length, cgID, a, leg, filename)

% format string
format = repmat('%s\t', 1, a);
format = regexprep(format, 't$', 'n');

m = max(set_length);

% some cells are empty because lists and overlaps have different lengths
cgID_print = cell(m,a);

for i=1:a    
    cgID_print(1:set_length(i),i) = cgID(nonzeros(idx_collect(:,i)));
end

fid = fopen(filename, 'w');

% print header (names of sets and number of elements)
header_format = repmat('%s\t',1,a-1);
header_format = [header_format,'%s\n'];
fprintf(fid, header_format, leg{1:a});

for i=1:m
    fprintf(fid, format, cgID_print{i,:});
end

fclose(fid);

end







