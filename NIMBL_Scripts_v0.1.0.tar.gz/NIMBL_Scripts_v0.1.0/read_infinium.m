function [sample_names, pval_all, beta_all, signals, cgID_input] = read_infinium(input_file, del, sample_del, sample_pos)

% [sample_names, pval_all, beta_all, signals, cgID_input] = read_infinium(input_file, del, sample_del, sample_pos)
%
% Read methylation dataset and quality control of samples
%
% IN:
% - input_file: (string) methylation data file name
% - del: (string) delimiter used in methylation file
% - sample_del: (string) delimiter used to seperate sample name in header
% - sample_pos: (integer) 1 - sample name before del, 2 - name after del
%
% OUT:
% - sample_names: cell array with detected sample names from header info
% - pval_all: matrix of detection pvalues of all samples
% - beta_all: matrix of beta values of all samples
% - signals: matrix of signals (signalA, signalB, sum) of all samples if
%   given as input
% - cgID_input: all unique probe identifiers of input file (cg..., rs..., ch....)



%%%%%%
% avoid re-reading of methylation input file
% re-reading is checked by file name, so if the user changes the input file
% during a MATLAB session the old data will be used

persistent D;
persistent INPUT_METH_FILE;
%%%%%%



%% variables 

% constant used in formula for beta value calculation (default=100) if beta
% values are computed from input signal values
offset = 100;


%% regular expressions for sample columns

% p value
c_pval = 'p(\s|-)?val';
% c_pval = 'detection pval';

% beta value
c_beta = 'beta';

% signal A (unmethylated)
% c_sig1 = 'signal.?a|unmethylated';
c_sig1 = 'signal.?a';

% signal B (methylated)
% c_sig2 = 'signal.?b|(?<!un)methylated';
c_sig2 = 'signal.?b';


%% read methylation data

% NOTE: numerical values are on the right-hand side (D.data)
% missing numeric values in D.data: converted to NaN
% D.textdata: first row + cgIDs (or maybe other annotation) on left-hand side
        
fprintf(1, '\n# Methylation data:\n');

% import methylation data only if new input file is provided by the same or another input script
% if isempty(D)
if ~strcmp(input_file, INPUT_METH_FILE)
        
    fprintf(1, '- Importing data from: %s ... ',input_file);
    tic;
    D = importdata(input_file, del);
    
    fprintf(1, 'done\n');    
    toc;
    
    % reset persistent variable with latest input file
    INPUT_METH_FILE = input_file;
    
else
    fprintf(1, '- Use dataset again from: %s\n',input_file);
end
    

% if only one extra column of strings: delete first column with cgIDs
% header_s = D.textdata(1, 2:end);

% potentially several first columns with strings before numerical data
header_s = D.textdata(1, size(D.textdata,2)-size(D.data,2)+1 : end);


%% column index for cgIDs

% regular expression to search for cgID column
% besides CpG sites (ID: "cg...") there can be for 450k array:
% 3091 non-CpG sites, ID: "ch.[chr number].number"
% 65 random SNPs, ID: "rs[number]" 
% c_cgID = '^cg[0-9]{8}$';
c_cgID = '^cg[0-9]{8}$|^ch\.([0-9]*|X)\.|^rs[0-9]*';

% check second row in textdata matrix
cgID_idx = find(not(cellfun(@isempty, regexpi(D.textdata(2,:),c_cgID))));

% if multiple hits for different columns - take first column
if length(cgID_idx) > 1
    cgID_idx = cgID_idx(1);
end

cgID_input = D.textdata(2:end, cgID_idx);


%% pvals

pval_idx = not(cellfun(@isempty, regexpi(header_s,c_pval)));
pval_all = D.data(:,pval_idx);


%% Beta-values

beta_idx = not(cellfun(@isempty, regexpi(header_s,c_beta)));

% test if no beta values are given within input file
% if so, beta values need to be computed from signals

if any(beta_idx)
    beta_all = D.data(:,beta_idx);
    
    % verification: check if dimensions are the same
    if (size(pval_all,2) ~= size(beta_all,2))
        error('Beta-value and P-value sample numbers inconsistent');
    end
    
    beta_miss = 0;
    fprintf(1, '- Beta-values given as input\n');
        
    % stats about missing beta values
    % miss_beta_vs_pval(beta_all, pval_all);    
    
else % remember to calculate beta values from unmeth and meth signals   
    beta_miss = 1;
    fprintf(1, '- Beta-values calculated from signals\n');
end


%% signals and intensities

sig_idx = not(cellfun(@isempty, regexpi(header_s,[c_sig1, '|' c_sig2])));

if any(sig_idx)    
    
    % store signals and intensities
    % 3rd dim for samples
    signals = zeros(size(pval_all,1), 3, size(pval_all,2));
        
    %  unmethylated signal
    sigA_idx = not(cellfun(@isempty, regexpi(header_s,c_sig1)));
    signals(:,1,:) = D.data(:, sigA_idx);
        
    % methylated signal
    sigB_idx = not(cellfun(@isempty, regexpi(header_s,c_sig2)));
    if sum(sigA_idx) ~= sum(sigB_idx)
        error('not the same number of columns for unmethylated and methylated signals, check methalytion data file or regular expression used to detect signals in header')
    end
    signals(:,2,:) = D.data(:, sigB_idx);    
    
    % intensity = sum of signals    
    signals(:,3,:) = signals(:,1,:) + signals(:,2,:);
else
    signals = 0;
end


%% beta value calculation

if beta_miss    
    beta_all = squeeze(signals(:,2,:) ./ (signals(:,1,:) + signals(:,2,:) + offset));
end


%% sample names: use columns of detection pvalue of each sample

% check if dot is used as delimiter
if strcmp(sample_del, '.')
    sample_del = '\.';
end

sample_names = regexp(header_s(pval_idx)', sample_del, 'split');

sample_names = vertcat(sample_names{:});
sample_names = sample_names(:,sample_pos)';

% consistency check
if length(sample_names) ~= size(pval_all)
    error('number of sample names not consistent with number of Beta-value columns')    
end


%% Display short summary on screen

fprintf(1, '- Number of identified samples: %u\n', size(pval_all,2));
fprintf(1, '- Number of measurements per sample: %u\n', size(pval_all,1));

end

