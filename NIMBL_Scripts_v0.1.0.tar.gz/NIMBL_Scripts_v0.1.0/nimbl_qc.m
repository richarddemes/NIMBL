function nimbl_qc(input_script)

% nimbl_qc(input_script)
% 
% module: performs basic quality control of samples
% 
% IN:
% - input_script = script name of user specified settings e.g.
%   nimbl_qc('my_analysis')
% 
% OUT:
% - report file
% - PDF files:
%   - histogram of low quality measurements per sample
%   - percent of low quality measurements per sample
%   - histogram of missing beta values per sample
%   - beta value distributions of type I vs type II before/after peak
%     correction


% version
nimbl_version = 'v0.1.0';

fprintf(1, '\nNIMBL-qc module (%s):\n-------------------------\n', nimbl_version);


%% include user-defined input

eval(input_script);

% nimbl_qc report
fid_rep = fopen([nimbl_qc_prefix, '_report.txt'], 'w');

% extra annot file: specifies for each array site the design type
design_type_annot_file = '450k_annot_design_type.txt';



%% read methylation data

[sample_names, pval_all, beta_all, ~, cgID_input] = read_infinium(input_file, input_del, sample_del, sample_pos);


%% report all samples from input

fprintf(fid_rep, 'NIMBL quality control report (%s)\n\n', nimbl_version);
fprintf(fid_rep, '# Methylation input file:\t%s\n', input_file);
fprintf(fid_rep, 'Total number of sites per sample:\t%u\n\n', size(beta_all,1));

fprintf(fid_rep, 'Sample index\tSample name\n');
for i=1:size(beta_all,2)
    fprintf(fid_rep, '%u\t%s\n', i, sample_names{i});
end


%% read reduced set of annotation data necessary for peak-based correction
%  - it could also be read from annotation file
%  - input can be filtered dataset, so ensure compatbility of methylation
%    input and design type information

if any(peak_correct) && platform == 2
    
    D = importdata(design_type_annot_file);
    probe_annot = D.textdata(2:end,1);
    
    test_input = false;
    % test if complete dataset (all CpG sites are loaded)
    if length(probe_annot) ~= length(cgID_input)
        test_input = true;
    % if same length, check if identical at every position    
    elseif (sum(strcmp(probe_annot, cgID_input)) ~= length(probe_annot))
        test_input = true;
    else % array sites of annot file and input data are the same and in same order        
        inf_type = D.data;
    end
    
    
    % annotation file has different number or order of array sites
    % so make the two input files compatible 
    if test_input

        [test_intersect, ia, ib] = intersect(cgID_input, probe_annot);           

        % test if each input array site has a corresponding annotation row    
        if (length(test_intersect) ~= length(cgID_input))

            fprintf(1, '\nWARNING: Input file and annotation file (%s) are not compatible!\n', design_type_annot_file);
            fprintf(1, 'These are the first entries of the lists of identifiers compared:\n');
            fprintf(1, '- input file: %s (%u entries in total in input file)\n', cgID_input{1}, length(cgID_input));
            fprintf(1, '- extra annot file: %s (%u entries in total in annotation file)\n', probe_annot{1}, length(probe_annot));
            error('Some cgIDs of input file have no corresponding entry in extra annotation file!')

        else
            % re-arrange input and annot data so that the size and order is
            % the same
            
            fprintf(1, '\nrearrange rows of methylation data file and additional annotation file ...\n');
            
            % methylation data
            pval_all = pval_all(ia,:);
            beta_all = beta_all(ia,:);
            
            % only needed if corrected values are printed
            cgID_input = cgID_input(ia);
            
            % Infinium design type 
            inf_type = D.data(ib);            
        end    
    end
end   


%% exclude samples from QC

nbr = size(beta_all,2);
% keep original sample number
sample_idx = 1:nbr;

if qc_ex == 1
    
    sample_ex = unique(sample_ex);
    
    % samples for exclusion can still be specified
    if ~isempty(sample_ex) && all(sample_ex ~= 0)
           
        fprintf(1, '\n- Samples excluded from quality control:\n');
        fprintf(fid_rep, '\n# Samples excluded from quality control\n');
        fprintf(fid_rep, 'Sample index\tSample name\n');
        
        for i=1:length(sample_ex)
            fprintf(1, '- %u:\t%s\n', sample_ex(i), sample_names{sample_ex(i)});
            fprintf(fid_rep, '%u\t%s\n', sample_ex(i), sample_names{sample_ex(i)});
        end       
        
        % peak correction was specified for every sample individually
        if length(peak_correct) == size(beta_all,2)
            peak_correct(sample_ex) = [];
        end
        
        % sample_names(sample_ex) = [];   
        pval_all(:,sample_ex) = [];
        beta_all(:,sample_ex) = [];
        sample_idx(sample_ex) = [];
        sample_names(sample_ex) = [];
        
    end
else % do not exclude any samples for QC
    sample_ex = 0;
end

% escape underscores within name with backslashes for plots
% sample_names_print = regexprep(sample_names, '_','\\_');

% modify sample names: incorporate original sample index
% helps to identify specific samples in plots
%{
for i=1:size(beta_all,2)
    sample_names_print{i} = [num2str(sample_idx(i)), ' ',sample_names_print{i}];
end
%}

%% QC procedure

fprintf(1, '\n# Quality control of %u samples... \n', size(beta_all, 2));


%% QC based on detection pvalues

a = pval_all > pval_cut_s;

% total number of high pvalues
hp = sum(a,1);

% sample_ex is needed in cases many samples are plotted and the xlabels
% need to be adjusted because not every index is used
get_hist(hp', horzcat('Number of array sites with high P-value (cut-off = ', num2str(pval_cut_s), ')'), [nimbl_qc_prefix, '_pval_total.pdf'], sample_idx, sample_ex);


% percent of high pvalues
hp2 = sum(a,1) * 100 / size(a,1);

get_hist(hp2', horzcat('Percent of array sites with high P-value (cut-off = ', num2str(pval_cut_s), ')'), [nimbl_qc_prefix, '_pval_percent.pdf'], sample_idx, sample_ex);


%% missing beta-values across samples

% based on beta-value matrix
a = isnan(beta_all);
%%% miss_beta = find(any(a,2));
miss_beta = sum(a);

% print values to report file

fprintf(fid_rep, '\n# Global quality control of samples\n');

fprintf(fid_rep, 'Sample index\tMissing beta values\tSites with detection P-value > %3.2f\t%% value\n', pval_cut_s);

for i=1:length(sample_idx)    
    fprintf(fid_rep, '%u\t%u\t%u\t%3.2f\n', sample_idx(i), miss_beta(i), hp(i), hp2(i));
end


fprintf(fid_rep, '\n# Missing Beta-value statistics\n');
if (any(any(a)))
    
    % overview plot
    % get_hist(sum(a)', 'Number of missing Beta-values', [nimbl_qc_prefix, '_miss_beta.pdf'], sample_idx, sample_ex);   
    get_hist(miss_beta', 'Number of missing Beta-values', [nimbl_qc_prefix, '_miss_beta.pdf'], sample_idx, sample_ex);   

    % stats about missing beta values
    %%% miss_beta_vs_pval(beta_all, pval_all);
   
    % position of missing beta values
    miss_pos = isnan(beta_all);    
    m = sum(sum(miss_pos));

    % associated p-values
    miss_pvals = pval_all(miss_pos);    

    % Output    
    fprintf(fid_rep, 'Associated P-value\tnumber of missing beta values\tpercent value\n');
    fprintf(fid_rep, 'total\t%u\t%u\n', m, 100);

    mp = sum(miss_pvals > 0.05);
    fprintf(fid_rep, '> 0.05\t%u\t%3.2f\n', mp, mp*100/m);
    mp = sum(miss_pvals > 0.01);
    fprintf(fid_rep, '> 0.01\t%u\t%3.2f\n\n', mp, mp*100/m);
    
    fprintf(fid_rep, 'Number of missing beta values\tnumber of array sites\tpercent value\n');
    m_cpg_all = sum(sum(miss_pos,2) >= 1);
    fprintf(fid_rep, '>= 1\t%u\t%u\n', m_cpg_all, 100);
    m_cpg_one = sum(sum(miss_pos,2) == 1);
    fprintf(fid_rep, '=1\t%u\t%3.2f\n', m_cpg_one, m_cpg_one*100/m_cpg_all);   
   
else
    fprintf(fid_rep, '\nNo Beta-values missing\n');   
end
       


%% beta value distribution of all CpG sites for every sample

if (kde_test)    
    % get_beta_kde(beta_all, [nimbl_qc_prefix, '_beta_distribution.pdf'], sample_names_print, 0);
    
    % use sample idx instead of names, legend requires cell array of strings    
    get_beta_kde(beta_all, [nimbl_qc_prefix, '_beta_distribution.pdf'], arrayfun(@num2str, sample_idx, 'UniformOutput', 0), 0);      
end


%% peak-based correction
%  - for this QC module only to check the output plots
%  - corrected beta values are not saved at this stage!

if any(peak_correct) && platform == 2
    beta_all_corrected = peak_based_correction(beta_all, sample_idx, logical(inf_type), peak_correct, 1, peak_correct_detail, nimbl_qc_prefix, fid_rep);
end


%% print peak-based corrected beta values to a file
%  - use the same name as input file with suffix
%  - only samples are printed that were not excluded within the module

if any(peak_correct) && peak_correct_write
    
    % filename based on input filename:
    out_file = regexprep(input_file, '(.*)\.(.*)', '$1_NIMBL_peak_corrected.$2');

    % test if no '.' within filename, then strings are identical
    % just add the prefix at the end
    if strcmp(input_file, out_file)
        out_file = [input_file, '_NIMBL_peak_corrected.txt'];
    end  

    fid_out = fopen(out_file, 'w');

    % beta values: append prefix
    names_b = regexprep(sample_names, '(.*)', horzcat('$1', sample_del, 'BetaPeakCorrected'));
    d_beta = repmat('%11.9f\t', 1, size(beta_all,2));
    
    % header format
    d_header = repmat('%s\t',1, (peak_correct_write *size(sample_names,2))+1);
    d_header = [d_header(1:end-1), 'n'];
        
    % print also pvals
    if peak_correct_write == 2
        
        fprintf(1, '\n- Writing peak-based corrected beta values and P-values for %u samples and %u array sites to: %s ...', length(sample_names), size(beta_all,1), out_file);
        
        % pvals: append prefix 
        names_p = regexprep(sample_names, '(.*)', horzcat('$1', sample_del, 'Pval'));
        d_pval = repmat('%E\t',1,size(beta_all,2));

        % format for values
        d_values = ['%s\t', d_beta, d_pval(1:end-2), '\n'];
        
        % print header    
        fprintf(fid_out, d_header, 'TargetID', names_b{:}, names_p{:});

        % print corected beta values and pvals
        for i=1:size(beta_all,1)
            fprintf(fid_out, d_values, cgID_input{i}, beta_all_corrected(i,:), pval_all(i,:));
        end
    else % only corrected beta values
        
        fprintf(1, '\n- Writing peak-based corrected beta values for %u samples and %u array sites to: %s ...', length(sample_names), size(beta_all,1), out_file);
        
        % format for values
        d_values = ['%s\t', d_beta(1:end-2), '\n'];
        
        % print header    
        fprintf(fid_out, d_header, 'TargetID', names_b{:});

        % print corected beta values
        for i=1:size(beta_all,1)
            fprintf(fid_out, d_values, cgID_input{i}, beta_all_corrected(i,:));
        end
    end
    
    fclose(fid_out);
    fprintf(1, ' done\n');
end


%% KS-test (Kolmogorov-Smirnov test for two samples)

% test if only a small input dataset was loaded
% arbitrary cut-off: 5000
if size(beta_all,1) < 5000
    fprintf(1, '- skip Kolmogorov-Smirnov test due to small number of measurements (%u)\n', size(beta_all,1));
else
    ks_test(beta_all, sample_idx, platform, fid_rep, nimbl_qc_prefix); 
end

fclose(fid_rep);

end