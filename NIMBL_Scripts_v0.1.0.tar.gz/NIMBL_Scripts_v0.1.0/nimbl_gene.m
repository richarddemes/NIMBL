function [collect_names, collect_coords] = nimbl_gene(input_script)

% nimbl_gene(input_script)
% 
% module: methylation profile of user defined genes or chromosomal regions  
% 
% IN:
% - input_script = script name of user specified settings e.g.
%   nimbl('my_analysis'); 
% 
% OUT:
% - ...

% version
nimbl_version = 'v0.1.0';

fprintf(1, '\nNIMBL-gene module (%s):\n---------------------------\n', nimbl_version);

%% include user-defined input

eval(input_script);

%%%%%%%%%%%%%%%%
if platform == 1
    error('NIMBL-gene currently only works for 450k array data.');
end
%%%%%%%%%%%%%%%%


%% extra bases
% added to the ends of the final genomic sequence to ensure a
% complete alignment of probes close to the edge
extra_bases = 50;


%% nimbl gene report

fid_rep = fopen([nimbl_gene_prefix, '_report.txt'], 'w');

fprintf(fid_rep, 'NIMBL gene report (%s)\n\n', nimbl_version);


%% read methylation data

% do not consider signals
[sample_names, pval_all, beta_all, ~, cgID_input] = read_infinium(input_file, input_del, sample_del, sample_pos);


% report info about methylation input file
fprintf(fid_rep, '# Methylation input file:\t%s\n', input_file);
fprintf(fid_rep, 'Total number of array sites per sample:\t%u\n\n', size(beta_all,1));

fprintf(fid_rep, 'Sample index\tSample name\n');
for i=1:size(beta_all,2)
    fprintf(fid_rep, '%u\t%s\n', i, sample_names{i});
end

%% which samples in which groups
%  - user can specify more than two groups for this module

% original sample index/number
ori_idx = 1:size(beta_all,2);

% one vector with each sample in a specific group or not in any group
groups_all = zeros(1,size(beta_all,2));

% loop test variable
test_end = true;

% group index, assume that groups start with index 1 (g1)
% - group indices must be continuous g1,g2,g3, ...
% - groups can be empty (g3=[])
g_idx = 1;

while test_end    
    if exist(['g', num2str(g_idx)], 'var')
        groups_all(eval(['g', num2str(g_idx)])) = g_idx;
        g_idx = g_idx + 1;        
    else
        test_end = false;
    end
end

% number of specified groups (g1, g2, g3, ... , gm)
% some groups might be empty
m = g_idx - 1;

% test if also so many group names are provided
if m ~= length(group_names)
    fprintf(1, 'WARNING: Number of specfied groups (%u) and group names (%u) are not consistent.\n', m, length(group_names));    
end


%% exclude any samples (e.g. due to low quality)

fprintf(1, '\n# Exclusion of samples: \n');

sample_ex = unique(sample_ex);

if isempty(sample_ex) || all(sample_ex==0)
    fprintf(1, '- No samples excluded from dataset\n');          
else
    fprintf(1, '- Samples excluded from dataset:\n');
    fprintf(fid_rep, '\n# Samples excluded from methylation analysis\n');
    fprintf(fid_rep, 'Sample index\tSample name\n');
    

    % print excluded sample names
    for i=1:length(sample_ex)
        fprintf(1, '- %u: %s\n', sample_ex(i), sample_names{sample_ex(i)});
        fprintf(fid_rep, '%u\t%s\n', sample_ex(i), sample_names{sample_ex(i)});
    end          
    fprintf(1, '\n');
    
    % delete sample names
    sample_names(sample_ex) = [];
        
    % delete samples in pvals, betas, peak_correct
    if length(peak_correct) == size(beta_all,2)
        peak_correct(sample_ex) = [];
    end
    
    pval_all(:,sample_ex) = [];
    beta_all(:,sample_ex) = [];
    groups_all(sample_ex) = [];
    ori_idx(sample_ex) = [];
end


%% report samples of each group
%  - after optional exclusion of samples
%  - NIMBL-gene allows to plot more than 2 groups

% report table with groups vs samples
% 4 columns
% - 1: group idx
% - 2: group name
% - 3: original sample idx
% - 4: sample name

fprintf(fid_rep, '\n# Groups plotted\n');
% header
fprintf(fid_rep, 'Group index\tGroup name\tOriginal sample index\tSample name\n');

for i=1:m    
    % all samples of group i
    % this could be empty because group is masked (e.g. g2=[]), or all
    % samples within this group are excluded from analysis (via sample_ex)
    g_idx = find(groups_all == i);
    
    for j=1:length(g_idx)
        fprintf(fid_rep, '%u\t%s\t%u\t%s\n', i, group_names{i}, ori_idx(g_idx(j)), sample_names{g_idx(j)});
    end
end


%% read annotation data

[probe_annot, header, cgID_col, type_col, read_annot_file] = read_annotation(annot_file, input_del, platform);

% report info about annotation file
fprintf(fid_rep, '\n# Annotation input file:\t%s\n', read_annot_file);
fprintf(fid_rep, 'Total number of entries:\t%u\n', size(probe_annot, 1));


%% ensure compatibility of methylation input and annotation input

test_input = false;

% test if complete dataset given (all CpG sites are loaded)
if length(probe_annot(:,cgID_col)) ~= length(cgID_input)
    test_input = true;
% if same length, check if identical at every position    
elseif (sum(strcmp(probe_annot(:,cgID_col),cgID_input)) ~= length(probe_annot(:,cgID_col)))
    test_input = true;
end

% annotation file has different number or order of array sites
% so make the two input files compatible 
if test_input
    
    fprintf(1, '\n# Re-arrange methylation and annotation input data ...\n');
    
    % this can take a while:
    [test_intersect, ia, ib] = intersect(cgID_input, probe_annot(:,cgID_col));           
         
    % test if each input array site has a corresponding annotation row    
    if (length(test_intersect) ~= length(cgID_input))
        
        fprintf(1, '\n --- Input file and annotation file not compatible ---\n');
        fprintf(1, '- These are the first entries of the lists of identifiers compared:\n');
        fprintf(1, '- input file: %s (%u entries in total in input file)\n', cgID_input{1}, length(cgID_input));
        fprintf(1, '- annot file: %s (%u entries in total in annotation file)\n', probe_annot{1,cgID_col}, length(probe_annot(:,cgID_col)));
        error('Some cgIDs of input file have no corresponding entry in annotation file.')
        
    else
        % re-arrange input and annot data so that the size and order is the
        % same
                
        % methylation data
        pval_all = pval_all(ia,:);
        beta_all = beta_all(ia,:);
                        
        % annotation data
        % annoation for sites that are not within the input file are not
        % kept
        if size(probe_annot,1) > length(ib)
            fprintf(1, '- Extracted annotation for %u array sites\n', length(ib));
            fprintf(fid_rep, 'Number of entries of reduced annotation data:\t%u\n', length(ib));
        end
                
        probe_annot = probe_annot(ib,:);
        cgID_input =  cgID_input(ia);
    end    
end


%% Peak-based correction

if any(peak_correct) && platform == 2   
        
    % design type of each probe
    inf_type = strcmp(probe_annot(:,type_col), 'I');        
    
    % overwrite original beta values      
    beta_all = peak_based_correction(beta_all, ori_idx, inf_type, peak_correct, 0, 0, 0, fid_rep);    
end


%% read additional array sites from txt file
%  - used to highlight specific array sites in plots and txt file
%  - one or more columns of array IDs
%  - IDs can occur multiple types in different columns

if ~isempty(sites_extra)
    
    fprintf(1, '\n# Importing specific array sites from: %s\n', sites_extra);
    fprintf(fid_rep, '\n# Specific array sites file:\t%s\n', sites_extra);
    
    fid_extra = fopen(sites_extra, 'r');
    
    S_extra_header = fgetl(fid_extra);
    S_extra_header = regexp(S_extra_header, '\t', 'split');
        
    format_str = repmat('%s ', 1, length(S_extra_header));        
    S_extra = textscan(fid_extra, format_str, 'delimiter', '\t');
    fclose(fid_extra);
    
    % one cell array   
    S_extra = [S_extra{:}];    
    
    % columns can have different lengths, so empty content within some
    % vectors
    idx_extra = ~cellfun(@isempty, S_extra);
    S_extra_number = sum(idx_extra);
    
    % report column names and number of elements
    fprintf(fid_rep, 'Column name\tNumber of array sites\n');
    for i=1:size(S_extra, 2)
        fprintf(fid_rep, '%s\t%u\n', S_extra_header{i}, S_extra_number(i));
    end
    
    % one vector of all unique IDs
    % in plots it is currently ignored which column specified a site     
    % so highlighting independent of specific colums
    %%%% S_extra_all = unique(S_extra(idx_extra));
    
else
    S_extra = [];
    S_extra_header = [];
end


%% process input values and compare against UCSC refgene table
%  - get coordinates for specific gene transcripts
%  - one transcript is chosen, if ambiguous, the longest
%    transcript corresponding to the gene symbol is chosen

if platform == 1    
    % TODO: 27k support with hg18 genome
    % [collect_names, collect_coords] = get_genomic_coords(nimbl_gene_input, 'ucsc_hg18_refgene_table.txt', fid_rep);    
elseif platform == 2
    [collect_names, collect_coords] = get_genomic_coords(nimbl_gene_input, 'ucsc_hg19_refgene_table.txt', fid_rep);    
end


%% some pre-processing that needs to be performed only once

% chromosome
r_chr = '^chr$';

% gemomic position
r_mapinfo = 'mapinfo';

% chr
chr_idx = not(cellfun(@isempty, regexpi(header,r_chr)));
chr_all = probe_annot(:, chr_idx);
chr_all = regexprep(chr_all, {'x', 'y'}, {'23', '24'}, 'ignorecase');
chr_all = sscanf(sprintf('%s*', chr_all{:}), '%d*');

% mapinfo 
mapinfo_idx = not(cellfun(@isempty, regexpi(header,r_mapinfo)));
mapinfo_all = sscanf(sprintf('%s*', probe_annot{:, mapinfo_idx}), '%d*');


%% Create methylation profiles and overviews for genes or genomic regions
%  - and optionally generate alignment files (fasta files)

% print settings of genomic area to report file
fprintf(fid_rep, '\n# NIMBL-gene settings\n');
fprintf(fid_rep, 'Bases upstream of txS:\t%u\n', extra_upstream);
fprintf(fid_rep, 'Bases downstream of txE:\t%u\n', extra_downstream);
fprintf(fid_rep, 'Extra bases at genomic sequence ends:\t%u\n', extra_bases);

% print header of results table to report file
fprintf(fid_rep, '\n# Mapping of processed input values to chromosomal region and array sites (1-based coordinates)\n');
fprintf(fid_rep, 'Input value\tChrom\tStrand\tStart genomic region\tEnd genomic region\tLength genomic region\tNumber of measured array sites\tTotal number of CpG sites within region');

if align_probes
    fprintf(fid_rep, '\tStart of fasta sequence\tEnd of fasta sequence\n');
else
    fprintf(fid_rep, '\n');
end


fprintf(1, '\n# Analysis of %u processed input values:\n', size(collect_coords, 1));

% analyse each valid input value
for i=1:size(collect_coords, 1)
    
    [pos_found_idx, output_file_profile] = probe_alignment(platform, probe_annot, header, chr_all, mapinfo_all, cgID_col, beta_all, pval_all, pval_cut_p, groups_all, group_names, m,...
        collect_names(i,:), collect_coords(i,:), extra_upstream, extra_downstream, extra_bases, align_probes, label_sites, zoom_in, S_extra, S_extra_header,...
        nimbl_gene_prefix, fid_rep);
       
    
    % optionally write methylation levels to txt file
    if ~isempty(pos_found_idx)
        
        if ~ismember(methyl_profile_write, [0,1,2])
            
            fprintf(1, 'WARNING: please specify 0, 1 or 2 for input parameter ''methyl_profile_write'' to print methylation levels to txt file.\n');
            
        elseif methyl_profile_write > 0            
            
            % check overlap with each input column of specific sites            
            if ~isempty(sites_extra)
                
                S_extra_hits = zeros(length(pos_found_idx), size(S_extra,2));
                
                for j=1:size(S_extra,2)
                    [~,~,ib] = intersect(S_extra(:,j), cgID_input(pos_found_idx));
                    S_extra_hits(ib,j) = 1;
                end
                
                d_header_extra = ['\t', repmat('%s\t', 1, size(S_extra,2))];
                d_header_extra(end) = 'n';
                d_all_extra = ['\t', repmat('%u\t', 1, size(S_extra,2))];
                d_all_extra(end) = 'n';
            else                
                S_extra_header = {};                
                d_header_extra = '\n';  
                d_all_extra = '\n';
            end 
            
                        
            fid = fopen(output_file_profile, 'w');                                   
            
            % not every sample might be chosen as part of the comparison
            % these sample have 0 as an index
            % - plot sample as in the order of the input file
            n = groups_all > 0;
            sample_names_2 = sample_names(n);

            names_p = regexprep(sample_names_2, '(.*)', horzcat('$1', sample_del, 'Pval'));
            names_b = regexprep(sample_names_2, '(.*)', horzcat('$1', sample_del, 'Beta'));    
            
            d_beta = repmat('%11.9f\t', 1, sum(n));
            % d_pval = repmat('%E\t',1,sum(n)-1);
            d_pval = repmat('%11.9f\t',1,sum(n)-1);
            
            % print no further annotation
            if methyl_profile_write == 1
                
                fprintf(1, '- Writing methylation levels to file ...\n'); 
                
                % print header
                % format: one more column for IDs
                d_header = [repmat('%s\t',1,2*size(sample_names_2,2)), '%s', d_header_extra];
                fprintf(fid, d_header, 'TargetID', names_b{:}, names_p{:}, S_extra_header{:});
                   
                % format for all values
                d_all = ['%s\t',d_beta, d_pval, '%11.9f', d_all_extra];
                
                % print values
                if isempty(sites_extra)
                    for j=1:length(pos_found_idx)
                        fprintf(fid, d_all, cgID_input{pos_found_idx(j)}, beta_all(pos_found_idx(j),n), pval_all(pos_found_idx(j), n));
                    end
                else
                    for j=1:length(pos_found_idx)
                        fprintf(fid, d_all, cgID_input{pos_found_idx(j)}, beta_all(pos_found_idx(j),n), pval_all(pos_found_idx(j), n), S_extra_hits(j,:));
                    end
                end
                                                
            % include probe annotation (methyl_profile_write == 2)
            else
                
                fprintf(1, '- Writing methylation levels to file (including full annotation of array sites) ...\n');
                
                % print header
                % format: one more column for IDs before the actual values
                % with this extra column the file can be loaded as
                % methylation input file to NIMBL
                d_header = [repmat('%s\t',1, (2*size(sample_names_2,2) + size(probe_annot,2))), '%s', d_header_extra];                            
                fprintf(fid, d_header, header{:}, 'TargetID', names_b{:}, names_p{:}, S_extra_header{:});
                   
                % format for all values
                d_all = [repmat('%s\t',1, size(probe_annot,2)), '%s\t', d_beta, d_pval, '%11.9f', d_all_extra];
               
                % print values
                if isempty(sites_extra)
                    for j=1:length(pos_found_idx)
                        fprintf(fid, d_all, probe_annot{pos_found_idx(j),:}, cgID_input{pos_found_idx(j)}, beta_all(pos_found_idx(j),n), pval_all(pos_found_idx(j),n));
                    end
                else
                    for j=1:length(pos_found_idx)
                        fprintf(fid, d_all, probe_annot{pos_found_idx(j),:}, cgID_input{pos_found_idx(j)}, beta_all(pos_found_idx(j),n), pval_all(pos_found_idx(j),n), S_extra_hits(j,:));
                    end
                end
            end            
            fclose(fid);
        end
    end    
end 

fclose(fid_rep);
    
end




