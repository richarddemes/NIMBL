function nimbl(input_script)

% nimbl(input_script)
% 
% module: identifies differentially methylated array sites and corresponding genes
% 
% IN:
% - input_script = script name of user specified settings e.g.
%   nimbl('my_analysis'); 
% 
% OUT:
% - TAB-delimited text file reporting ranked and annotated candidates
%   identified
%

% version
nimbl_version = 'v0.1.0';

fprintf(1, '\nNIMBL-core module (%s):\n---------------------------\n', nimbl_version);


%% include user-defined input

eval(input_script);


%% nimbl report

fid_rep = fopen([nimbl_prefix, '_report.txt'], 'w');


%% read methylation data and sample QC

[sample_names, pval_all, beta_all, signals, cgID_input] = read_infinium(input_file, input_del, sample_del, sample_pos);


% report all samples from input
fprintf(fid_rep, 'NIMBL report (%s)\n\n', nimbl_version);
fprintf(fid_rep, '# Methylation input file:\t%s\n', input_file);
fprintf(fid_rep, 'Total number of array sites per sample:\t%u\n\n', size(beta_all,1));

fprintf(fid_rep, 'Sample index\tSample name\n');
for i=1:size(beta_all,2)
    fprintf(fid_rep, '%u\t%s\n', i, sample_names{i});
end


%% generate grouping vector

%   - 0: ignore sample
%   - 1: group 1
%   - 2: group 2

n = size(beta_all,2);

if not(isempty(intersect(g1, g2)))
    error('Samples are selected for both groups.')
elseif (max(g1) > n) || (max(g2) > n) || (min(g1) < 1) || (min(g2) < 1)
    error('Sample index exceeds limits.')
end

grouping = zeros(1,n);
grouping(g1) = 1;
grouping(g2) = 2;


%% exclude any samples (e.g. due to low quality)

fprintf(1, '\n# Exclusion of samples: \n');

sample_ex = unique(sample_ex);
sample_idx = 1:size(beta_all,2);

if isempty(sample_ex) || all(sample_ex==0)
    fprintf(1, '- No samples excluded from dataset\n');          
else
    fprintf(fid_rep, '\n# Samples excluded from methylation analysis\n');
    fprintf(fid_rep, 'Sample index\tSample name\n');

    for i=1:length(sample_ex)
        fprintf(1, '- %u:\t%s\n', sample_ex(i), sample_names{sample_ex(i)});
        fprintf(fid_rep, '%u\t%s\n', sample_ex(i), sample_names{sample_ex(i)});
    end       
        
    % delete sample names
    sample_names(sample_ex) = [];

    % delete samples in pvals, betas, peak_correct, signals, sample_idx, grouping
    if length(peak_correct) == size(beta_all,2)
        peak_correct(sample_ex) = [];
    end
    
    pval_all(:,sample_ex) = [];
    beta_all(:,sample_ex) = [];
    if (length(signals) ~= 1)        
        signals(:,:,sample_ex) = [];    
    end 
    
    sample_idx(sample_ex) = [];
    grouping(sample_ex) = [];
end


%% read annotation data

[probe_annot, header, cgID_col, type_col, read_annot_file] = read_annotation(annot_file, input_del, platform);

% report info about annotation file
% annot_file could be empty, so default is loaded
% us output parameter of read_annotation
fprintf(fid_rep, '\n# Annotation input file:\t%s\n', read_annot_file);
fprintf(fid_rep, 'Total number of entries:\t%u\n', size(probe_annot, 1));

%% ensure compatibility of methylation input and annotation input

test_input = false;
% test if complete dataset (all CpG sites are loaded)
if length(probe_annot(:,cgID_col)) ~= length(cgID_input)
    test_input = true;
% if same length, check if identical at every position    
elseif (sum(strcmp(probe_annot(:,cgID_col),cgID_input)) ~= length(probe_annot(:,cgID_col)))
    test_input = true;    
end

% annotation file has different number or order of array sites
% so make the two input files compatible 
if test_input
         
    [test_intersect, ia, ib] = intersect(cgID_input, probe_annot(:,cgID_col));           
     
    % test if each input array site has a corresponding annotation row    
    if (length(test_intersect) ~= length(cgID_input))
        
        fprintf(1, '\nInput file and annotation file are not compatible!\n');
        fprintf(1, 'These are the first entries of the lists of identifiers compared:\n');
        fprintf(1, '- input file: %s (%u entries in total in input file)\n', cgID_input{1}, length(cgID_input));
        fprintf(1, '- annot file: %s (%u entries in total in annotation file)\n', probe_annot{1,cgID_col}, length(probe_annot(:,cgID_col)));
        error('Some cgIDs of input file have no corresponding entry in annotation file!')
        
    else
        % re-arrange input and annot data so that the size and order is the
        % same
        
        % methylation data
        pval_all = pval_all(ia,:);
        beta_all = beta_all(ia,:);
        if (length(signals) ~= 1)        
            signals = signals(ia,:,:);    
        end 
        
        % array sites from input file
        cgID_input = cgID_input(ia);
        
        % annotation data
        % annoation for sites that are not within the input file are not
        % kept
        if size(probe_annot,1) > length(ib)
            fprintf(1, '- Extracted annotation for %u array sites\n', length(ib));
            fprintf(fid_rep, 'Number of entries of reduced annotation data:\t%u\n', length(ib));
        end
        probe_annot = probe_annot(ib,:);
    end    
end


%% Peak-based correction

if any(peak_correct) && platform == 2   
        
    % Infinium design type of each probe
    inf_type = strcmp(probe_annot(:,type_col), 'I');        
    
    % overwrite original beta values
    % do not generate any plots of beta value distributions
    beta_all = peak_based_correction(beta_all, sample_idx, inf_type, peak_correct, 0, 0, 0, fid_rep);      
end


%% select array sites (probes) and QC of probes

fprintf(1, '\n- Selection of array sites ...\n');

select_cpg = select_probes(probe_annot, header, grouping, sample_ex, group_names, sample_names, pval_all, beta_all, pval_cut_p, pval_qc_p, miss_beta_qc, chr_sel, cpg_reg, cpg_user, fid_rep);

% Sites fulfilling all criteria  
sel = all(select_cpg,2);


%% print excluded array sites
%  - beta values might be peak-based corrected within this module

% index od excluded sites
idx_ex = find(~sel);

if excluded_write && (sum(~sel) > 0)
    
    if any(peak_correct) && platform == 2 && excluded_write > 1
        corrected_info = '_peak_corrected'; % for file name
        corrected_info_2 = 'PeakCorrected'; % do not introduce any special character within the header
    else
        corrected_info = '';
        corrected_info_2 = '';
    end
    
    % filename based on input filename:
    out_file = regexprep(input_file, '(.*)\.(.*)', ['$1_NIMBL', corrected_info, '_excluded.$2']);
    
    % test if no '.' within filename, then strings are identical
    % just add the prefix to the end
    if strcmp(input_file, out_file)
        out_file = [input_file, ['$1_NIMBL', corrected_info, '_excluded.$2']];
    end  
        
    fid_out = fopen(out_file, 'w');
    
    % beta values: append prefix
    names_b = regexprep(sample_names, '(.*)', horzcat('$1', sample_del, 'Beta', corrected_info_2));
    d_beta = repmat('%11.9f\t', 1, size(beta_all,2));
    
    % pvals: append prefix 
    names_p = regexprep(sample_names, '(.*)', horzcat('$1', sample_del, 'Pval'));
    d_pval = repmat('%11.9f\t',1,size(beta_all,2));    
    
    % header format for option 2 and 3
    d_header = repmat('%s\t',1, ((excluded_write - 1) * size(sample_names,2))+1);
    d_header = [d_header(1:end-1), 'n'];
    
    if excluded_write == 1 % cgIDs
        
        fprintf(1, '- Writing identifiers for %u samples and %u excluded array sites to: %s ...', length(sample_names), length(idx_ex), out_file);
        
        % print header    
        fprintf(fid_out, 'TargetID\n');
              
        for i=1:length(idx_ex)
            fprintf(fid_out, '%s\n', cgID_input{idx_ex(i)});
        end 
         
    
    elseif excluded_write == 2 % cgIDs + beta values        
        
        fprintf(1, '- Writing %s beta values for %u samples and %u excluded array sites to: %s ...', corrected_info_2, length(sample_names), length(idx_ex), out_file);
        
        % format for values
        d_values = ['%s\t', d_beta(1:end-2), '\n'];
        
        % print header    
        fprintf(fid_out, d_header, 'TargetID', names_b{:});
        
        for i=1:length(idx_ex)
            fprintf(fid_out, d_values, cgID_input{idx_ex(i)}, beta_all(idx_ex(i),:));
        end
        
    elseif excluded_write == 3 % cgIDs + beta values and pvals        
        
        fprintf(1, '- Writing %s beta values and P-values for %u samples and %u excluded array sites to: %s ...', corrected_info_2, length(sample_names), length(idx_ex), out_file);
        
        % format for values
        d_values = ['%s\t', d_beta, d_pval(1:end-2), '\n'];
        
        % print header    
        fprintf(fid_out, d_header, 'TargetID', names_b{:}, names_p{:});
        
        for i=1:length(idx_ex)
            fprintf(fid_out, d_values, cgID_input{idx_ex(i)}, beta_all(idx_ex(i),:), pval_all(idx_ex(i),:));
        end
        
    elseif excluded_write == 4 % beta values, pvals, annotation
       
        fprintf(1, '- Writing %s beta values, P-values and annotation for %u samples and %u excluded array sites to: %s ...', corrected_info_2, length(sample_names), length(idx_ex), out_file);
                
        % print header
        % format: one more column for IDs before the actual values
        % with this extra column the file can be loaded as
        % methylation input file to NIMBL        
        d_header = repmat('%s\t',1, (size(probe_annot,2) + 2*size(sample_names,2) + 1));
        d_header = [d_header(1:end-1), 'n'];
        
        fprintf(fid_out, d_header, header{:}, 'TargetID', names_b{:}, names_p{:});

        % format for all values
        d_all = [repmat('%s\t',1, size(probe_annot,2) + 1), d_beta, d_pval(1:end-2), '\n'];
        
        for i=1:length(idx_ex)
            fprintf(fid_out, d_all, probe_annot{idx_ex(i),:}, cgID_input{idx_ex(i)}, beta_all(idx_ex(i),:), pval_all(idx_ex(i),:));    
        end        
    end
    
    fclose(fid_out);
    fprintf(1, ' done\n');
end


%% final selection of values

% delete sites not selected
pval_all(~sel,:) = [];
beta_all(~sel,:) = [];
cgID_input(~sel) = [];
probe_annot(~sel,:) = [];
if (length(signals) ~= 1)        
    signals(~sel, :, :) = [];    
end


%% print selected array sites
%  - beta values might be peak-based corrected within this module
%  - TODO: a function for printing selected array sites

if selected_write && (sum(sel) > 0)
    
    if any(peak_correct) && platform == 2 && selected_write > 1
        corrected_info = '_peak_corrected'; % for file name
        corrected_info_2 = 'PeakCorrected'; % do not introduce any special character within the header
    else
        corrected_info = '';
        corrected_info_2 = '';
    end
    
    % filename based on input filename:
    out_file = regexprep(input_file, '(.*)\.(.*)', ['$1_NIMBL', corrected_info, '_selected.$2']);
    
    % test if no '.' within filename, then strings are identical
    % just add the prefix to the end
    if strcmp(input_file, out_file)
        out_file = [input_file, ['$1_NIMBL', corrected_info, '_selected.$2']];
    end  
        
    fid_out = fopen(out_file, 'w');
    
    % beta values: append prefix
    names_b = regexprep(sample_names, '(.*)', horzcat('$1', sample_del, 'Beta', corrected_info_2));
    d_beta = repmat('%11.9f\t', 1, size(beta_all,2));
    
    % pvals: append prefix 
    names_p = regexprep(sample_names, '(.*)', horzcat('$1', sample_del, 'Pval'));
    d_pval = repmat('%11.9f\t',1,size(beta_all,2));    
    
    % header format for option 2 and 3
    d_header = repmat('%s\t',1, ((selected_write - 1)  * size(sample_names,2))+1);
    d_header = [d_header(1:end-1), 'n'];
    
    if selected_write == 1 % cgIDs
        
        fprintf(1, '- Writing identifiers for %u samples and %u selected array sites to: %s ...', length(sample_names), size(beta_all, 1), out_file);
        
        % print header    
        fprintf(fid_out, 'TargetID\n');
                
        for i=1:size(beta_all,1)
            fprintf(fid_out, '%s\n', cgID_input{i});
        end 
          
    elseif selected_write == 2 % cgIDs + beta values        
        
        fprintf(1, '- Writing %s beta values for %u samples and %u selected array sites to: %s ...', corrected_info_2, length(sample_names), size(beta_all, 1), out_file);
        
        % format for values
        d_values = ['%s\t', d_beta(1:end-2), '\n'];
        
        % print header    
        fprintf(fid_out, d_header, 'TargetID', names_b{:});
        
        for i=1:size(beta_all,1)
            fprintf(fid_out, d_values, cgID_input{i}, beta_all(i,:));
        end
        
    elseif selected_write == 3 % cgIDs + beta values and pvals        
        
        fprintf(1, '- Writing %s beta values and P-values for %u samples and %u selected array sites to: %s ...', corrected_info_2, length(sample_names), size(beta_all, 1), out_file);
        
        % format for values
        d_values = ['%s\t', d_beta, d_pval(1:end-2), '\n'];
        
        % print header    
        fprintf(fid_out, d_header, 'TargetID', names_b{:}, names_p{:});
        
        for i=1:size(beta_all,1)
            fprintf(fid_out, d_values, cgID_input{i}, beta_all(i,:), pval_all(i,:));            
        end       
        
    elseif selected_write == 4 % cgIDs + beta values, pvals, annotation
       
        fprintf(1, '- Writing %s beta values, P-values and annotation for %u samples and %u selected array sites to: %s ...', corrected_info_2, length(sample_names), size(beta_all, 1), out_file);
                
        % print header
        % format: one more column for IDs before the actual values
        % with this extra column the file can be loaded as
        % methylation input file to NIMBL        
        d_header = repmat('%s\t',1, (size(probe_annot,2) + 2*size(sample_names,2) + 1));
        d_header = [d_header(1:end-1), 'n'];
        
        fprintf(fid_out, d_header, header{:}, 'TargetID', names_b{:}, names_p{:});

        % format for all values
        d_all = [repmat('%s\t',1, size(probe_annot,2) + 1), d_beta, d_pval(1:end-2), '\n'];
        
        for i=1:size(beta_all,1)
            fprintf(fid_out, d_all, probe_annot{i,:}, cgID_input{i}, beta_all(i,:), pval_all(i,:));
        end 
    end
    
    fclose(fid_out);
    fprintf(1, ' done\n');
end


%% beta value distribution across selected CpG sites for every sample passed QC

if (kde_test) 
    
    %{
    % escape underscores within name with backslashes for plots
    % sample_names_print = regexprep(sample_names, '_','\\_');    
    
    % modify sample names: incorporate original sample index
    % helps to identify specific samples in plots    
        
    sample_idx = 1:size(beta_all,2) + length(sample_ex);
    if length(sample_ex) > 0 && all(sample_ex ~= 0)
        sample_idx(sample_ex) = [];
    end
        
    for i=1:size(beta_all,2)
        sample_names_print{i} = [num2str(sample_idx(i)), ' ',sample_names_print{i}];
    end    
    %}  
           
    % highlight group1 vs group2
    % color map: red-yellow - group1,  blue-pink: group2
    
    % color_matrix = zeros(sum(grouping > 0),3);
    % color_matrix(1:sum(grouping==1),:) = colormap(autumn(sum(grouping==1)));
    % color_matrix(sum(grouping==1)+1:end,:) = colormap(cool(sum(grouping==2)));
    color_matrix = zeros(length(grouping),3);
    color_matrix(grouping==1,:) = colormap(autumn(sum(grouping==1)));
    color_matrix(grouping==2,:) = colormap(cool(sum(grouping==2)));    
    color_matrix(grouping==0,:) = [];
        
    % get_beta_kde(beta_all(:,grouping > 0), [nimbl_prefix, '_beta_distribution_selected_sites.pdf'], sample_names_print(grouping > 0), color_matrix);
    
    % use sample idx instead of names, legend requires cell array of strings    
    idx_new = arrayfun(@num2str, sample_idx, 'UniformOutput', 0);    
    get_beta_kde(beta_all(:,grouping > 0), [nimbl_prefix, '_beta_distribution_selected_sites.pdf'], idx_new(grouping > 0), color_matrix);    
end


%% boxplot of each sample
%  - highlight g1 vs g2 with two colors

if boxplot_write

    fprintf(1, '- Boxplot of samples g1 vs g2 ...\n');    
    
    group_names_print = regexprep(group_names, '_','\\_');
    title_info = ['Overall Beta-value distribution (', group_names_print{1} ,' (', num2str(sum(grouping == 1)),') vs ',...
        group_names_print{2}, ' (',num2str(sum(grouping == 2)), '), ',   num2str(size(beta_all,1)), ' array sites)'];
      
    get_beta_box(beta_all(:,grouping > 0), title_info, [nimbl_prefix, '_groups_boxplots.pdf'], sample_idx(grouping > 0), grouping(grouping > 0), boxplot_write);  
end

%% differential methylation analysis

fprintf(1, '\n# Differential methylation analysis:\n');

[overview, overview_bin, s_all] = differential_methylation(beta_all, grouping, beta_dist, mask_frac, limit1, limit2);

% binary vector of candidates
candidates_idx = overview_bin(:,1,1) == 1 & (overview_bin(:,2,1) == 1 & overview_bin(:,2,2) == 1);


%% Display settings and results on screen and report file

fprintf(1, '- groups: { ''%s'' } vs { ''%s'' } (%u vs %u samples)\n', group_names{1}, group_names{2}, sum(grouping == 1), sum(grouping == 2));
fprintf(1, '- number of array sites analysed: %u\n', size(beta_all,1));
fprintf(1, '- Minimal intergroup Beta-value distance: %3.2f\n', beta_dist);

% output to report
fprintf(fid_rep, '\n# Differential methylation settings\n');
fprintf(fid_rep, 'Number of sites analysed\t%u\n', size(beta_all,1));
fprintf(fid_rep, 'Minimal intergroup beta-value distance (d)\t%3.2f\n', beta_dist);

if sum(mask_frac) > 0
    k_vals = [floor(sum(grouping == 1)*mask_frac(1)),floor(sum(grouping == 2)*mask_frac(2))];
    fprintf(1, '- Maximal number of masked samples: group1: %u | group2: %u\n', k_vals(1), k_vals(2));
    fprintf(fid_rep, 'Maximal number of masked samples (group1, group2)\t%u\t%u\n', k_vals(1), k_vals(2));
else
    fprintf(1, '- No samples masked\n');
    fprintf(fid_rep, 'No samples masked\n');
end

% report limits if specified by user 
if ((sum(limit1 == [0,1]) < 2) || (sum(limit2 == [0,1]) < 2))
    fprintf(1, '- Limits on median Beta-values group1: [%3.2f, %3.2f], group2: [%3.2f, %3.2f]\n', limit1(1), limit1(2), limit2(1), limit2(2));
    fprintf(fid_rep, 'Limits on median beta values\tgroup1: [%3.2f, %3.2f]\tgroup2: [%3.2f, %3.2f]\n', limit1(1), limit1(2), limit2(1), limit2(2));
else
   fprintf(1, '- No limits on median Beta-values of groups\n'); 
   fprintf(fid_rep, 'No limits on median beta values of groups\n'); 
end

% number of identified sizes
fprintf(1, '\n# Results:\n- Total number of differentially methylated sites: %u\n', sum(candidates_idx));
fprintf(1, '- Sites with higher methylation in group1: %u\n\n', sum(overview(candidates_idx,12)));


fprintf(fid_rep, '\n# Differential methylation results\n');
fprintf(fid_rep, 'Number of differentially methylated sites\t%u\n', sum(candidates_idx));


idx_print = find(candidates_idx);


%% gene level analysis

% currently only works for 450k data!!!

if platform == 2 && (sum(candidates_idx) > 0)

    fprintf(1, '- Gene level analysis... \n');

    % if (sum(candidates_idx) > 0)

    % load gene annotation information
    % generated with preprocess_annotation.m
    %  3 variables:
    %  - ID_info
    %  - cg_info
    %  - gene_symbols
    
    % read from tab-delimited text file:
    gene_annot_450k = importdata('450k_gene_annot.txt', '\t', 0);

    ID_info = gene_annot_450k.textdata(:,1);
    % first three columns are relevant here
    % col 4 and 5 represent chr and mapinfo
    cg_info = gene_annot_450k.data(:,1:3);
    gene_symbols = gene_annot_450k.textdata(~cellfun(@isempty, gene_annot_450k.textdata(:,2)),2);
    gene_symbols(1) = {''};


    % translate ID list of diff sites into corresponding gene set
    [g_hits_idx, g_hits, ig] = get_genes(probe_annot(candidates_idx,cgID_col), ID_info, cg_info);


    if length(g_hits_idx) > 0            

        fprintf(fid_rep, 'Number of corresponding genes\t%u\n', length(g_hits_idx));
        fprintf(fid_rep, 'Number of diff methylated sites without gene annotation (intergenic)\t%u\n', ig);

        % compute numbers for all sites on array
        % ID_info contains all sites for which gene annotation is provided
        [g_hits_idx_all, g_hits_all, ~] = get_genes(unique(ID_info), ID_info, cg_info);

        % sites analysed
        % use these numbers for the sites within gene regions, % values are
        % calculated based on these
        [g_hits_idx_sel, g_hits_sel, ~] = get_genes(probe_annot(:,cgID_col), ID_info, cg_info);

        % rearrange gene regions in 5' -> 3' order
        g_hits_sel = g_hits_sel(:,[1,6,7,4,2,5,3]);

        % comprehensive gene table:    

        %  1: gene idx
        %  2: # sites on chip
        %  3: # sites excluded
        %  4: # sites analysed
        %  5: # sites diff. methylated
        %  6: % diff methylated 

        % gene regions
        % 7: # sites analysed TSS1500
        % 8: # sites found diff methylated
        % 9: % diff methylated for prev. gene region
        % 10: # sites analysed TSS200
        % 11: # sites found diff methylated
        % 12: % diff methylated for prev. gene region
        % 13: # sites analysed 5'UTR
        % 14: # sites found diff methylated
        % 15: % diff methylated for prev. gene region
        % 16: # sites analysed 1st exon
        % 17: # sites found diff methylated
        % 18: % diff methylated for prev. gene region
        % 19: # sites analysed body
        % 20: # sites found diff methylated
        % 21: % diff methylated for prev. gene region
        % 22: # sites analysed 3'UTR
        % 23: # sites found diff methylated
        % 24: % diff methylated for prev. gene region
        % 25: # sites analysed promoter (TSS1500, TSS200, 3'UTR)
        % 26: # sites found diff methylated
        % 27: % diff methylated for prev. gene region

        first_cols = 6;
        g_cols = first_cols + 21;
        gene_table = zeros(length(g_hits_idx), g_cols);

        % gene indices
        gene_table(:,1) = g_hits_idx;

        % sites in total
        [~, ~, ib] = intersect(gene_table(:,1), g_hits_idx_all);
        gene_table(:,2) = g_hits_all(ib,1); 

        % sites analysed
        % use these numbers for the gene regions
        [~, ~, ib] = intersect(gene_table(:,1), g_hits_idx_sel);
        gene_table(:,4) = g_hits_sel(ib,1); 

        % sites excluded
        gene_table(:,3) = gene_table(:,2) - gene_table(:,4);

        % diff methylated sites
        gene_table(:,5) = g_hits(:,1);

        % percent diff methylated
        gene_table(:,6) = (gene_table(:,5)*100)./gene_table(:,4);

        % rearrange gene regions in 5' -> 3' order
        % columns in table are alphabetically ordered
        g_hits = g_hits(:,[1,6,7,4,2,5,3]);

        % gene region info        

        % gene region info of sites analysed
        s1 = first_cols + 1;
        col_greg_total = [s1, s1+3, s1+6, s1+9, s1+12, s1+15, s1+18];
        % ib can still be used
        gene_table(:,col_greg_total) = [g_hits_sel(ib,2:end), sum(g_hits_sel(ib,[2,3,4]),2)];

        % gene region info of sites diff methylated
        s1 = s1+1;
        col_greg_diff = [s1, s1+3, s1+6, s1+9, s1+12, s1+15, s1+18];
        % include promoter
        gene_table(:,col_greg_diff) = [g_hits(:,2:end), sum(g_hits(:,[2,3,4]),2)];

        % percent of diff methylated sites found in gene regions
        s1 = s1+1;
        col_greg_perc = [s1, s1+3, s1+6, s1+9, s1+12, s1+15, s1+18];
        gene_table(:,col_greg_perc) = (gene_table(:,col_greg_diff).*100) ./ gene_table(:,col_greg_total);


        % replace all NaN with 0
        gene_table(isnan(gene_table)) = 0;


        % sort gene table by descending order of sites diff methylated and
        % corresponding percent value
        gene_table = sortrows(gene_table, [-5, -6]);


        %% write gene table to file

        fid_gtable = fopen([nimbl_prefix, '_gene_table.txt'],'w');

        % header
        header_g = '';
        header_g = [header_g,'gene symbol\tsites on array\tsites excluded\tsites analysed\tsites diff methyl\t%%\t']; 

        gene_regions = {'TSS1500', 'TSS200', '5''UTR', '1st Exon', 'Body', '3''UTR'};

        for j=1:length(gene_regions)
            header_g = [header_g, 'sites ', gene_regions{j},'\tsites diff methyl\t%%\t'];
        end
        % promoter: TSS1500+TSS200+5'UTR
        header_g = [header_g, 'sites promoter\tsites diff methyl\t%%\n'];

        % print header
        fprintf(fid_gtable, header_g);

        gtable_format1 = repmat('%u\t',1,first_cols-2);
        gtable_format2 = repmat('%u\t%u\t%4.3f\t',1,6);
        gtable_format_all = ['%s\t', gtable_format1, '%4.3f\t' gtable_format2, '%u\t%u\t%4.3f\n'];

        for j=1:size(gene_table,1)
            fprintf(fid_gtable, gtable_format_all, gene_symbols{gene_table(j,1)}, gene_table(j,2:end));
        end        

        fclose(fid_gtable);    
    end    
end

%% sorting of candidates

% if cand_mult > 0    
    % sort according to combined score, followed by individual scores   
%    [~, IX] = sortrows(overview(idx_print,[13,14]), [-2,-1]);
% else 
    % sort according to single score, column 13
    [~, IX] = sort(overview(idx_print,13), 'descend');
% end

% sort candidates
idx_print = idx_print(IX);   

% select sorted data of candidates
% for all samples: '0': masked in differential procedure, '1': kept
s_all = s_all(idx_print,:);
beta_scatter = beta_all(idx_print,:);


%% plot beta values of candidates in summary plot
%  masked samples are marked with 'x'

if ~isempty(idx_print)

    fprintf(1, '\n- Generate overview plot of diff methylated sites ... \n');

    % plot_differential_sites(group_names, grouping, beta_scatter, s_all, hits, [nimbl_prefix, '_diff_methylation.pdf']);
    % several group names might be specified (for NIMBL-gene), use by default the first two names
    plot_differential_sites(group_names(1:2), grouping, beta_scatter, s_all, hits, [nimbl_prefix, '_diff_methylation.pdf']);
end


%%  number of maskings of each sample in each group

n1 = sum(grouping == 1);
n2 = sum(grouping == 2);
m = max(n1, n2);
f = zeros(m,4);

if sum(mask_frac) > 0    
    
    if sum(k_vals) > 0 % the user defined fraction might not result in any masking
        
        f(1:n1, 1) = sum(~s_all(:,grouping==1));
        f(1:n2, 3) = sum(~s_all(:,grouping==2));

        s1 = sum(any(~s_all(:,grouping==1),2));
        s2 = sum(any(~s_all(:,grouping==2),2));

        % total number of sites with any masked sample
        s3 = sum(any(~s_all(:,grouping>0),2));

        % which samples are to which percent involved in masking
        % - one site can have several maskings
        f(:,2) = f(:,1) .* 100 ./ s1;
        f(:,4) = f(:,3) .* 100 ./ s2;

        fprintf(fid_rep, '\n# Masking of samples\n');    

        fprintf(fid_rep, 'Samples masked from group\tDiff methylated sites with masked samples\n');
        fprintf(fid_rep, 'group1\t%u\ngroup2\t%u\nany\t%u\n\n', s1, s2, s3);    

        % groups can have different lengths
        group_members = cell(m, 6);

        % group1
        % idx
        group_members(1:n1,1) = num2cell(sample_idx(grouping==1));
        % number of maskings
        group_members(1:n1,2) = num2cell(f(1:n1,1));
        % % value
        group_members(1:n1,3) = num2cell(f(1:n1,2));

        % group2    
        % idx
        group_members(1:n2,4) = num2cell(sample_idx(grouping==2));
        % number of maskings
        group_members(1:n2,5) = num2cell(f(1:n2,3));
        % % value
        group_members(1:n2,6) = num2cell(f(1:n2,4));

        fprintf(fid_rep, 'Sample index\tSites masked in group1\tPercent\tSample idx\tSites nasked in group2\tPercent\n');
        for i=1:size(group_members,1)
            fprintf(fid_rep, '%u\t%u\t%3.2f\t%u\t%u\t%3.2f\n', group_members{i,:});
        end 
    
    end
end



%% print methylation results table - TAB-delimited

% report: 
%  - all probe information (from annotation data)
%  - pvalues
%  - signal values (if provided)
%  - beta values
%  - intergroup distance, median difference, score
%  - number of masked samples in group1, group2 and both

if ~isempty(idx_print)

    fprintf(1, '\n- Output diff methylated sites... ');

    file_name_sheet = [nimbl_prefix, '_diff_methylation.txt'];
    fid = fopen(file_name_sheet, 'w');

    % print only cgIDs
    file_name_sheet_ID = [nimbl_prefix, '_diff_methylation_IDs.txt'];
    fid_ID = fopen(file_name_sheet_ID, 'w');

end

%% header and format strings

if ~isempty(idx_print)
    
    % probe annotation
    d_annot = repmat('%s\t', 1, length(header));

    % original sample names: first group1 samples, then group2 samples
    names = [sample_names(grouping == 1), sample_names(grouping == 2)];
    d_samp = repmat('%s\t',1,size(names,2));

    % pvalues
    % names_p = regexprep(names, '(.*)', '$1.Pval');    
    names_p = regexprep(names, '(.*)', horzcat('$1', sample_del, 'Pval'));
    d_pval = repmat('%E\t',1,size(names,2));  


    % signals (3D matrix) if any signals given    
    % 0 or 3 values per sample: sig A, sig B and intensity (sigA + sigB)

    test_signal = size(signals,2);

    % no signals provided
    if test_signal == 1 % signals == 0
        test_signal = 0;
    end

    if (test_signal > 1)

        % append header information on each sample name
        names_s = cell(size(signals,2),size(names,2));   
        names_s(1,:) = regexprep(names, '(.*)', horzcat('$1', sample_del, 'SignalA'));
        names_s(2,:) = regexprep(names, '(.*)', horzcat('$1', sample_del, 'SignalB'));
        names_s(3,:) = regexprep(names, '(.*)', horzcat('$1', sample_del, 'Intensity'));    

        % single row vector
        names_s = reshape(names_s, 1, test_signal*size(names,2));
    else    
        names_s = {};
    end

    % signals
    % - 0 or 3 values per sample
    l = test_signal * size(names, 2);
    d_sig = repmat('%15.9f\t', 1, l);


    % beta values
    % beta values might be calculated within infinium_qc.m based on signals
    names_b = regexprep(names, '(.*)', horzcat('$1', sample_del, 'Beta'));
    d_beta = repmat('%11.9f\t', 1, size(names,2));

    % rest:
    % intergroup dist, median diff, score, masking group1, group2 and sum
    % d_res_h = 'intergroup dist\tmedian diff\tgroup1 higher methylated\tscore\tcombined score\t# masked group1\t# masked group2\t# sum of maskings\n';
    d_res_h = 'intergroup dist\tmedian diff\tgroup1 higher methylated\tscore\t# masked group1\t# masked group2\t# sum of maskings\n';

    % results
    % d_res = repmat('%11.9f\t', 1 , 4);
    % d_res = horzcat(repmat('%11.9f\t', 1 , 2), '%u\t', repmat('%11.9f\t', 1 , 2));
    d_res = horzcat(repmat('%11.9f\t', 1 , 2), '%u\t%11.9f\t');


    % masking group1, group2 and both groups    
    d_mask = '%u\t%u\t%u\n';

    % overall format for header
    % probe annot, pvalues, signals, beta values, results
    % repmat returns empty matrix if test_signal == 0
    d_all_head = [d_annot, d_samp, repmat(d_samp,1,test_signal), d_samp, d_res_h];

    % print header
    fprintf(fid, d_all_head, header{:}, names_p{:}, names_s{:}, names_b{:});

end

%% print probe annotation and numeric data for each candidate:

if ~isempty(idx_print)
    
    % overall format for all values per row
    d_all = [d_annot,d_pval,d_sig,d_beta,d_res,d_mask];

    % samples of the two groups can be mixed in their order
    % ensure to have first all group1 samples and then group2 samples    
    idx1 = find(grouping==1);
    idx2 = find(grouping==2);    
    idx = [idx1, idx2];

    % signals in correct format
    if (test_signal > 1)
        signals_print = reshape(signals(idx_print,:,idx),length(idx_print),l);
    end

    % beta values in right order of samples
    beta_scatter = beta_scatter(:,idx);


    % flag any masked samples in beta value matrix with NaN
    if (any(overview(candidates_idx,7)) && flag_mask == 1)
        del = s_all(:,idx) == 0;        
        beta_scatter(del) = NaN;
    end


    for x=1:size(idx_print,1)

        if (test_signal ~= 0)

            fprintf(fid, d_all,...
                probe_annot{idx_print(x),:},...
                pval_all(idx_print(x),idx),...            
                signals_print(x, :),...
                beta_scatter(x, :),...
                overview(idx_print(x),[8,11,12,13]),...
                overview(idx_print(x), [5,6,7])); 
        else % no signals given       

            fprintf(fid, d_all,...
                probe_annot{idx_print(x),:},...
                pval_all(idx_print(x),idx),...           
                beta_scatter(x, :),...
                overview(idx_print(x),[8,11,12,13]),...
                overview(idx_print(x), [5,6,7]));

            fprintf(fid_ID, '%s\n', probe_annot{idx_print(x),cgID_col});


        end
    end

    fclose(fid);
    fclose(fid_ID);
    fprintf(1, 'done\n');    
end



%% group variation analysis

p = size(beta_all,1);

for i=1:2 % group
    
    v = max(beta_all(:, grouping == i),[], 2) - min(beta_all(:, grouping == i), [], 2);
        
    % [x1,x_bin] = histc(v,0:0.05:1)
    
    edges = 0:0.05:1;
    v_hist = histc(v,edges);
        
    % bar plot 
    % bar(edges, v_hist, 'style', 'histc')
    
    v_hist_mat = zeros(length(edges)-1, 6);
    
    
    for j=1:length(edges)-1        
        v_hist_mat(j,1) = edges(j);
        v_hist_mat(j,2) = edges(j+1);
        v_hist_mat(j,3) = v_hist(j);
        v_hist_mat(j,4) = v_hist(j)*100/p;        
    end
    
    v_hist_mat(:,5) = cumsum(v_hist_mat(:,3));
    v_hist_mat(:,6) = cumsum(v_hist_mat(:,4));    
    
    fprintf(fid_rep, '\n# Maximal beta value distance in group %s (%u samples, %u selected sites)\n', group_names{i}, sum(grouping==i), p);
    fprintf(fid_rep, 'edge1\tedge2\t# sites\tpercent\tcumsum # sites\tcumsum percent\n');
    for j=1:size(v_hist_mat,1)
        fprintf(fid_rep, '%3.2f\t%3.2f\t%u\t%3.4f\t%u\t%3.4f\n', v_hist_mat(j,:));
    end
end



%% keep cpgIDs of selected samples

% assume first column contains cpgIDs
% selected_cpg_sites = probe_annot(:,1);


fclose(fid_rep);

    
end

