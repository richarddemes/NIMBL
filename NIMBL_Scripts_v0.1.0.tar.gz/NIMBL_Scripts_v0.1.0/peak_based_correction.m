function [beta_all_corrected]  = peak_based_correction(data, sample_idx, inf_type, peak_correct, qc, plots, prefix, fid_rep)

% peak_based_correction(data, sample_idx, inf_type, peak_correct, qc, plots, prefix)
%
% implementation of Dedeurwaerder2011 approach to correct Infinium II values
% 
% IN:
% - data: matrix of beta values
% - sample_idx: (numeric) original sample indices, used if plots are
%   generated for each sample
% - inf_type: (logical) vector of Infinium design type of array sites (1: type I, 0: type II)
% - peak_correct: specifies how each sample should be corrected (from input script)
% - qc: (binary) generate or sckip QC plots (beta value distributions)
% - plots: corresponds to peak_correct_detail from input script, generate
%          plots for each sample or merge all samples in one plot
% - prefix: prefix name for plots 
%
% OUT:
% - beta_all_corrected: corrected matrix of beta values
% - PDF plots of beta value distribution of type vs type II
%


fprintf(1, '\n# Peak-based correction of Infinium II methylation levels:\n- %u type I probes\n- %u type II probes\n- ', sum(inf_type), sum(~inf_type));
fprintf(fid_rep, '\n# Peak-based correction of Infinium II methylation levels\n');
fprintf(fid_rep, 'Number of samples:\t%u\n', size(data,2));
fprintf(fid_rep, 'Type I probes:\t%u\n', sum(inf_type));
fprintf(fid_rep, 'Type II probes:\t%u\n', sum(~inf_type));
fprintf(fid_rep, 'Sample correction method:\t');

if length(peak_correct) == 2 % each sample with the same peak-based correction
    if sum(peak_correct) == 2
        fprintf(1, 'unmethylated and methylated peaks\n');
        fprintf(fid_rep, 'unmethylated and methylated peaks\n');
    elseif peak_correct(1)
        fprintf(1, 'unmethylated peak\n');
        fprintf(fid_rep, 'unmethylated peak\n');
    else
        fprintf(1, 'methylated peak\n');
        fprintf(fid_rep, 'methylated peak\n');
    end
    
    peak_correct = repmat(peak_correct,size(data,2),1);    
    
elseif length(peak_correct) == size(data,2) % individual peak-based correction
    
    fprintf(1, 'samples corrected individually\n');
    fprintf(fid_rep, 'individual correction\n');
    
    peak_correct = repmat(peak_correct',1,2);
    for i=1:size(peak_correct,1)
        if peak_correct(i,1) == 0
            peak_correct(i,:) = [0,0];
        elseif peak_correct(i,1) == 1
            peak_correct(i,:) = [1,1];
        elseif peak_correct(i,1) == 2
            peak_correct(i,:) = [1,0];
        elseif peak_correct(i,1) == 3;
            peak_correct(i,:) = [0,1];
        else
            error('Peak-based correction: specify 0,1,2 or 3 for each sample')
        end
                
    end
else    
   error('Please check the input file for peak-based correction settings');
end


%% plot raw beta value distribution Infinium I vs II

if qc    
    if plots                
        for i=1:size(data,2)

            % NaN values ignored by ksdensity.m
            beta_inf_type = NaN(sum(~inf_type),2);
            % Infinium I
            beta_inf_type(1:sum(inf_type),1) = data(inf_type, i);                        
            % Infinium II
            beta_inf_type(:,2) = data(~inf_type, i);

            get_beta_kde(beta_inf_type, horzcat(prefix, '_design_type_beta_dist_sample_',num2str(sample_idx(i)) ,'.pdf'),...
                {horzcat('sample\_', num2str(sample_idx(i)), ' Inf I'), horzcat('sample\_', num2str(sample_idx(i)), ' Inf II')}, [0,0,1;1,0,0]);
        end
    else % plot all samples at once
               
        % for each sample: two columns with values of type I and type II                
        s1 = sum(inf_type);
        s2 = sum(~inf_type);
        beta_tester = NaN(max(s1, s2), 2*size(data,2));
        
        k = 1;
        for i=1:size(data,2)        

            beta_tester(1:s1, k) = data(inf_type,i);
            k=k+1;
            beta_tester(1:s2, k) = data(~inf_type,i);
            k=k+1;        
        end
               
        get_beta_kde(beta_tester, [prefix, '_design_type_beta_dist.pdf'], {['Inf I (' , num2str(sum(inf_type)) ,')'], ['Inf II (', num2str(sum(~inf_type)) ,')']}, [0,0,1;1,0,0]);    
    end
end 


%% convert beta values to M values (Du2010)

M = log2(data./(1-data));

%% peak estimation

% kde of M values for type I and type II

% kernel
% kernel = 'epanechnikov';
kernel = 'normal';

% bandwidth
% width = 0.2;
% width = 0;
% width = 0.5; % M-values
width = 0.05; % beta-values

% number of vectors
nbr = size(data,2);

% number of points used for kde
% default = 100
npoints = 200;

summits = zeros(4,2,nbr);
summits_M = zeros(4,2,nbr);

%%% data_copy = data;

% middle point
% t = 0;
t = 0.5;

% kde for each sample/column
for i=1:nbr
% for i=1:1
    
    %%% density estimation based on beta values!!
    
    % inf type I        
    % [f_I, x_I] = ksdensity(M(inf_type,i), 'kernel', kernel, 'width', width, 'npoints', npoints);
    [f_I, x_I] = ksdensity(data(inf_type,i), 'kernel', kernel, 'width', width, 'npoints', npoints);
    
    % inf type II
    % [f_II, x_II] = ksdensity(M(~inf_type,i), 'kernel', kernel, 'width', width, 'npoints', npoints);   
    [f_II, x_II] = ksdensity(data(~inf_type,i), 'kernel', kernel, 'width', width, 'npoints', npoints);
    
    % peak estimation (ideally 4 peaks)    
    
    % M-value of 0 corresponds to Beta-value of 0.5    
    
    % unmethylated peak summits
    [m, p] = max(f_I(x_I<t));
    S_u_I = x_I(p);
    
    %%%%%%%%%%    
    if abs(S_u_I - t) < 0.15        
        [m, p] = max(f_I(x_I<(t-0.15)));
        S_u_I = x_I(p);        
    end    
    %%%%%%%%%%   
    
    summits(1,1,i) = S_u_I;
    summits(1,2,i) = m;
    S_u_I = log2(S_u_I/(1-S_u_I));    
    summits_M(1,1,i) = S_u_I;
    % summits_M(1,1,i) = (2^S_u_I) / (2^S_u_I + 1);
    % check if the obtained summit is close to 0 - indicates wrong peak
    %{
    if abs(S_u_I) < 0.15
        [~, p] = max(f_I(x_I<-1));
        S_u_I = x_I(p);
    end
    %}
           
    [m, q] = max(f_II(x_II<t));
    S_u_II = x_II(q);
    %%%%%%%%%%    
    if abs(S_u_II - t) < 0.15        
        [m, q] = max(f_II(x_II<(t-0.15)));
        S_u_II = x_II(q);        
    end    
    %%%%%%%%%%   
    summits(2,1,i) = S_u_II;
    summits(2,2,i) = m;
    S_u_II = log2(S_u_II/(1-S_u_II));
    summits_M(2,1,i) = S_u_II;
    % summits_M(2,1,i) = (2^S_u_II) / (2^S_u_II + 1); 
    % check if the obtained summit is close to 0 - indicates wrong peak
    %{
    if abs(S_u_II) < 0.15
        [~, q] = max(f_II(x_II<-1));
        S_u_II = x_II(q);
    end
    %}
        
    % methylated peak summits
    
    [m, p] = max(f_I(x_I>t));
    x_I_dummy = x_I(x_I>t);
    S_m_I = x_I_dummy(p);
    
    %%%%%%%%%%    
    if abs(S_m_I - t) < 0.15        
        [m, p] = max(f_I(x_I>(t+0.15)));
        x_I_dummy = x_I(x_I>(t+0.15));
        S_m_I = x_I_dummy(p);
    end    
    %%%%%%%%%%    
    
    summits(3,1,i) = S_m_I;
    summits(3,2,i) = m;    
    S_m_I = log2(S_m_I/(1-S_m_I));     
    summits_M(3,1,i) = S_m_I;
    % summits_M(3,1,i) = (2^S_m_I) / (2^S_m_I + 1);
    
    [m, q] = max(f_II(x_II>t));
    x_II_dummy = x_II(x_II>t);
    S_m_II = x_II_dummy(q);
    
    %%%%%%%%%%    
    if abs(S_m_II - t) < 0.15        
        [m, q] = max(f_II(x_II>(t+0.15)));
        x_II_dummy = x_II(x_II>(t+0.15));
        S_m_II = x_II_dummy(q);
    end    
    %%%%%%%%%%  
    
    summits(4,1,i) = S_m_II;
    summits(4,2,i) = m;
    S_m_II = log2(S_m_II/(1-S_m_II));        
    summits_M(4,1,i) = S_m_II;
    % summits_M(4,1,i) = (2^S_m_II) / (2^S_m_II + 1);
    % correct and rescale M-values if type II
    
    % sigma_u_I = 0 - S_u_I;
    % sigma_u_II = 0 - S_u_II;    
    % sigma_m_I = S_m_I;
    % sigma_m_II = S_m_II;
    
    idx1 = M(:,i) >= 0;
    idx2 = M(:,i) < 0;
                
    
    % negative M-values (unmethylated)
    if peak_correct(i,1)                
        M((~inf_type & idx2),i) = M((~inf_type & idx2),i) / (S_u_II / S_u_I);
        %%% M((~inf_type & idx2),i) = (M((~inf_type & idx2),i)/(-S_u_II))*(-S_u_I);
    end

    if peak_correct(i,2)        
        % positive M-values (methylated)        
        M((~inf_type & idx1),i) = M((~inf_type & idx1),i) / (S_m_II / S_m_I);
    end

        
    %{
    M_inf = NaN(sum(~inf_type),2);
    M_inf(1:sum(inf_type,1),1) = M(inf_type,i);
    M_inf(:,2) = M(~inf_type,i);
    get_M_kde(M_inf, horzcat('QC_design_type_Mvals_corrected_sample_',num2str(i) ,'.pdf'), {'Infinium I', 'Infinium II'}, [0,0,1; 1,0,0]);    
    %}
    
    
    summits_M(:,2,i) = 0.3;
    % summits_M(:,2,i) = 3;
end


%% corrected beta-values

beta_all_corrected = 2.^M./(2.^M + 1);


%% plot corrected beta values

if qc    
    if plots        
        for i=1:size(beta_all_corrected,2)

            beta_cor = NaN(sum(~inf_type),2);
            beta_cor(1:sum(inf_type,1),1) = beta_all_corrected(inf_type,i);
            beta_cor(:,2) = beta_all_corrected(~inf_type,i);
            get_beta_kde(beta_cor, horzcat(prefix, '_design_type_beta_dist_corrected_sample_',num2str(sample_idx(i)) ,'.pdf'),...
                {horzcat('sample\_', num2str(sample_idx(i)), ' Inf I'), horzcat('sample\_', num2str(sample_idx(i)), ' Inf II')}, [0,0,1; 1,0,0]);
        end        
    else % plot all samples at once
        
        s1 = sum(inf_type);
        s2 = sum(~inf_type);
        
        beta_tester = NaN(max(s1, s2), 2*size(beta_all_corrected,2));    
        k = 1;
        for i=1:size(beta_all_corrected,2)        

            beta_tester(1:s1,k) = beta_all_corrected(inf_type,i);
            k=k+1;
            beta_tester(1:s2,k) = beta_all_corrected(~inf_type,i);
            k=k+1;        
        end
               
        get_beta_kde(beta_tester, [prefix, '_design_type_beta_dist_corrected.pdf'], {['Inf I (' , num2str(sum(inf_type)) ,')'], ['Inf II (', num2str(sum(~inf_type)) ,')']}, [0,0,1;1,0,0]);
    end    
end
    


end
