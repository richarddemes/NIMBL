function [nimbl_gene_collect_names, nimbl_gene_collect_coords] = get_genomic_coords(nimbl_gene_input, ucsc_file, fid_rep)

%%% function [D, genes_input, genes_input_split, nimbl_gene_collect_names, nimbl_gene_collect_coords, no_match, gene_symbols_all_split, gene_symbols_all] = get_genomic_coords(nimbl_gene_input, ucsc_file)
%%% function [genes, genes2, C] = get_genomic_coords(nimbl_gene_input, coord_file, del, fid_rep)


% get for each input row the relevant coordinates
% input can be:
% - gene name
% - accession ID
% - accession ID + txStart (delimited by ';')
% - genomic region: chr;start pos;end pos (UCSC table is ignored)
%
% generate numeric table with all coordinates needed for stem plot later or
% for probe_alignment
%


%% regular expressions for colum headers
%  - based on Schema for RefSeq Genes

% Reference sequence chromosome or scaffold
c_chr = 'chrom';

% transcription start 
c_txS = 'txstart';

% transcription end
c_txE = 'txend';

% strand: positive or negative
c_strand = 'strand';

% gene name: Alternate name (e.g. gene_id from GTF)
% only 1 gene name is given, so it can be that specified gene is not found,
% but transcript_ID is given in UCSC table (name)
c_gene_symbol = '^name2$';

% Name of gene (usually transcript_id from GTF) - NM_... or NR_...
c_accession = '^name$';

% Coding region start
c_cdsS = 'cdsstart$';

% Coding region end
c_cdsE = 'cdsend$';

% Exon start positions
% c_ExS = 'exonstart';

% Exon end positions
% c_ExE = 'exonEnd';


%% process input for nimbl_gene
%  input can be within a cell array or provided by a file


% genes are specified in file if only one string is specified
if ischar(nimbl_gene_input)
    fid = fopen(nimbl_gene_input);
        
    genes_input = textscan(fid,'%s','delimiter', '\n');
    genes_input = [genes_input{:}];
    
    fclose(fid);    
    
    fprintf(fid_rep, '\n# NIMBL-gene input data from file:\t%s\n', nimbl_gene_input);
    fprintf(fid_rep, 'Number of entries:\t%u\n\n', size(genes_input, 1));
    
else % entries specified in cell array
    genes_input = nimbl_gene_input;
        
    % create column vector
    if size(genes_input, 1) < size(genes_input, 2)
        genes_input = genes_input';
    end    
    
    fprintf(fid_rep, '\n# NIMBL-gene input data as specified within global input file\n');
    fprintf(fid_rep, 'Number of entries:\t%u\n\n', size(genes_input, 1));    
end

% different parts of input entries to be delimited by ';'
genes_input_split = regexp(genes_input, ';', 'split');
genes_input_length = cellfun(@length, genes_input_split);

% check if UCSC data is needed
% UCSC refgene table is not needed if only genomic regions are specified
if all(genes_input_length >= 3)
    ucsc_read = false;
    fprintf(1, '\n- Assume that all input values for NIMBL are user-defined genomic regions, hence, no UCSC table loaded.\n');
else
    ucsc_read = true;
end


%% read USCS data: refGene table

if ucsc_read

    fprintf(1, '\n# UCSC refgene data:\n');
    fprintf(1, '- Importing data from: %s ... \n',ucsc_file);
    fprintf(fid_rep, '# UCSC gene transcript input file:\t%s\n', ucsc_file);


    fid = fopen(ucsc_file);
    
    % one string
    header = fgetl(fid);
    
    % number of columns, delimiter '\t'
    header = regexp(header, '\t', 'split');
    l = length(header);
    
    format = repmat('%s ', 1, l);
    D = textscan(fid, format, 'delimiter', '\t');

    % one cell array
    D = [D{:}];

    fclose(fid);
    
    fprintf(fid_rep, 'Number of entries:\t%u\n\n', size(D,1));

    % columns in refGene table:
    chr_idx = not(cellfun(@isempty, regexpi(header,c_chr)));
    txS_idx = not(cellfun(@isempty, regexpi(header,c_txS)));
    txE_idx = not(cellfun(@isempty, regexpi(header,c_txE)));
    strand_idx = not(cellfun(@isempty, regexpi(header,c_strand)));
    gene_symbol_idx = not(cellfun(@isempty, regexpi(header,c_gene_symbol)));
    accession_idx = not(cellfun(@isempty, regexpi(header,c_accession)));
    cdsS_idx = not(cellfun(@isempty, regexpi(header,c_cdsS)));
    cdsE_idx = not(cellfun(@isempty, regexpi(header,c_cdsE)));    
    %%% ExS_idx = not(cellfun(@isempty, regexpi(header,c_ExS)));
    %%% ExE_idx = not(cellfun(@isempty, regexpi(header,c_ExE)));
        
    % convert strings to numerical values  
    txS_all = sscanf(sprintf('%s*', D{:, txS_idx}), '%d*');
    txE_all = sscanf(sprintf('%s*', D{:, txE_idx}), '%d*');
    cdsS_all = sscanf(sprintf('%s*', D{:, cdsS_idx}), '%d*');
    cdsE_all = sscanf(sprintf('%s*', D{:, cdsE_idx}), '%d*');
    
    % convert chromosomes (chr1, chrX, chr22, chrY,...) to numeric values
    chr_all = regexprep(D(:, chr_idx), 'chr', '');    
    chr_all = regexprep(chr_all, 'x', '23', 'ignorecase'); % chrX
    chr_all = regexprep(chr_all, 'y', '24', 'ignorecase'); % chrY   
    chr_all = sscanf(sprintf('%s*', chr_all{:}), '%d*');
    
    % convert strand to numeric value
    strand_all = regexprep(D(:, strand_idx), '+', '1');
    strand_all = regexprep(strand_all, '-', '0');
    strand_all = sscanf(sprintf('%s*', strand_all{:}), '%d*');
        
    % collect all main gene symbols (1st entry in gene symbols list)
    gene_symbols_all_split = regexp(D(:, gene_symbol_idx), '\|', 'split');
    % first entries are 'main' symbols, which are in 2nd position, first
    % split is empty since all names are within '|'
    gene_symbols_all_first = cellfun(@(x) x{2}, gene_symbols_all_split, 'UniformOutput', 0);
        
    % some overhead, should pay off especially with more gene symbols as
    % input, this index will allow exact search instead of using a regular
    % expression
    gene_symbols_all = cellfun(@(x) x(2:end-1), gene_symbols_all_split, 'UniformOutput', 0);
    a = cellfun(@length, gene_symbols_all);
    gene_symbols_all = [gene_symbols_all{:}]';
    
    idx_symbols = zeros(sum(a),1);
    pos = 1;
    for i=1:length(a)       
        idx_symbols(pos:pos + a(i) - 1) = i;
        pos = pos + a(i);
    end
    
    
    % format for ucsc information
    format = repmat('%s\t', 1, l-1);
    format = ['%s\t%u\t', format, '%s\n'];

    fprintf(fid_rep, '# Gene transcripts found by gene symbols or accession IDs within UCSC input file:\n\n');

    % print header
    fprintf(fid_rep, ['Input value\tSelected\t', repmat('%s\t', 1, l-1), '%s\n'], header{:});
    
end


%% Process all input rows

nimbl_gene_collect_names = cell(length(genes_input), 4);
% 1. input value
% 2. gene symbol (first entry or including all synonyms)
% 3. accession ID (NM, NR)
% 4. name used for naming the files

nimbl_gene_collect_coords = zeros(length(genes_input), 6);
% 1. chr
% 2. strand (always positive for user-defined region)
% 3. start of region: txS or start of user-defined genomic region
% 4. end of region: txE or end of user-defined region
% 5. cdsS if UCSC hit (0 for user-defined genomic regions)
% 6. cdsE if UCSC hit (0 for user-defined genomic regions)

% collect input values for which no match is found
no_match = false(length(genes_input), 1);

fprintf(1, '\n# Processing input values:\n');

for i=1:length(genes_input)
   
    nimbl_gene_collect_names{i} = genes_input{i};    
    fprintf(1, '- Process input: %s\n', genes_input{i});
    
    % genomic region with or without name
    if genes_input_length(i) >= 4
                               
        if genes_input_length(i) == 4 % no name
            
            % create name from input values
            
            if strcmpi(genes_input_split{i}{1}, 'x')
                chr_name = 'X';
                genes_input_split{i}{1} = '23';
            elseif strcmpi(genes_input_split{i}{1}, 'y')
                chr_name = 'Y';
                genes_input_split{i}{1} = '24';
            else
                chr_name = genes_input_split{i}{1};
            end
                       
            if strcmp(genes_input_split{i}{2}, '+')
                strand_char = 'plus';
                strand_val = 1;
            elseif strcmp(genes_input_split{i}{2}, '-')
                strand_char = 'minus';
                strand_val = 0;
            else
                error('Specify strand for genomic region as ''+'' (positive, plus, forward) or ''-'' (negative, minus, reverse)');
            end
                        
            % nimbl_gene_collect_names{i,4} = ['Region_chr', chr_name, '_', genes_input_split{i}{2}, '_', genes_input_split{i}{3}];
            % include strand info
            nimbl_gene_collect_names{i,4} = ['Region_chr', chr_name, '_', strand_char, '_', human_readable(str2double(genes_input_split{i}{3})), '_', human_readable(str2double(genes_input_split{i}{4}))];
            % vals = sscanf(sprintf('%s*', genes_input_split{i}{1:3}), '%d*');
            vals = sscanf(sprintf('%s*', genes_input_split{i}{[1,3,4]}), '%d*');
            
        else % specific region name provided
            nimbl_gene_collect_names{i,4} = genes_input_split{i}{1};
            % vals = sscanf(sprintf('%s*', genes_input_split{i}{2:4}), '%d*');
            vals = sscanf(sprintf('%s*', genes_input_split{i}{[2,4,5]}), '%d*');
            
            if strcmp(genes_input_split{i}{3}, '+')                
                strand_val = 1;
            elseif strcmp(genes_input_split{i}{3}, '-')
                strand_val = 0;
            else
                error('Specify strand for genomic region as ''+'' (positive, plus, forward) or ''-'' (negative, minus, reverse)');
            end
        end

        
        if vals(2) >= vals(3)
            fprintf(1, 'WARNING: start position (%u) of genomic region needs to be smaller than end position (%u).\n', vals(2:3));
            no_match(i) = true;
           
        elseif (vals(1) > 24) || (vals(1) < 1)
            
            fprintf(1, 'WARNING: chromosome of genomic region (%u) needs to be within [1,24] or X, Y.\n', vals(1));
            no_match(i) = true;
        
        else
            % keep genomic coordinates
            nimbl_gene_collect_coords(i, [1,3,4]) = vals;
        
            % decode strand info
            nimbl_gene_collect_coords(i, 2) = strand_val;
        end
        
        
    % NM_ NR_ identifier with txStart    
    elseif genes_input_length(i) == 2
                
        % search in ucsc table
        idx = find(strcmp(genes_input_split{i}{1}, D(:,accession_idx)));
        
        % at least one match
        if any(idx)
            
            % search for specific txS
            txS_wanted = str2double(genes_input_split{i}{2});

            txS_hit = find((txS_all(idx) == txS_wanted));            

            % txS not found
            if isempty(txS_hit)
               
                fprintf(1, 'WARNING: no match found for txStart site (%u) and accession ID (%s), choose first match\n', txS_wanted, genes_input_split{i}{1});
                
                % use first one of all matches independent of txStart site
                % despite having the wrong txS site
                txS_hit = 1;
                
            % more than one accession ID starts with the same txStart    
            elseif length(txS_hit) > 1

                fprintf(1, 'WARNING: %u matches found for txStart site (%u) and accession ID (%s), choose first match.\n', length(txS_hit), txS_wanted, genes_input_split{i}{1});
                txS_hit = 1;
            end            
           
            nimbl_gene_collect_names{i,2} = D{idx(txS_hit), gene_symbol_idx};
            nimbl_gene_collect_names{i,3} = genes_input_split{i}{1};            
            % nimbl_gene_collect_names{i,4} = [D{idx(txS_hit), chr_idx}, '_', gene_symbols_all_first{idx(txS_hit)}, '_', genes_input_split{i}{1}, '_UCSCtxS_', human_readable(txS_all(idx(txS_hit))+1)];
            % skip chr tag at beginning
            nimbl_gene_collect_names{i,4} = [gene_symbols_all_first{idx(txS_hit)}, '_', genes_input_split{i}{1}, '_UCSCtxS_', human_readable(txS_all(idx(txS_hit))+1)];
            
            
            nimbl_gene_collect_coords(i,:) = [chr_all(idx(txS_hit)), strand_all(idx(txS_hit)), txS_all(idx(txS_hit)), txE_all(idx(txS_hit)), cdsS_all(idx(txS_hit)), cdsE_all(idx(txS_hit))];
            
            % report all related transcripts
            idx_chosen = zeros(length(idx), 1);
            idx_chosen(txS_hit) = 1;
            
            for j=1:length(idx)
                fprintf(fid_rep, format, genes_input{i}, idx_chosen(j), D{idx(j),:});
            end 
            
        else % no match found for accession ID            
            no_match(i) = true;
            fprintf(1, 'WARNING: no match found for accession ID: %s\n', genes_input_split{i}{1});
        end
        
    % gene symbol, accession ID (NM_, NR_) or anything else (e.g. 3x ';')   
    else
        s = genes_input{i};
        
        % some gene symbols have only one character, e.g. 'T'
        % if strcmp(s(1:3), 'NM_') || strcmp(s(1:3), 'NR_')
        % use strncmp instead
        
        % test if input is accession ID
        if strncmp('NM_', s, 3) || strncmp('NR_', s, 3)
            
            idx = find(strcmp(genes_input{i}, D(:,accession_idx)));

            if ~isempty(idx)

                if length(idx) > 1
                    fprintf(1, 'WARNING: %u matches found for accession ID: %s, choose first match\n', length(idx), genes_input{i});
                end

                % choose by default the first hit
                nimbl_gene_collect_names{i,2} = D{idx(1), gene_symbol_idx};
                nimbl_gene_collect_names{i,3} = genes_input{i};
                % use the main symbol of the gene                
                % nimbl_gene_collect_names{i,4} = [D{idx(1), chr_idx}, '_', gene_symbols_all_first{idx(1)}, '_', genes_input{i}, '_UCSCtxS_', human_readable(txS_all(idx(1))+1)];
                % skip chr tag at beginning
                nimbl_gene_collect_names{i,4} = [gene_symbols_all_first{idx(1)}, '_', genes_input{i}, '_UCSCtxS_', human_readable(txS_all(idx(1))+1)];

                nimbl_gene_collect_coords(i,:) = [chr_all(idx(1)), strand_all(idx(1)), txS_all(idx(1)), txE_all(idx(1)), cdsS_all(idx(1)), cdsE_all(idx(1))];

                % report all related transcripts
                idx_chosen = zeros(length(idx), 1);
                idx_chosen(1) = 1;
                for j=1:length(idx)
                    fprintf(fid_rep, format, genes_input{i}, idx_chosen(j), D{idx(j),:});
                end                

            else
                fprintf(1, 'WARNING: no match found for accession ID: %s\n', genes_input{i});
                no_match(i) = true;
            end
            
            
        % search for a gene symbol
        else
            
            % perform exact search
            idx = idx_symbols(strcmp(genes_input{i}, gene_symbols_all));
            
            % multiple matches are possible
            if ~isempty(idx)
                
                idx_chosen = zeros(length(idx), 1);
                
                % multiple matches are possible
                if length(idx) > 1
                    fprintf(1, 'WARNING: %u matches found for gene symbol: %s, choose longest transcript', length(idx), genes_input{i});
                    
                    % find longest transcript
                    % If there are several identical maximum values, the index of the first one found is returned.
                    [max_test, m_idx] = max((txE_all(idx) - txS_all(idx)));
                    
                    % report if several tarnscripts of the same length
                    mult_max = sum(max_test == (txE_all(idx) - txS_all(idx)));
                    if  mult_max > 1
                        fprintf(1, ' (%u transcripts of the same length: %u).\n',mult_max, max_test);                        
                    else
                        fprintf(1, '.\n');                        
                    end
                else
                    m_idx = 1;
                end
                
                % choose only one transcript
                idx_chosen(m_idx) = 1;
                
                % report all related transcripts
                for j=1:length(idx)
                    fprintf(fid_rep, format, genes_input{i}, idx_chosen(j), D{idx(j),:});
                end
                
                nimbl_gene_collect_names{i,2} = D{idx(m_idx), gene_symbol_idx};
                nimbl_gene_collect_names{i,3} = D{idx(m_idx), accession_idx};
                % use the user-specified gene symbol for the name of this
                % region
                % nimbl_gene_collect_names{i,4} = [D{idx(m_idx), chr_idx}, '_', genes_input{i}, '_', D{idx(m_idx), accession_idx}, '_UCSCtxS_', human_readable(txS_all(idx(m_idx)) +1)];
                % skip chr tag at beginning
                nimbl_gene_collect_names{i,4} = [genes_input{i}, '_', D{idx(m_idx), accession_idx}, '_UCSCtxS_', human_readable(txS_all(idx(m_idx)) +1)];
                
                nimbl_gene_collect_coords(i,:) = [chr_all(idx(m_idx)), strand_all(idx(m_idx)), txS_all(idx(m_idx)), txE_all(idx(m_idx)), cdsS_all(idx(m_idx)), cdsE_all(idx(m_idx))];
                
            else
                fprintf(1, 'WARNING: no match found for gene symbol: %s\n', genes_input{i});
                no_match(i) = true;
            end
        end
    end
end


%% Remove 'bad' entries from collected data

if any(no_match)
    nimbl_gene_collect_coords(no_match,:) = [];
    nimbl_gene_collect_names(no_match,:) = [];
end


%% make UCSC txS and cdsS 1-based
%  UCSC provides 0-based coordinates for the start positions (txS and cdsS)

idx = find(nimbl_gene_collect_coords(:,5) ~= 0);
nimbl_gene_collect_coords(idx,[3,5]) = nimbl_gene_collect_coords(idx,[3,5]) + 1;


%% report table with genomic regions

% no cdS position set for these user-defined regions
idx = find(nimbl_gene_collect_coords(:,5) == 0);

if idx
    fprintf(fid_rep, '\n# Genomic regions:\n\n');
    
    % header
    fprintf(fid_rep, 'Input value\tChromosome\tStart position\tEnd position\n');
    
    % values
    for i=1:length(idx)
        fprintf(fid_rep, '%s\t%u\t%u\t%u\n', nimbl_gene_collect_names{idx(i), 1}, nimbl_gene_collect_coords(idx(i), [1,3,4]));
    end
    
end


%% report list of input values that could not be processed or did not match

if any(no_match)
    fprintf(fid_rep, '\n# List of input values which are not found in UCSC input file or are incorrect (use '';'' as delimiter):\n');
    
    idx = find(no_match);
    
    for i=1:sum(no_match)
        fprintf(fid_rep, '%s\n', genes_input{idx(i)});
    end
end



end


function out_string = human_readable(input_number)

out_string = sprintf(',%c%c%c',fliplr(num2str(input_number)));
out_string = fliplr(out_string(2:end));

end