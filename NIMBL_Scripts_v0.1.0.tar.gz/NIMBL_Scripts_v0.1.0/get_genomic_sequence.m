function [seq] = get_genomic_sequence(filename, filename_s, chr, start_pos, end_pos, print_seq_fname)

% [seq] = get_genomic_sequence(filename, filename_s, chr, start_pos, end_pos, print_seq_fname)
% 
% extract genomic chromosomal sequence from genome
% 
% IN:
% - filename: (string) name of multifasta file with each chr seq
% - filename_s: (sring) name of file with length of each chr seq
% - chr: (integer) chromsome of wanted seq
% - start_pos: (integer) chromosomal start position
% - end_pos: (integer) chromosomal end position
% - print_seq_fname: (string) optional file name to store seq extracted 
% 
% OUT:
% - seq: (string) extracted seq
% - fasta file with extracted seq


fid= fopen(filename,'r');
if fid == -1
    error('Could not open file');
end

% start_pos must be smaller than end_pos
if (start_pos >= end_pos)
    error('Start position of sequence must be smaller than end position');
end


% length of sequence
seq_length = end_pos - start_pos + 1;


%% calculate offset

% offset of each chromosome header ('>chr12') in bytes
s_header = zeros(24,1);
% '>chr' - constant size of 4 bytes and '\n' is 1 byte
const = 5;
% chr1...9
for i=1:9    
    s_header(i) = const + 1;    
end
% chr10..22
for i=10:22
    s_header(i) = const + 2;
end
% chrX and chrY
for i=23:24
    s_header(i) = const + 1;
end


% number of bases per line (UCSC deafult = 50)
tline = fgetl(fid); % header
tline = fgetl(fid);
n = length(tline);

% read size of chromosomes from file
s = dlmread(filename_s);

% offset in bytes due to length of chromosomes
chr_s = zeros(24,1); 

for i=1:24
    % number of nt + 1 byte for each line ('\n')            
    chr_s(i) = s(i) + ceil(s(i) / n);
end


% calculate offset depending on chromosomal position
if chr == 1
    offset = s_header(1);    
else
    offset = sum(s_header(1:chr)) + sum(chr_s(1:chr-1));
end


%% begining of sequence in chromosome
% one nt uses 1 byte, '\n' uses 1 byte as well

start_pos_new = pos_finder(start_pos, n);


%% jump one position before start of sequence

fseek(fid, offset + start_pos_new, 'bof');


%% calculate number of bytes to read
%  include number of bytes for newlines
if (end_pos <= n)
    length_offset = 0;    
else
    length_offset = ceil((seq_length - (mod(end_pos,n)))  / n);
end


% read complete sequence
seq = fread(fid, seq_length + length_offset, 'uint8=>char')';


% optional output of sequence
if (print_seq_fname)
    fid2 = fopen(print_seq_fname,'w');
    if fid == -1
        error('Could not open file');
    end 
    
    fprintf(fid2, '%s\n',seq);
    
    fclose(fid2);
    
end


% delete newlines, obtain one string of nucleotides

% very slow:
% seq = regexprep(seq, '\n', ''); 

% quick:
pos_nl = regexp(seq, '\n', 'start');
seq(pos_nl) = [];


if (length(seq) ~= seq_length)
    error('retrieved sequence has not the right length');
end


fclose(fid);


end


function [pos_out] = pos_finder(pos_in, n)

% find starting position: include number of '\n'

if (pos_in < n)
    pos_out = pos_in - 1;
else
    pos_mod = mod(pos_in, n);
    pos_lines = floor(pos_in/n);
    
    if (pos_mod == 0) % last position in line
        pos_out = n * pos_lines + pos_lines - 2;
    else
        pos_out = n * pos_lines + pos_lines + pos_mod - 1;
    end   
end

end