function [overview, overview_bin, s_all] = differential_methylation(beta_all, groups, beta_dist, mask_frac, limit1, limit2)

% [overview, overview_bin, s_all] = differential_methylation(beta_all, groups, beta_dist, mask_frac, limit1, limit2)
%
% Compute differentially methylated CpG sites
%
% IN:
% - beta_all: beta values for each analysed CpG site
% - groups: (integer) column vector defining two groups of samples
% - beta_dist: minimal beta value distance between non-overlapping groups of samples
% - mask_frac: column vector with fraction of samples that can be masked
%   from analysis (outliers) for each group
% - limit1: column vector with limits on median beta value of group1
% - limit2: column vector with limits on median beta value of ggroup2
%
% OUT:
% - overview matrix, columns:
%   1: initial intergroup distance group 1 vs 2 (0 if groups overlap)
%   2: initial median group1
%   3: initial median group2
%   4: initial median difference group 1 vs 2
%   5: number of masked samples group1
%   6: number of masked samples group2
%   7: number of masked samples in both groups
%   8: intergroup distance (after masking, if any)
%   9: median group1 (after masking, if any) 
%  10: median group2 (after masking, if any)
%  11: absolute median difference
%  12: binary vector: median group1 > median group2
%  13: score
%
% - overview_bin - binary matrix to select candidates based on mposed constraints,
%   use 3rd dim for the two groups, columns:
%   1: intergroup distance > beta_dist  (only first dim used)
%   2: median of groups in specified limits
% 
% - s_all: binary matrix: which samples were masked (0) for each CpG site
%          and which were kept (1)
%   


%% compute statistics
    
overview = zeros(size(beta_all,1), 13);
% overview_bin = false(size(beta_all,1), 2, 2);
overview_bin = true(size(beta_all,1), 2, 2);

% samples in group1:
idx1 = groups == 1;

% samples in group2:
idx2 = groups == 2;

% initial intergroup distance
% 0 if groups overlap
r = get_group_diff(idx1, idx2, beta_all);
overview(:,1) = r;

b1 = beta_all(:,idx1);
b2 = beta_all(:,idx2);

% size information for groups
n1 = size(b1);
n2 = size(b2);

% median
%%% m1 = median(b1, 2);
%%% m2 = median(b2, 2);

% beta values could be missing (flagged as NaN)
m1 = nanmedian(b1, 2);
m2 = nanmedian(b2, 2);


overview(:,2) = m1;
overview(:,3) = m2;

% absolute value
median_diff = abs(m2 - m1);
overview(:,4) = median_diff;


%% Absolute distance to median

c1 = abs(b1 - repmat(m1, 1, size(b1,2)));
c2 = abs(b2 - repmat(m2, 1, size(b2,2)));


%% masking of most distant samples

% maximal number of masked samples
% e.g. 4 (group1) vs 0 (group2)
k_vals = [floor(size(b1,2)*mask_frac(1)),floor(size(b2,2)*mask_frac(2))];

% maximal total number of maskings in one probe
s = sum(k_vals);

% info if masking (still) possible for this group1 and group2 (column vector)
k1 = repmat(k_vals(1)>0, size(b1,1), 1);
k2 = repmat(k_vals(2)>0, size(b1,1), 1);

%%%%%%%%%%%

% check NaN values if any in groups
% these samples are considered as deleted in the group
% although not reported as masked, they are just not existent
% but they count as masked samples

%{
sum(sum(b1))
sum(sum(b2))

sum(k1)
sum(k2)
%}

p1 = sum(isnan(b1),2);
p2 = sum(isnan(b2),2);


k1 = k1 & (p1 < k_vals(1));
k2 = k2 & (p2 < k_vals(2));

%%% sum(k1)
%%% sum(k2)

% entries already set as NaN
% c1(isnan(b1)) = NaN;
% c2(isnan(b2)) = NaN;



%%%%%%%%%%%


% number of maskings
masked1 = zeros(size(b1,1),1);
masked2 = zeros(size(b1,1),1);

% which of three masking-cases, see below
k_test = false(size(b1,1),3);

% initial intergroup distances
r2 = r;

% for each possible masking of a sample in one group
for i=1:s
    
    % compare binary vectors
    k_test(:,1) = k1 < k2; % masking in group2
    k_test(:,2) = k1 > k2; % masking in group1
    k_test(:,3) = k1 & k2; % masking in group1 or group2
    % k_test(:,4) = ~any([k1 k2],2); % no masking at all
    
    % all CpG sites where a sample can be masked
    idx_all = any(k_test,2) & r2 < beta_dist;
            
    
    % 3 cases of masking: depending on number that can be masked in each
    % group
    for j=1:3
        
        % CpG sites relevant for one of the 3 cases
        idx = find(k_test(:,j) & r2 < beta_dist);
        
                 
        if idx
        
            % handle cases
            if j==1 % mask samples in group2

                % for EACH site the position within the CpG site vector
                [~,ix] = max(c2,[],2);

                % get linear indices of samples with highest distance to
                % median
                tix = sub2ind(n2,(1:n2(1))',ix);

                % mark furthest sample
                % choose only these CpG sites / rows that are relevant for this case:
                % given by idx
                c2(tix(idx)) = NaN;
                b2(tix(idx)) = NaN;

                % report masking
                masked2(idx) = masked2(idx) + 1;

                % update if masking still possible
                k2(idx) = masked2(idx) < k_vals(2);            


            elseif j==2 % mask samples in group1
                
                [~,ix] = max(c1,[],2);
                
                tix = sub2ind(n1,(1:n1(1))',ix);
                
                c1(tix(idx)) = NaN;
                b1(tix(idx)) = NaN;

                % report masking
                masked1(idx) = masked1(idx) + 1;

                % update if masking still possible
                k1(idx) = masked1(idx) < k_vals(1);


            elseif j==3 % samples can be masked in group1 or group2
                
                % mask furthest sample
                % compare max from c1 and c2

                [max1,ix1] = max(c1,[],2);
                [max2,ix2] = max(c2,[],2);

                ix_comp = max1 > max2;                
                

                %% masking in group1
                
                % incorporate extra information 
                idx_cpg = find(k_test(:,j) & r2 < beta_dist & ix_comp);

                % linear indices of samples with highest distance to median
                tix = sub2ind(n1,(1:n1(1))',ix1);

                % mark furthest sample                             
                c1(tix(idx_cpg)) = NaN;
                b1(tix(idx_cpg)) = NaN;
                
                % report masking                
                masked1(idx_cpg) = masked1(idx_cpg) + 1;
                
                % update k1                
                k1(idx_cpg) = masked1(idx_cpg) < k_vals(1);

                %% masking in group2
                
                idx_cpg = find(k_test(:,j) & r2 < beta_dist & ~ix_comp);
                
                % linear indices of samples with highest distance to mean
                tix = sub2ind(n2,(1:n2(1))',ix2);

                % mark furthest sample
                c2(tix(idx_cpg)) = NaN;
                b2(tix(idx_cpg)) = NaN;
                
                % report masking                
                masked2(idx_cpg) = masked2(idx_cpg) + 1;
                
                % update k2
                k2(idx_cpg) = masked2(idx_cpg) < k_vals(2);

            % else % no maskings allowed in any group
            end            
        end
   end
    
    
    % b1 and b2 are now updated
    % calculate new intergroup distance across all sites    
    
    % update all ranges, min and max functions ignore NaN values
    min2_all = min(b2,[],2);
    max2_all = max(b2,[],2);
    
    min1_all = min(b1,[],2);
    max1_all = max(b1,[],2);
    
    a = min2_all - max1_all;
    
    % [group 1] [group2]
    t1 = idx_all & a > 0;
    r2(t1) = a(t1);
    
    % [group 2] [group 1] or still overlapping and r2 < 0
    t2 = idx_all & a <= 0;
    r2(t2) = min1_all(t2) - max2_all(t2);        
    
end


%% report results

% number of masked samples for each group
overview(:,5) = masked1;
overview(:,6) = masked2;
overview(:,7) = masked1 + masked2;

% set 0 for negative intergroup distances (if groups still overlap) 
r2(r2<0) = 0;

% final intergroup distance after masking procedure
overview(:,8) = r2;


%% which samples masked at each site

samples1 = ~isnan(c1);
samples2 = ~isnan(c2);

% merge masked samples
s_all = false(size(beta_all));
s_all(:,idx1) = samples1;
s_all(:,idx2) = samples2; 



%% mark CpG sites with large enough intergroup distance

overview_bin(:,1,1) = overview(:,8) >= beta_dist;

    

%% check if median (after possible masking) is within limits if specified


% median after masking (if any)
m1 = nanmedian(b1,2);
m2 = nanmedian(b2,2);


% report new median differences
overview(:,9) = m1;
overview(:,10) = m2;
overview(:,11) = abs(m1-m2);
% median group1 > median group2
overview(:,12) = m1 > m2;


% group1
if (sum(limit1 == [0,1]) < 2)    
    overview_bin(:,2,1) = (m1 >= limit1(1)) & (m1 <= limit1(2));    
end


% group2
if (sum(limit2 == [0,1]) < 2)    
    overview_bin(:,2,2) = (m2 >= limit2(1)) & (m2 <= limit2(2));    
end


%% scoring procedure
%  score = intergroup dist - (median diff - intergroup dist)

overview(:,13) = overview(:,8) - (overview(:,11) - overview(:,8));



end



function [r] = get_group_diff(idx1, idx2, betas)   

% compute intergroup distance across all CpG sites

% beta values group1 
b1 = betas(:,idx1);
% beta values group2
b2 = betas(:,idx2);

range_b1 = [min(b1,[],2), max(b1,[],2)];
range_b2 = [min(b2,[],2), max(b2,[],2)];

% min group2 - max group 1
a = range_b2(:,1) - range_b1(:,2);
% min group 1 - max group 2
b = range_b1(:,1) - range_b2(:,2);

k1 = a > 0;
k2 = b > 0;


r = zeros(size(betas,1),1);
% if r == 0 then ranges are overlapping

% higher methylation level group2
r(k1) = a(k1);
% higher methylation level group1
% k2 does not overwrite values, only one scenario possible
r(k2) = b(k2);    

end


