function preprocess_gene_info(input_script)

% function preprocess_annotation(input_script)
% 
% include gene synonyms within gene prediction table from UCSC
% - UCSC table is used for gene information (txStart, cdsStart,...)
% - UCSC table contains only one gene name/symbol (refseq gene name, column 'name2')
% - expand the alternate name columns with information from NCBI gene_info
% 
% check overlap with 450k annotation file
% - gene symbols ('UCSC_RefGene_Name')
% - gene accessions ('UCSC_RefGene_Accession'), NM_... and NR_...
%
% currently only works for 450k file
% 
% OUT:
% - text file with expanded gene prediction table
% - report file, includes:
%   - gene symbols of 450k annotation file that are not in the gene_info file
%   - gene accessions of 450k annotation file that are not in the UCSC gene prediction table


% version
nimbl_version = 'v0.1.0';

fprintf(1, '\nPreprocessing gene info (%s):\n---------------------------------\n', nimbl_version);


%% include user-defined input

eval(input_script);

if platform == 1
    error('This script currently only works for 450k annotation data.');
end

%% variables

% 450k values
% column index of gene symbols, 'UCSC_RefGene_Name'
% 27k default = 1
% 450k default = 22
% col_gene_symbol = 22;
% use column header
col_gene_symbol = 'UCSC_RefGene_Name';


% column index of gene accessions 'UCSC_RefGene_Accession'
% 27k default = 4
% 450k default = 23
% col_gene_acc = 23;
% column header
col_gene_acc = 'UCSC_RefGene_Accession';


% default annotation files
a_27k = 'Infinium_27k_annotation.txt';
a_450k = 'Infinium_450k_annotation.txt';


% column header of gene name in UCSC refgene table: Alternate name (e.g. gene_id from GTF)
c_gene_refgene = '^name2$';

% column header for gene transcript ID in UCSC table: Name of gene (usually transcript_id from GTF)
c_gene_transcript = '^name$';


% filename of updated UCSC refgene table
% these are the default names used in module nimbl_gene as parameters for 
% calling 'get_transcript_coords'

if platform == 1
    ucsc_file_new = 'ucsc_hg18_refgene_table.txt';
else % platform == 2
    ucsc_file_new = 'ucsc_hg19_refgene_table.txt';
end


%% report file for preprocessing

fid_rep = fopen('preprocess_gene_info_report.txt', 'w');
fprintf(fid_rep, 'Preprocessing gene info (%s)\n\n', nimbl_version);


%% read gene information from annotation file
%  - read only two columns of annotation file

if (isempty(annot_file)) % use default annotation file
    
    if platform == 1        
        annot_file = a_27k;
    elseif platform == 2
        annot_file = a_450k;
    else
        error('Please specify ''1'' or ''2'' to select an Infinium platform')
    end
end

fid = fopen(annot_file);

header_annot = fgetl(fid);
header_annot = regexp(header_annot, input_del, 'split');

col_gene_symbol_idx = find(not(cellfun(@isempty, regexpi(header_annot, col_gene_symbol))));
col_gene_acc_idx = find(not(cellfun(@isempty, regexpi(header_annot, col_gene_acc))));


fprintf(1, '- Importing array annotation data from: %s ... \n', annot_file);
fprintf(1, '\t- Found ''%s'' in column %u of annotation table\n', col_gene_symbol, col_gene_symbol_idx);
fprintf(1, '\t- Found ''%s'' in column %u of annotation table\n', col_gene_acc, col_gene_acc_idx);

% build format string from column indices 
s1 = repmat('%*s', 1, min([col_gene_symbol_idx, col_gene_acc_idx]) - 1);
s2 = repmat('%*s', 1, abs(col_gene_symbol_idx - col_gene_acc_idx) - 1);

gene_info_array = textscan(fid, [s1, '%s', s2, '%s%*[^\n]'], 'delimiter', input_del);
gene_info_array = [gene_info_array{:}];

fclose(fid);

fprintf(fid_rep, '# Array annotation input file:\t%s (%u rows)\n', annot_file, size(gene_info_array, 1));


%% read UCSC gene prediction table (refGene table)

if platform == 1
    
    % TODO: 'hg18_refgene_table.txt'
    
elseif platform == 2    
    
    fid = fopen(refgene_ucsc_table);
    % one string
    header = fgetl(fid);
    fclose(fid);

    % number of columns, delimiter of NCBI file is \t
    l_ucsc_header = length(regexp(header, '\t', 'split'));
    
    fid = fopen(refgene_ucsc_table);
    fprintf(1, '- Importing UCSC refgene table from: %s ... \n', refgene_ucsc_table);
    
    gene_info_ucsc = textscan(fid, repmat('%s ', 1, l_ucsc_header), 'delimiter', '\t');

    % one cell array
    gene_info_ucsc = [gene_info_ucsc{:}];

    fclose(fid);
    
    header = gene_info_ucsc(1,:);
    % remove header from cell array
    gene_info_ucsc(1,:) = [];
    
end

gene_ucsc_idx = not(cellfun(@isempty, regexpi(header,c_gene_refgene)));
genes_ucsc = gene_info_ucsc(:,gene_ucsc_idx);

% unique list of refgene gene names (names2 column)
genes_ucsc_u = unique(gene_info_ucsc(:,gene_ucsc_idx));

% list of gene transcripts, processed later
gene_ucsc_transcript_idx = not(cellfun(@isempty, regexpi(header,c_gene_transcript)));
genes_ucsc_transcripts = gene_info_ucsc(:,gene_ucsc_transcript_idx);


fprintf(fid_rep, '# UCSC refgene input file:\t%s (%u rows)\n', refgene_ucsc_table, size(gene_info_ucsc, 1) + 1);


%% read data from NCBI gene_info 
%  - 4 columns in total
%  - 1. symbol
%  - 2. synonyms
%  - 3. locus tag
%  - 4. GeneID

fprintf(1, '- Importing NCBI gene information from: %s ... \n', gene_info_ncbi_table);

% only one column, symbol and synonyms combined
% gene_info_ncbi = importdata(gene_info_ncbi_table);

fid = fopen(gene_info_ncbi_table);
gene_info_ncbi = textscan(fid, '%s%s%s%u', 'delimiter', '\t');
fclose(fid);

% third column contains locus tag
% only used to scan genes found on array, not listed in UCSC table
gene_info_ncbi_tag = [gene_info_ncbi{:,3}];


% fourth column contains Entrez Gene IDs
% only used to scan LOC genes found on array, not listed in UCSC table
gene_info_ncbi_ID = [gene_info_ncbi{:,4}];


% only one cell array with names (symbol and corresponding synonyms)
gene_info_ncbi = [gene_info_ncbi{:, 1:2}];

% delete '-' indicating missing synonyms in column 2
gene_info_ncbi(:,2) = regexprep(gene_info_ncbi(:,2), '^-$', '');


fprintf(fid_rep, '# NCBI gene information input file:\t%s (%u rows)\n', gene_info_ncbi_table, size(gene_info_ncbi, 1));



%% process NCBI data

fprintf(1, '- Processing NCBI gene information ...\n');

% unique ncbi symbols, first column
[genes_ncbi_symbols_u, ~, n] = (unique(gene_info_ncbi(:,1)));

% count how often each symbol is within list
% some symbols might be duplicated
hist_n = hist(n, 1:length(genes_ncbi_symbols_u));

% duplicated symbols
ncbi_symbols_duplic = genes_ncbi_symbols_u(hist_n > 1);

% duplication level
ncbi_symbols_duplic_count = hist_n(hist_n > 1);

fprintf(fid_rep, '\n\nNumber of unique NCBI gene symbols:\t%u\n', length(genes_ncbi_symbols_u));
fprintf(fid_rep, 'Number of duplicated NCBI gene symbols: %u\n', length(ncbi_symbols_duplic));
fprintf(fid_rep, 'Keep only gene symbols with maximum number of synonyms\n\n');

fprintf(fid_rep, 'NCBI symbol\tNCBI synonym\tNote\n');

% report all duplicated entries
% delete rows with identical symbols based on the number of synonyms
% the genes with no synonyms are most likely to represent genes of unknown
% gene type and 'Annotation category: not annotated on reference assembly'

pos_del = [];

pos = find(hist_n > 1);


for i=1:length(pos)
    
    % position of rows with duplicated synonym
    idx = find(n==pos(i));
    
    dupl = gene_info_ncbi(idx, :);
    
    % test if no synonyms given
    test_empty = cellfun(@isempty, dupl(:,2));
           
    test = regexp(dupl(:,2), '\|', 'match');
    % number of synonyms
    test_length = cellfun(@length, test) + 1;
    % correct for empty synonyms
    test_length(test_empty) = 0;
        
    % find gene with max number of entries:
    [~, max_idx] = max(test_length);
    del_idx = true(size(dupl,1),1);
    del_idx(max_idx) = false;
            
    pos_del = [pos_del; idx(del_idx)];
    
    for j=1:ncbi_symbols_duplic_count(i)
        fprintf(fid_rep, '%s\t%s', dupl{j,:});
        
        if del_idx(j)
            fprintf(fid_rep, '\tdeleted\n');
        else
            fprintf(fid_rep, '\n');
        end
    end
end


% delete rows with identical gene symbols, keep only one row
gene_info_ncbi(pos_del,:) = [];

% also delete gene ID and locus tag
gene_info_ncbi_ID(pos_del) = [];
gene_info_ncbi_tag(pos_del) = [];


%% mapping of UCSC and NCBI gene symbols


fprintf(1, '- Mapping of UCSC and NCBI gene information ...\n');


fprintf(fid_rep, '\nNumber of unique gene symbols within UCSC refgene table:\t%u\n', length(genes_ucsc_u));

% which genes of ucsc are NOT within symbols of ncbi
ucsc_only = setdiff(genes_ucsc_u, genes_ncbi_symbols_u);
fprintf(fid_rep, 'Gene symbols of UCSC refgene table that do not overlap with NCBI symbols:\t%u\n', length(ucsc_only));
fprintf(fid_rep, 'Note that corresponding gene variants within the UCSC refgene table are appended to the updated refgene table\n\n');
fprintf(fid_rep, 'UCSC gene symbol\tPotentially new symbol (according to NCBI gene_info)\tCorresponding synonyms\n');

% assume that this list is fairly small
% so search potential new symbols by scanning all NCBI synonyms

for i=1:length(ucsc_only)
    
    fprintf(fid_rep, '%s', ucsc_only{i}); 
    
    test = find(not(cellfun(@isempty, regexp(gene_info_ncbi(:,2), ['\<', ucsc_only{i}, '\>']))));
    
    % there might be several hits, just append the additional ones    
    for j=1:size(test, 1)        
        fprintf(fid_rep, '\t%s\t%s', gene_info_ncbi{test(j),:});
    end     
    
    fprintf(fid_rep, '\n');
end

% correct ucsc gene list for these genes
% find rows in ucsc original table to ignore for now
% loop through all these genes, assume the list is short

% false for entries to be ignored
idx_ignore = true(length(genes_ucsc), 1);

for i=1:size(ucsc_only,1)
    
    % match complete word
    r = horzcat('^',ucsc_only{i},'$');
    
    idx_ignore = (idx_ignore & cellfun(@isempty, regexp(genes_ucsc, r)));
end


% new unique list of refgene gene names (names2 column)
[genes_ucsc_u_corrected, ~, n_ucsc] = unique(gene_info_ucsc(idx_ignore,gene_ucsc_idx));

% map ucsc symbols and ncbi symbols
[genes_ucsc_ncbi, ~, ib] = intersect(genes_ucsc_u_corrected, gene_info_ncbi(:,1));

% create list of synonyms  for ucsc entries, taken from ncbi synonyms
genes_synonyms = gene_info_ncbi(ib,2);



%% remove duplicated synonyms among all potential synonyms
%  - otherwise genes specified for nimbl-gene might give wrong coordinates

fprintf(1, '- Removing duplicated gene synonyms and symbols ...\n');

% perform on the non-expanded level!
genes_synonyms_split = regexp(genes_synonyms, '\|', 'split');


% number of synonyms per gene
genes_synonyms_length = cellfun(@length, genes_synonyms_split);


% original index vector, row number of each gene
test_idx = zeros(sum(genes_synonyms_length),1);

pos = 1;
for i=1:length(genes_synonyms_length)
    
    test_idx(pos:pos + genes_synonyms_length(i) - 1) = i;
    
    % new gene/row from original ncbi input file
    pos = pos + genes_synonyms_length(i);    
end


genes_synonyms_split = [genes_synonyms_split{:}]';
[genes_synonyms_u, m, n] = unique(genes_synonyms_split);
hist_n = hist(n, 1:length(genes_synonyms_u));

% fprintf(fid_rep, '\nNumber of synonyms that are duplicates: %u\n', sum(hist_n > 1));

% indices which represent multiple hits
% indices correspond to unique list of synonyms (genes_synonyms_u)
pos = find(hist_n > 1);

% only indices of genes that have no duplicates
genes_synonyms_no_duplic_idx = setdiff(n, pos);

% gene names that occur only once
genes_synonyms_no_duplic = genes_synonyms_u(genes_synonyms_no_duplic_idx);

% need to know which of these non-duplicated synonyms belong to the same
% gene/row
test_idx_reduced = test_idx(m);
test_idx_new = test_idx_reduced(genes_synonyms_no_duplic_idx);

% test_idx_new corresponds to genes_synonyms_no_duplic


%% remove synonyms that correspond to any symbols
% (including those which are in ucsc only)

[synonyms_eq_symbols, ~, ib] = intersect(genes_ucsc_u, genes_synonyms_no_duplic);

% delete these from the list of synonyms
genes_synonyms_no_duplic(ib) = [];
% and delete the corresponding index for the gene/row
test_idx_new(ib) = [];

%{
fprintf(fid_rep, '\nSynonyms (from unique list synonyms) that are also given as symbols:\n');
for i=1:length(synonyms_eq_symbols)
    fprintf(fid_rep, '%s\n',synonyms_eq_symbols{i});    
end
%}


% build new list if genes_synonyms, containing only unique names
genes_synonyms_2 = cell(length(genes_synonyms), 1);

test_idx_new_u = unique(test_idx_new);
for i=1:length(test_idx_new_u)
    genes_synonyms_2{test_idx_new_u(i)} = genes_synonyms_no_duplic(test_idx_new == test_idx_new_u(i))';
end


%% final list of gene symbols with unique synonyms

fprintf(1, '- Writing updated UCSC refgene table to file: %s ...\n', ucsc_file_new);
fprintf(fid_rep, '\n\n# Updated UCSC refgene table written to file:\t%s\n', ucsc_file_new);

% report number of ucsc gene names for which synonyms were found
fprintf(fid_rep, 'Number of UCSC gene symbols for which unique NCBI synonyms were found:\t%u\n', sum(cellfun(@length, genes_synonyms_2) > 0));

% verification if all duplicates are removed
l1 = length(unique([genes_ucsc_u_corrected; genes_synonyms_no_duplic; ucsc_only]));
l2 = length(genes_ucsc_u_corrected) + length(genes_synonyms_no_duplic) + length(ucsc_only);

% final evaluation
if l1 ~= l2
    fprintf(fid_rep, '\nWARNING: There are some symbols or synonyms that occur multiple times:\n');
    
    all_names = [genes_ucsc_u_corrected; genes_synonyms_no_duplic; ucsc_only];
    [test, ~, n] = unique(all_names);
    hist_n = hist(n, 1:length(test));
    all_names_non_unique = test(hist_n > 1);
    for i=1:length(all_names_non_unique)
        fprintf(1, '%s\n', all_names_non_unique{i});
    end
    
else
    fprintf(fid_rep, 'Total number of unique gene symbols (and synonyms) in updated refgene table:\t%u\n', l1);
end

% create updated gene names with '|' between names
% '|' is used for finding exact matches with input gene names
genes_ucsc_final = cell(length(genes_ucsc_u_corrected), 1);
for i=1:length(genes_synonyms_2)
       
    s = ['|', genes_ucsc_u_corrected{i}, '|'];
    
    % loop through synonyms
    for j=1:length(genes_synonyms_2{i})
        s = [s,  genes_synonyms_2{i}{j}, '|'];
    end
    
    genes_ucsc_final{i} = s;    
end

% reorder and expand according to original ucsc input table
% genes can have multiple transcripts, i.e. rows in refgene table
genes_ucsc_final = genes_ucsc_final(n_ucsc);


%% print updated UCSC gene information table

fid = fopen(ucsc_file_new, 'w');

% keep rows of refgene table for which the gene name did not match the ncbi
% gene symbols
ucsc_only_gene_info = gene_info_ucsc(~idx_ignore, :);
%%% gene_info_ucsc(~idx_ignore,:) = [];

% the table with all symbols found in NCBI symbols
gene_info_ucsc_subset = gene_info_ucsc(idx_ignore,:);


gene_ucsc_name_idx = find(gene_ucsc_idx);
format_out =  [repmat('%s\t', 1, l_ucsc_header-1), '%s\n'];

% print header
fprintf(fid, format_out, header{:});

% data for all genes that were found to have a corresponding NCBI symbol
for i=1:length(genes_ucsc_final)
    
    % last column with updated gene names
    % fprintf(fid, format_out, gene_info_ucsc{i,:}, genes_ucsc_final{i});
    
    % replace original gene names column ('name2') with updated info
    fprintf(fid, format_out, gene_info_ucsc_subset{i,1:gene_ucsc_name_idx-1},...
        genes_ucsc_final{i}, gene_info_ucsc_subset{i,gene_ucsc_name_idx+1:end}); 
end


% append rows for which ucsc gene and ncbi symbol did not match at the end
% of the updated refgene table

for i=1:size(ucsc_only_gene_info)
    % put '|' around gene name
    fprintf(fid, format_out, ucsc_only_gene_info{i,1:gene_ucsc_name_idx-1},...
        ['|', ucsc_only_gene_info{i,gene_ucsc_name_idx}, '|'],...
        ucsc_only_gene_info{i,gene_ucsc_name_idx+1:end});
end


fclose(fid);



%% Comparison of updated UCSC table and array annotation

fprintf(1, '- Processing gene info from array annotation ...\n');
fprintf(fid_rep, '\n# Comparison of gene information from array annotation and updated UCSC refgene table\n');


% gene symbols can be in first or second column of the two loaded columns
if col_gene_symbol_idx < col_gene_acc_idx    
    gene_symbols_array = gene_info_array(:,1);
    genes_array_transcripts = gene_info_array(:,2);
else
    gene_symbols_array = gene_info_array(:,2);
    genes_array_transcripts = gene_info_array(:,1);
end

% symbols are separated by ';' in 450k annotation

gene_symbols_array = regexp(gene_symbols_array, ';', 'split');
gene_symbols_array = [gene_symbols_array{:}]';

gene_symbols_array = unique(gene_symbols_array);

% delete potential empty element at first position
% if isempty(gene_symbols_array{1})
%    gene_symbols_array(1) = [];
% end

% assume that array contains intergenic sites, so empty gene symbols at the
% beginning
fprintf(fid_rep, 'Number of unique gene symbols (''%s'') from array annotation:\t%u\n', col_gene_symbol, length(gene_symbols_array) - 1);

% overlap with ucsc updated gene symbols

gene_symbols_array_only = setdiff(gene_symbols_array(2:end), [genes_ucsc_u_corrected; genes_synonyms_no_duplic; ucsc_only]);

fprintf(fid_rep, 'Number of gene symbols from array annotation that are not within updated UCSC refgene table (as symbols or synonyms):\t%u\n', length(gene_symbols_array_only));


if platform == 1    
    % TODO    
elseif platform == 2    
    
    file_gene_annot_450k = '450k_gene_annot.txt';
    
    fprintf(1, '- Importing additional gene information from: %s ...\n', file_gene_annot_450k);
    gene_annot_450k = importdata(file_gene_annot_450k, '\t');

    ID_info = gene_annot_450k.textdata(:,1);
    cg_info = gene_annot_450k.data;
    
    % gene symbols already obtained from above, should be the same!
    % gene_symbols = gene_annot_450k.textdata(~cellfun(@isempty, gene_annot_450k.textdata(:,2)),2);
    % gene_symbols(1) = {''};    
end



%% search array only gene symbols in all NCBI synonyms

fprintf(1, '- Searching NCBI gene annotation for gene symbols on array which are not within the UCSC refgene table ...\n');


% list of ALL NCBI synonyms
genes_synonyms = gene_info_ncbi(:,2);
genes_synonyms_split = regexp(genes_synonyms, '\|', 'split');

% number of synonyms per gene
genes_synonyms_length = cellfun(@length, genes_synonyms_split);

% original index vector, row number of each gene
test_idx = zeros(sum(genes_synonyms_length),1);

pos = 1;
for i=1:length(genes_synonyms_length)
    
    test_idx(pos:pos + genes_synonyms_length(i) - 1) = i;
    
    % new gene/row from original ncbi input file
    pos = pos + genes_synonyms_length(i);    
end

genes_synonyms_split = [genes_synonyms_split{:}]';

% unique synonyms==
[genes_synonyms_u, ~, n] = unique(genes_synonyms_split);

% overlap with array only gene names
[~, ia, ib] = intersect(gene_symbols_array_only, genes_synonyms_u);

% collect ncbi information
array_only_in_ncbi = cell(size(gene_symbols_array_only, 1), 2);

for i=1:length(ia)
    a = gene_info_ncbi(test_idx(find(n == ib(i))),:);
      
    array_only_in_ncbi{ia(i),1} = sprintf('%s, ', a{:,1});
    array_only_in_ncbi{ia(i),2} = sprintf('%s, ', a{:,2});    
end

fprintf(fid_rep, 'Number of array only genes which overlap with NCBI synonyms:\t%u\n', length(ia));


%% search array only gene symbols within all NCBI symbols

[~, ia, ib] = intersect(gene_symbols_array_only, gene_info_ncbi(:,1));

fprintf(fid_rep, 'Number of array only genes which overlap with NCBI symbols:\t%u\n', length(ia));


for i=1:length(ia)
    a = gene_info_ncbi(ib(i),:);
    
    % if there are already hits from previous search against synonyms, keep
    % these hits
    array_only_in_ncbi{ia(i),1} = [array_only_in_ncbi{ia(i),1}, sprintf('%s, ', a{:,1})];
    
    
    if ~isempty(a{:,2})
        array_only_in_ncbi{ia(i),2} = [array_only_in_ncbi{ia(i),2}, sprintf('%s, ', a{:,2})];
    end    
end


%% sarch GENE ID in NCBI GeneID list for LOC+GENEID

% LOC genes with no information so far in extra information of array only
% genes
idx = cellfun(@isempty, array_only_in_ncbi(:,1));
loc_idx = not(cellfun(@isempty, regexp(gene_symbols_array_only, '^LOC\d+$')));
idx = idx & loc_idx;


% extract Gene IDs from [LOC+GENE ID] symbols
loc_geneIDs = regexp(gene_symbols_array_only(idx), '\d+', 'match');
loc_geneIDs = [loc_geneIDs{:}]';
% convert to numeric vector
loc_geneIDs = sscanf(sprintf('%s*', loc_geneIDs{:}), '%d*');

% expand geneID vector to original length of array_only
% zero values should not match with list of all gene IDs
loc_geneIDs2 = zeros(size(array_only_in_ncbi, 1), 1);
loc_geneIDs2(idx) = loc_geneIDs; 

[~, ia, ib] = intersect(loc_geneIDs2, gene_info_ncbi_ID);

array_only_in_ncbi(ia, :) = gene_info_ncbi(ib,:);

fprintf(fid_rep, 'Number of array only genes (LOC+GeneID) which overlap with NCBI Gene ID:\t%u\n', length(ia));


%% search array only genes in NCBI locus tag column

% search only genes which do not have any additional info from previous
% searches

idx = cellfun(@isempty, array_only_in_ncbi(:,1));

% expand to original vector
array_test = cell(size(array_only_in_ncbi, 1), 1);
array_test(idx) = gene_symbols_array_only(idx);

% remove empty cells
array_test(~idx) = {''};
[~, ia, ib] = intersect(array_test, gene_info_ncbi_tag);

array_only_in_ncbi(ia, :) = gene_info_ncbi(ib,:);

fprintf(fid_rep, 'Number of array only genes which overlap with NCBI locus tag:\t%u\n', length(ia));



%% report array_only gene symbols
%  - with the number of array sites and minimum and maximum maplocation
%  - check if all array sites annotated with the same chromosome
%  - provide information from NCBI table about potential updates of these
%    genes, some genes have a symbol in 


fprintf(fid_rep, ['\nGene symbol array only\tNumber of corresponding array sites\t',...
    'chromosome\tMin location of all array sites\tMax location of all array sites\t',...
    'NCBI symbol\tNCBI Synonyms\tNote\n']);


% gene_symbols_array_only and gene_symbols_array are sorted!
[~, ~, ib] = intersect(gene_symbols_array_only, gene_symbols_array);
[~, ~, n] = unique(cg_info(:,1));

% cg_info does not contain the empty element from the unique list of gene
% symbols, so increase every index by 1
n = n + 1;

for i=1:length(ib)
    
    % index of all occurences in original list
    idx = find(n == ib(i));

    pos_min = min(cg_info(idx, 5));
    pos_max = max(cg_info(idx, 5));
            
    % all sites should be on the same chromosome, but if not print a
    % warning for this gene
    chr = unique(cg_info(idx, 4));
        
    % report gene symbols with extra information
    % array sites can occur multiple times, report only unique ones
    fprintf(fid_rep, '%s\t%u\t%u\t%u\t%u\t%s\t%s', gene_symbols_array_only{i}, length(unique(ID_info(idx))), chr(1), pos_min, pos_max, array_only_in_ncbi{i,:});
        
    if length(chr) > 1
        fprintf(fid_rep, ['\tassigned to multiple chromosomes: ', repmat('%u, ', 1, length(chr)-1), '%u\n'], chr);
    else
        fprintf(fid_rep, '\n');
    end    
end


%% gene variant/transcripts 

fprintf(1, '- Comparing gene variants/transcripts from UCSC with array annotation ...\n');

% all transcripts from UCSC table
[genes_ucsc_transcripts_u, m, n] = unique(genes_ucsc_transcripts);

fprintf(fid_rep, '\n\n# Comparison of gene transcripts (RefSeq accessions) of UCSC refgene table and array annotation\n');
fprintf(fid_rep, 'Number of unique UCSC gene transcripts (NM_, NR_):\t%u\n', length(genes_ucsc_transcripts_u));


% all transcript IDs within array annoation
genes_array_transcripts_split = regexp(genes_array_transcripts, ';', 'split');
genes_array_transcripts_split = [genes_array_transcripts_split{:}]';

% unique synonyms
[genes_array_transcripts_u, ~, ~] = unique(genes_array_transcripts_split);

% the first entry should be the empty string
if isempty(genes_array_transcripts_u{1})
    genes_array_transcripts_u(1) = [];
end

fprintf(fid_rep, 'Number of unique array gene transcripts:\t%u\n', length(genes_array_transcripts_u));


%% compare transcripts: array vs all UCSC

transcripts_array_only = setdiff(genes_array_transcripts_u, genes_ucsc_transcripts_u);
fprintf(fid_rep, 'Number of array gene transcripts that are not within UCSC refgene table:\t%u\n\n', length(transcripts_array_only));

% import data from NCBI removed refseq records
% 3 columns:
% - accession
% - refseq status
% - removed status
fid = fopen(refseq_removed_table);
refseq_removed = textscan(fid, '%s%s%s', 'delimiter', '\t');
refseq_removed = [refseq_removed{:}];
fclose(fid);

% overlap of array only transcripts and old/removed ones
[~, ia, ib] = intersect(transcripts_array_only, refseq_removed(:,1));

removed_info = cell(size(transcripts_array_only, 1), 2);
removed_info(ia,:) = refseq_removed(ib,2:3);

% colum headers
fprintf(fid_rep, 'RefSeq ID\tRefSeq status\tRemoved status\n');

for i=1:length(transcripts_array_only)
    fprintf(fid_rep, '%s\t%s\t%s\n', transcripts_array_only{i}, removed_info{i,:});
end


%%  compare transcripts: array vs duplicated UCSC

hist_n = hist(n, 1:length(n));

fprintf(fid_rep, '\n# Duplicated UCSC transcripts\n');
fprintf(fid_rep, 'Number of duplicated UCSC gene transcripts:\t%u\n', sum(hist_n > 1));

genes_ucsc_transcripts_dupl = genes_ucsc_transcripts_u(hist_n > 1);


% collect information about duplicated transcripts: chr and txStart
% these duplicates can be on different chromosomes
% theoretically the txStart could then be the same, but highly unlikely
ucsc_dupl_info = cell(length(pos), 2);

pos = find(hist_n > 1);

for i=1:length(pos)
    
    % position of rows with duplicated accession
    % idx = find(n==pos(i));    
    a = gene_info_ucsc(n==pos(i), :);
        
    % there are at least 2 entries, so end-1 is fine
    ucsc_dupl_info{i,1} = [sprintf('%s, ', a{1:end-1,3}), a{end,3}];    
    ucsc_dupl_info{i,2} = [sprintf('%s, ', a{1:end-1,5}), a{end,5}];
        
    % check if txStart is the same
    %{
    if (length(idx) ~= length(unique(a(:,5))))
        fprintf(1, 'txstart is the same at least once: %s\n', a{1,2});
    end
    %}
end



[transcripts_array_duplic, ~, ib] = intersect(genes_array_transcripts_u, genes_ucsc_transcripts_dupl);
fprintf(fid_rep,  'Number of array gene transcripts that are duplicated within UCSC refgene table:\t%u\n\n', length(transcripts_array_duplic));

% which of these duplicated transcripts are annotated within array
dupl_on_array = zeros(size(genes_ucsc_transcripts_dupl, 1) ,1);
dupl_on_array(ib) = 1;

% duplication level
genes_ucsc_transcripts_dupl_count = hist_n(hist_n > 1);

fprintf(fid_rep, 'UCSC transcript ID\tDuplication level\tGiven in array annotation (1: yes, 0: no)\tChromosome\tTranscription start site\n');
for i=1:sum(hist_n > 1)
    fprintf(fid_rep, '%s\t%u\t%u\t%s\t%s\n', genes_ucsc_transcripts_dupl{i}, genes_ucsc_transcripts_dupl_count(i), dupl_on_array(i), ucsc_dupl_info{i,:});
end



%%

fclose(fid_rep);


end