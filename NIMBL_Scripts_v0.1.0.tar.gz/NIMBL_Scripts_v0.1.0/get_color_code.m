function [color_code] = get_color_code(grouping, sample_nbr)

%[color_code] = get_color_code(grouping, sample_nbr)
%
% get vector of RGB colors: for each group one color


%% color map

%{
color_pool_6 = ...    
[ 1 0 0 % 1 RED    
   0 0 1 % 2 BLUE    
   0 1 0 % 3 GREEN   % green is weak and red vs green is not good
   1 0 1 % 4 MAGENTA    
   0 0 0 % 5 BLACK 
   0 1 1 ]; % 6 CYAN
%}

color_pool_7 = ...    
[ 1 0 0 % 1 RED   
   0 0 1 % 2 BLUE
   0 1 1 % 3 CYAN   
   1 0 1 % 4 MAGENTA
   1 0.6 0 % 5 ORANGE
   0 0 0 % 6 BLACK
   0 1 0]; % 7 GREEN
   
%{
colors= {
0    0    0    'black';
1    0    0    'red';
0    1    1    {'cyan','baby blue'};
1    0.6  0    'orange';
0.5  0.5  1    'light blue';
0    1    0    {'green','light green'};
0.8  0.5  0    'brown';
0.5  0.5  0.5  'dark gray';
0.25 0.25 0.9  {'blue','cobalt blue'};
1    1    0.6  'cream';
0    0.5  0    {'dark green','forest green'};
1    0.5  0.5  'peach';
1    1    0    'yellow';
0    0    0.8  {'dark blue','navy blue'};
0.8  0.8  0.8  {'gray','light gray'};
0.5  0    0.9  'purple';
0.3  0.8  0    'avocado';
1    0.5  1    {'magenta','pink'};
0    0.8  0.8  {'aqua','turquoise'};
0.9  0.75 0    'gold';
1    1    1    'white';
};
%}


%% consistency check

group_nbr = max(grouping);

% check if number of group indices equals number of samples
if ~isequal(length(grouping), sample_nbr)
    error('Each sample requires one group number.');
end

% check if grouping is correctly: 1,2,...
if ~isequal(unique(grouping), 1:group_nbr)
    error('Grouping not correct. Use 1,2,...,n as group numbers.');
end


%% get for each group one color from color pool or from colormap

if (group_nbr <= 7) 
    color_code = color_pool_7(grouping,:);   
else
    color_code = colormap(hsv(sample_nbr));
end



end

