function get_beta_kde(data, file_name, legend_names, color_set)

% get_beta_kde(data, file_name, legend_names, color_set)
%
% compute and plot kernel density estimation based on data matrix
% 
% IN:
% - data: matrix - for each column estimate its probability density
% - file_name: (string) name for PDF file of distribution plots
% - legend_names: cell array with names of each distribution (column)
% - color_set: RGB color code matrix
%
% OUT: 
% - PDF file with distribution estimates of all columns

fprintf(1, '\n- Computing Beta-value distribution (%s) ... ', file_name);

%% variables

% kernel
% kernel = 'epanechnikov';
kernel = 'normal';

% bandwidth
% width = 0.2;
% width = 0;
width = 0.05;

% number of points used for kde
% default = 100
npoints = 200;


%% figure

figure('visible','off');


%% colormap

if (isempty(color_set)) | (color_set==0)
    % every sample a different color
    color_order = colormap(hsv(size(data,2)));
    set(gcf,'DefaultAxesColorOrder',color_order);
else
    % set color according specified set
    set(gcf,'DefaultAxesColorOrder',color_set);
end


%% kde

% boundaries: all beta values have to be BETWEEN lower and upper bound

%{
% test if minimum beta value == 0
if min(min(data)) == 0
    low = -0.00001;    
else
    low = 0;     
    % low = -0.1;
end

% test if maximum beta value == 1
if max(max(data)) == 1
    up = 1.00001;    
else
    up = 1;
end
%}


% number of vectors
nbr = size(data,2);


% store all points for both axes
xi_all = zeros(npoints, nbr);
f_all = zeros(npoints, nbr);
u_all = zeros(nbr,1);

% kde for each column
for i=1:nbr
        
    if (width == 0)        
        % no user specified bandwidth
        % [f_all(:,i), xi_all(:,i), u_all(i)] = ksdensity(data(:,i), 'kernel', kernel, 'support', [low,up], 'npoints', npoints);        
        [f_all(:,i), xi_all(:,i), u_all(i)] = ksdensity(data(:,i), 'kernel', kernel, 'npoints', npoints);
    else
       % [f_all(:,i), xi_all(:,i), u_all(i)] = ksdensity(data(:,i), 'kernel', kernel, 'width', width, 'support', [low,up], 'npoints', npoints);
       [f_all(:,i), xi_all(:,i), u_all(i)] = ksdensity(data(:,i), 'kernel', kernel, 'width', width, 'npoints', npoints);
    end    
end


%% plot all kdes at once 

plot(xi_all, f_all,'LineWidth',0.7);
% default LineWidth = 0.5


%% plot settings

% legend

% modify sample names: incorporate sample index
%{
for i=1:nbr
    legend_names{i} = [num2str(sample_idx(i)), ' ',legend_names{i}];
end
%}

% select font size
if nbr < 20
    fs = 8;
elseif nbr < 85
    fs = 5;
else 
    fs = 3;
end

legend(legend_names,'Location', 'NorthEastOutside', 'FontSize',fs)


% title
title(horzcat('Beta-value distribution (', num2str(size(data,1)) , ' array sites)'));


% grid
set(gca,'YGrid','on')

% axes labels
xlabel('Beta-value')
ylabel('Probability Density')

% limit
%%% xlim([0 1])
xlim([-0.05,1.05])

%% save figure as PDF file

set(gcf, 'PaperType','A4','PaperOrientation','landscape');
set(gcf, 'PaperUnits', 'centimeters');
set(gcf, 'PaperPosition', [-3.5 0 36.5 21]);

saveas(gcf,file_name)

close all

fprintf(1, ' done\n');  


end
