%% Dedeurwaerder2011 - 16 breast tissue samples, 450k platform
%  methylation experiment done: maybe in Brussels
%  8x normal tissue (N)
%  8x breast cancer tissue (BC)
%
% - compatible with NIMBL version 0.1.0 

%% 1. Input files

% 1.1
% file name for methylation input data (string)
input_file = 'GSE29290_BC_16_samples.txt';


% 1.2
% optional annotation file name (string)
% if annotation file name is empty ('') default annotation file of platform
% is used:
% - Infinium_27k_annotation.txt
% - Infinium_450k_annotation.txt
annot_file = '';


% 1.3
% delimiter used in input files (string)
% default: TAB ('\t')
input_del = '\t';


% 1.4
% Infinium platform (integer)
% - 27k array (1)
% - 450k array (2)
platform = 2;


% 1.5
% delimiter for sample names within columns of header of input file (string)
sample_del = '.';
% sample_del = '_';


% 1.6
% position of sample name in column headers (integer)
% - before sample delimiter (1)
% - after sample delimiter (2)
% examples:
% - PRL_1 (M).pval -> "PRL_1 (M)" is sample name (sample_pos = 1)
% - pval_mcf7.untr -> "mcf7.untr" is sample name (sample_pos = 2)
sample_pos = 1;


%% 2. Quality control of samples

% 2.1
% threshold for detection pvalue, values above threshold indicate
% low-quality measurement
pval_cut_s = 0.05;


% 2.2
% indices of samples to exclude entirely from analysis
% do NOT choose '0' if no sample should be excluded, but '[]'
% sample_ex = [1,12]; -> exclude samples 1 and 12
sample_ex = [];


% 2.3
% choose whether samples marked for exclusion should also be excluded from
% the QC procedure (NIMBL-qc)
% qc_ex = 0;
qc_ex = 1;


% 2.4
% generate (1) or skip (0) plots of beta value distribution within nimbl_qc
% and nimbl (this might take a while)
kde_test = 0;
% kde_test = 1;


% 2.5
% choose whether beta values of Infinium II design should be corrected
% - all samples are identically corrected: 
%   binary vector for [unmethylated peak, methylated peak]
% - or correct samples individually, specify one integer per sample:
%   - 0: [0,0] -> no correction
%   - 1: [1,1] -> correct both peaks
%   - 2: [1,0] -> correct only unmethylated peak
%   - 3: [0,1] -> correct only methylated peak
% examples:
% peak_correct = [0,0]; -> no correction of any samply and no QC test
% peak_correct = [1,1,2,2]; -> correct only unmethylated peak of samples 3
% and 4 (of a total of only 4 samples)
% peak_correct = [1,1];
peak_correct = [0,0];


% 2.6
% plots of Infinium I and II distribution during QC
% peak_correct_detail = 0; -> merge all samples in one plot
% peak_correct_detail = 1; -> individual plot of each sample
peak_correct_detail = 0;


% 2.7
% write corrected beta values to text file (integer)
% - file name is used from input_file with prefix 'NIMBL_peak_corrected'
% - if samples are excluded (qc_ex = 1) these are also excluded here
% values:
% - 0: no output
% - 1: print only corrected beta values
% - 2: print corrected beta values and pvals
peak_correct_write = 0;


%% 3. Quality control and selection of CpG sites

% 3.1
% threshold for detection pvalue, values above threshold indicate
% low-quality measurement
% - also used to indicate low-quality measurements within the plots of
%   NIMBL-gene module
pval_cut_p = 0.05;


% 3.2
% threshold in percent of accepted number of low quality measurements/samples
% per CpG site, exclude CpG sites above threshold
% set value to '0' for most stringent QC
pval_qc_p = 5;


% 3.3
% fraction of maximal number of samples with missing beta value (NaN) in 
% each group: [group1, group2], values < 1
% examples:
% - miss_beta_qc = [0, 0]; -> exlude sites with missing beta values in any
%                             group
% - miss_beta_qc = [1/4, 0]; -> allow 25% of samples in group1 to have a 
%                               missing beta value, none such in group2
miss_beta_qc = [0, 0];


% 3.4
% binary vector of 4 chromosome groups
% (1) autosomes - (2) X - (3) Y - (4) unspecified
% examples:
% chr_sel = [1,1,1,1]; -> all chromsomes and unspecified
% chr_sel = [1,1,0,1]; -> exclude y chr
chr_sel = [1,1,1,1];


% 3.5
% CpG region, several regions can be selected
%   - 1: CpG island (CGI)
%   - 2: N-Shore (5' shore)
%   - 3: S-Shore (3' shore)
%   - 4: N-Shelf
%   - 5: S-Shelf
%   - 6: not related to CGI
% examples:
% - cpg_reg = 0; -> do not select for CpG region
% - cpg_reg = 1; -> select CpG sites within is CGIs
% - cpg_reg = [1,2,3]; -> select CpG sites in CGIs and shores
cpg_reg = 0;


% 3.6
% user annotation
% specify any numerical value within column [0..9]
% same usage as in 3.5
% - 0: ignore user annotation
cpg_user = 0;


% 3.7
% write selected array sites to text file
% - file name is used from input_file with prefix 'NIMBL_selected'
% - if samples are excluded (sample_ex) these are also excluded here
% - if peak correction is chosen, corrected beta values are written
% values:
% - 0: no output
% - 1: cgIDs
% - 2: cgIDs + beta values
% - 3: cgIDs + beta values and pvals
% - 4: cgIDs + beta values and pvals + array annotation
selected_write = 0;


% 3.8
% write excluded array sites to text file
% - file name is used from input_file with prefix 'NIMBL_excluded'
% - if samples are excluded (sample_ex) these are also excluded here
% - if peak correction is chosen, corrected beta values are written
% values:
% - 0: no output
% - 1: cgIDs
% - 2: cgIDs + beta values
% - 3: cgIDs + beta values and pvals
% - 4: cgIDs + beta values and pvals + array annotation
excluded_write = 0;


%% 4. Grouping of samples and differential methylation

% 4.1.
% 2 groups of samples
% - sample index according to occurrence of samples in input file
% - additional groups g3,... can be defined for NIMBL-gene
% examples:
% - 12 samples in total: 4 in group1, 4 in group2
% g1 = [1,2,5,6];
% g2 = [3,4,7,12];
% - 24 samples in total: 12 in group1, 12 in group2
% g1 = [1:6,13:18];
% g2 = [7:12,19:24];
% - additional groups for NIMBL-gene
% g3 = 5;
% g4 = [];
% g5 = [1:4];

% Normal
g1 = 1:8;

% Cancer
g2 = 9:16;


% 4.2
% names of the two groups for NIMBL core module
% NIMBL-gene allows to specify more groups (and corresponding names)
% example:
% - 5 groups (g1...g5) specified
% group_names = {'Normal', 'Cancer_1', 'Cancer_2', 'Cancer_3', 'Normal_2'};
group_names = {'Normal', 'Cancer'};


% 4.3
% minimal beta value intergroup distance
beta_dist = 0.1;


% 4.4
% fraction of maximum number of masked samples in each group
% [group1, group2]
% - values < 1
% examples:
% - mask_frac = [0, 0]; -> no masking in both groups
% - mask_frac = [1/4, 0]; -> max 25% of samples in group1, no in group2

% mask_frac = [0,0];
mask_frac = [2/8, 2/8];


% 4.5
% optional lower and upper limits on median of beta values of each group
% [lower, upper]
% examples:
% - limit1 = [0, 1]; -> no limits group1
% - limit1 = [0.65, 1]; -> hypermethylation group1
% - limit2 = [0, 0.3]; -> hypomethylation group2

% group1
limit1 = [0, 1];
% group2
limit2 = [0, 1];


% 4.6
% subset of ranked identified candidates displayed in methylation plot
% - range - row vector: [start position, end position] 
%   if less candidates identfied than end position: selection ignored
% - individuals - column vector: [position 1; position 2; position 3]
% examples:
% - hits = [1,50]; -> top 50 candidates
% - hits = [1;10;2;5]; -> 4 candidates at specified positions
hits = [1,50];


% 4.7
% flag beta values of masked samples in text file (integer)
%   - 0: no flag (only missing beta values would appear as NaN)
%   - 1: flag beta values with NaN
flag_mask = 0;
% flag_mask = 1;


% 4.8
% boxplot of each sample in group1 vs group2 (integer)
% values:
% - 0: no boxplot
% - 1: boxplot with samples in original order
% - 2: boxplot with group1 samples left and group2 samples right
boxplot_write = 0;
% boxplot_write = 1;
% boxplot_write = 2;



%% 5. Gene or region methylation profile (nimbl_gene)

% 5.1
% list of genes and chromosomal regions or filename of file with listed genes
% and regions (one row per input value)
% nimbl_gene_input = 'list_of_input_values.txt';

% nimbl_gene_input = {'SLC38A2'};
nimbl_gene_input = {'CHAD'};
% nimbl_gene_input = {'CHAD', 'SLC38A2'};
% nimbl_gene_input = {'NM_032785','14;+;78227173;78236085'};


% 5.2
% include extra bases upstream of transcription start site (TSS, txS)
extra_upstream = 2000;


% 5.3
% include extra bases downstream of transcription end site (txE)
extra_downstream = 200;


% 5.4
% perform (1) or skip (0) alignment of array probes to genomic target
% sequence to generate a multiple fasta file
align_probes = 0;
% align_probes = 1;


% 5.5
% zoom in first n bases or region [n1,n2]
% start is defined by number of extra bases upstream of TSS (extra_upstream)
% if genes are specified as input value
% examples:
% zoom_in = 0; -> disable zoom plot
% zoom_in = 4000; -> zoom in first 4000 bases
% zoom_in = [2000, 8000]; -> display region from plot position 2000 to 8000
zoom_in = 0;


% 5.6
% label (1) or do not label (0) the array sites on the x-axis of overview
% plot, labels corresponds to positions of sites within 5'-3' seequence
% - labels correspond to the numbers within the fasta file
% label_sites = 0;
label_sites = 1;


% 5.7.
% write methylation levels of array sites within genomic region to txt file
% - 0: no output
% - 1: cgID + beta values and pvalues
% - 2: all info from probe annotation + beta values and pvalues
% methyl_profile_write = 0;
methyl_profile_write = 1;


% 5.8
% file name of specific array sites
% - highlighted in plots, and txt output file as binary matrix
% - specify one or more columns with array site identifiers and headers
sites_extra = '';
% sites_extra = 'sites_extra.txt';


% 5.9
% file name of UCSC refGene table
refgene_ucsc_table = 'ucsc_hg19_refgene_table_raw_03112012.txt';


% 5.10
% file name of extracted information from NCBI 'gene_info'
% - only human entries
% 4 columns:
% - 1: 'Symbol', original column 3
% - 2: 'Synonyms', original column 5
% - 3: 'LocusTag',  original column 4
% - 4: 'GeneID', original column 2
gene_info_ncbi_table = 'ncbi_gene_info_names_03112012.txt';


% 5.11.
% file name of removed RefSeq records from NCBI
% - only human entries
% 3 columns
% - 1: accession (version removed), original column 3
% - 2: refseq status, original column 6
% - 3: removed status, original column 8
refseq_removed_table = 'refseq_removed_records_release37_to_55_human_NM_NR.txt';


%% 6. Comparison of 2 or 3 lists of array sites (nimbl_compare)

% 6.1.
% number of lists to compare against each other (2 or 3)
n = 3;
% n = 2;


% 6.2.
% file names of lists of array sites

% list 1
% NIMBL
% list1 = 'nimbl_example_BC_d0.1_m_0_8_diff_methylation_IDs.txt';
list1 = 'nimbl_example_BC_d0.1_m_2_8_diff_methylation_IDs.txt';

% list 2
% IMA: wilcoxon, nonorm, nopeak, BH, adjust pval cut = 0.05
list2 = 'IMA_example_BC_wilcoxon_BH_P_0.05_IDs.txt';

% list 3
% IMA: limma, nonorm, nopeak, BH, adjust pval cut = 0.05
list3 = 'IMA_example_BC_limma_BH_P_0.05_IDs.txt';


% 6.3
% names of input lists
% these strings are also used for filenames of output files, so
% please do not include characters not allowed for filenames
% m1, m2, m3

% m1 = 'NIMBL_d0.1_m_0_8';
% m1 = 'NIMBL_d0.1_m_2_8';
m1 = 'N';

% m2 = 'IMA_wilcox_adjP_0.05';
m2 = 'W';

% m3 = 'IMA_limma_adjP_0.05';
m3 = 'L';


% 6.4
% matrix of beta values including array IDs in first column
% this should include only the sites that were used for differential
% methylation analysis (i.e. sites excluded due to QC are not in this file)
beta_file = 'GSE29290_BC_16_samples_nonorm_nopeak_480917.txt';


% 6.5
% post-filter lists based on mean or median beta-value difference
% between group1 and group2
% examples:
% - f_on = [1,1,1]; -> post-filter all 3 lists
% - f_on = [0,1,1]; -> do not post-filter the first list, use all sites
% - f_on = [1,1]; -> post-filter both of the 2 lists
% f_on = [1,1,1];
% f_on = [0,0];
f_on = [0,0,0];


% 6.6
% post-filter based on mean or median beta value difference between groups
% mean: 1
% median: 2
% filter_method = 1;
filter_method = 2;


% 6.7
% post-filter cut-off for mean or median difference
f = 0.2;


% 6.8
% plot mean or median beta values of groups against each other
% mean: 1
% median: 2
% m = 1;
m = 2;


% 6.9
% output list-specific gene tables separately
% gene_table_sep = 0;
gene_table_sep = 1;


%% 7. Prefixes for module output files

% 7.1
% prefix for nimbl_qc
nimbl_qc_prefix = 'nimbl_qc';


% 7.2
% prefix for nimbl
nimbl_prefix = 'nimbl';
% nimbl_prefix = 'nimbl_example_BC_d0.1_m_0_8';
% nimbl_prefix = 'nimbl_example_BC_d0.1_m_2_8';


% 7.3
% prefix for nimbl_gene
nimbl_gene_prefix = 'nimbl_gene';


% 7.4
% prefix for nimbl_compare
nimbl_comp_prefix = 'nimbl_compare';












