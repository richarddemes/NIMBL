% function plot_beta_overview(group_names, grouping, betas, pvals, pval_cut_p, file_name, title_info, xtick_labels, number_groups, idx_extra, test_max_extra)
function plot_beta_overview(group_names, grouping, betas, pvals, pval_cut_p, file_name, title_info, xtick_labels, number_groups, group_member_extra, test_max, color_extra, legend_extra)

% plot_beta_overview(group_names, grouping, betas, file_name, title_info)
% 
% summary plot of methylation levels of array sites of various number of
% color-highlighted groups
% 
% IN:
% - group_names: cell array with n group names
% - grouping: (integer) specify group of each sample (1..n)
% - betas: beta values
% - file_name: (string) PDF file name of plot
% - xtick_labels: labels for each array site, index in mapinfo-sorted list
% - number_groups: number of specified group variables in input file (g1, g2, ... gnumber_groups)
% OUT:
% - PDF file of plot


fprintf(1, '- Generating methylation profile ...\n');

% figure window invisible
figure('visible','off');
hold on

% number of groups
g = grouping(grouping>0);
g = unique(g);
n = length(g);

% appearence
% color = get_color_code_new(unique(grouping),n);
% color = get_color_code(1:n,n);
color = get_color_code(1:number_groups,number_groups);

% for legend 
handles_all = zeros(1, n);

% legend
% escape underscores within names
group_names_print = regexprep(group_names, '_','\\_');
group_names_print = group_names_print(g);


%% generate plot

% default: 0.5
line_width = 0.8;

s = size(betas, 1);
% size of marker
if s <= 50
    marker_size = 60;
elseif s <= 100
    marker_size = 40;
elseif s <= 150
    marker_size = 20;
elseif s <= 200
   marker_size = 10; 
else
   marker_size = 5;
end
    

% highlight any exta array sites with specific color corresponding to one
% column/group of the input file given by sites_extra
% plot before the markers are plotted
if ~isempty(group_member_extra)
    
    ng = unique(group_member_extra);
    ng(ng==0) = [];
    
    % collect handles of all extra groups for the legend
    handles_extra = zeros(1, length(ng));
    
    % each group that has one or more members (array sites)
    for i=1:length(ng)
        idx = group_member_extra == ng(i);
        handles_extra(i) = stem(find(idx), test_max(idx), 'Marker', 'none', 'Color', color_extra(ng(i),:), 'LineWidth', line_width);        
    end
else
    handles_extra = [];
    legend_extra = [];
end


for i=1:n % group i
    
    % idx = grouping == i;        
    idx = grouping == g(i);
    
    % relevant beta values
    beta_plot = betas(:, idx);
    
    % coordinates as row vectors
    x = repmat(1:size(betas,1),1,sum(idx));
    % y = reshape(betas(:,idx), 1, size(betas,1) * sum(idx));    
    y = reshape(beta_plot, 1, size(betas,1) * sum(idx));    
          
    handles_all(i) = scatter(x, y, 'o', 'SizeData', marker_size, 'MarkerEdgeColor', color(g(i),:), 'LineWidth', line_width);
    
    % test for pval above threshold
    pval_test = pvals(:, idx) > pval_cut_p;        
    beta_high_pval = NaN(size(betas,1), sum(idx));    
    beta_high_pval(pval_test) = beta_plot(pval_test);
    y = reshape(beta_high_pval, 1, size(betas,1) * sum(idx));
    
    % keep the same color for each group index    
    scatter(x, y, 'x', 'SizeData', marker_size, 'MarkerEdgeColor', color(g(i),:), 'LineWidth', line_width);
    
    
    % include size of group (number of samples) within the legend
    group_names_print{i} = [group_names_print{i}, ' (', num2str(sum(idx)), ')'];           
end

hold off


%% plot settings

% legend
% lh = legend(handles_all, group_names_print, 'Location', 'NorthOutside', 'Orientation', 'horizontal');
lh = legend([handles_all, handles_extra], [group_names_print, legend_extra], 'Location', 'NorthOutside', 'Orientation', 'horizontal');


% the linewidth is not automatically adjusted
% use 1 as default
h = findobj(lh,'Type','patch');
set(h,'LineWidth', 1); % also works for vector of handles

% box
box on

% axes limits
xlim([0 size(betas, 1)+0.5]) 
ylim([0 1])

set(gca,'YGrid','on')
% set(gca,'GridLineStyle',':')

if s <= 25
    xticks = 0:size(betas,1);
elseif s <= 50
    xticks = 0:2:s;
elseif s <= 100
    xticks = 0:5:s;
elseif s <= 200  
    xticks = 0:10:s;
else
    xticks = 0:20:s;
end

% do not use xtick at position 0
set(gca,'XTick', xticks(2:end))

% use xtick labels according to the ordered list of array sites
% so if zooom is chosen, preserve the array site index
set(gca,'XTickLabel', xtick_labels(xticks(2:end)))

% axes labels
xlabel(gca, 'Array Site')
ylabel(gca, 'Beta-Value')

% title
title(title_info);


%% save as PDF

set(gcf, 'PaperUnits', 'centimeters');
set(gcf, 'PaperType','A4','PaperOrientation','landscape');
% set(gcf, 'PaperPosition', [-3.5 0 36 22]);
set(gcf, 'PaperPosition', [-3.5 -1.2 36.2 23.2]);

saveas(gcf,file_name)

close all

end

