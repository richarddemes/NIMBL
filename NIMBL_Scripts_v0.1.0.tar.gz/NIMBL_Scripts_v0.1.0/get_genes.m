function [g_hits_idx, g_hits, ig] = get_genes(ID_list, ID_info, cg_info)

% generate gene information table based on list of IDs


% check if IDs are unique
if length(ID_list) ~= length(unique(ID_list))
    fprintf(1, 'There are multiple IDs within the input list of array IDs\n');
end

% get positions in cg_info table for matches
% if there are multiple array sites in table, the last position is returned
[~, ~, ib] = intersect(ID_list, ID_info);

% report number of intergenic sites
ig = length(ID_list)-length(ib);
% fprintf(1, 'Number of sites that are intergenic within the list: %u\n', ig);

% gene matches: collect overall hits and gene region hits
% the maximum index in the cg_info table gives the length of the list of
% unique gene names + 1 (for the empty string)

g_hits = zeros(max(cg_info(:,1)),7);


for i=1:length(ib)
    
    % corresponds to last position if several annotations given for this array site
    x = ib(i);
    
    % reset prev gene index since two adjacent array sites in the table can
    % be associated with the same gene
    prev = 0;
    
    for j=1:cg_info(x,3)
        
        % go backwards in list if several annotations given
        
        % gene index
        n1 = cg_info(x-j+1,1);
        
        % gene region
        n2 = cg_info(x-j+1,2);
                
        % count gene region hits
        g_hits(n1,n2) = g_hits(n1,n2) + 1; 
                
        % increment overall count of array sites for this gene
        % (first column) only once for this site
        if prev ~= n1
            g_hits(n1,1) = g_hits(n1,1) + 1;
        end 
        prev = n1;        
    end    
end


g_hits_idx = find(g_hits(:,1));

% delete empty rows, i.e. genes that are not related to the any ID
g_hits(g_hits(:,1) == 0,:) = [];


end