function get_beta_cdf(data, file_name, legend_names, color_set)

% get_beta_cdf(data, file_name, legend_names, color_set)
%
% compute and plot empirical cumulative distribution function
% 
% IN:
% - data: matrix - for each column estimate its probability density
% - file_name: (string) name for PDF file of distribution plots
% - legend_names: cell array with names of each distribution (column)
% - color_set: 
%
% OUT: 
% - PDF file with distribution estimates of all columns


%% figure

figure('visible','off');


%% colormap

%%% if isempty(color_set) || all(color_set == 0)
if color_set == 0
    % every sample a different color
    color_order = colormap(hsv(size(data,2)));
    %%% set(gcf,'DefaultAxesColorOrder',color_order);
else
    % set color according specified set
    color_order = color_set;
    %%% set(gcf,'DefaultAxesColorOrder',color_set);
end


%% cdf plots

% number of vectors
nbr = size(data,2);

% cdf for each column
for i=1:nbr    
    h = cdfplot(data(:,i));    
    set(h, 'Color', color_order(i,:))    
    hold on    
end


%% plot settings

% legend

% select font size
if nbr < 20
    fs = 8;
elseif nbr < 85
    fs = 5;
else 
    fs = 3;
end

legend(legend_names,'Location', 'NorthEastOutside', 'FontSize',fs)

%%%%%%%%%%%%%
% redraw aberrant samples on top
%{
ks_idx = find(ks_idx);
for i=1:length(ks_idx)
    h = cdfplot(data(:,ks_idx(i)));    
    set(h, 'Color', color_order(ks_idx(i),:)) 
    % set(h, 'Color', 'green')
end
%}
%%%%%%%%%%%%

% title
% default: Empirical CDF

% axes labels
xlabel('Beta-value')
ylabel('cdf(Beta-value)')


%% save figure as PDF file

set(gcf, 'PaperType','A4','PaperOrientation','landscape');
set(gcf, 'PaperUnits', 'centimeters');
set(gcf, 'PaperPosition', [-3.5 0 36.5 21]);

saveas(gcf,file_name)

close all


end
