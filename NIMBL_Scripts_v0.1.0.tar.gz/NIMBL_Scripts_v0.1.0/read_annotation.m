function [A2, header2, cgID_idx2, design_type_idx, annot_file] = read_annotation(annot_file, del, platform)

% [A2, header2, cgID_idx2, design_type_idx, annot_file] = read_annotation(annot_file, del, platform)
%
% Read annotation file provided by user or default annotation file
%
% IN:
% - annot_file: (string) annotation data file name, if empty ('') read
%   default annotation file of platform
% - del: (string) delimiter used in annotation file
% - platform: (integer) 1 - 27k array, 2 - 450k array
%
% OUT:
% - A2: cell array with annotation data
% - heade2r: cell array with column headers of annotation file
% - cgID_idx2: (integer) column index of column with cg-Identifier
% - design_type_idx: (integer) column index of Infinium design type (I or
%                    II), only for 450k
% - annot_file: string of read file name

% avoid re-reading of annotation input file
% re-reading is checked by file name, so if the user changes the input file
% during a MATLAB session the old data will be used

persistent A;
persistent HEADER;
persistent CG_ID_IDX;
persistent INPUT_ANNOT_FILE;


%% variables

% default annotation files:
a_27k = 'Infinium_27k_annotation.txt';
a_450k = 'Infinium_450k_annotation.txt';

% regular expression to search for cgID column
% besides CpG sites (ID: "cg...") there can be for 450k array:
% 3091 non-CpG sites, ID: "ch.[chr number].number"
% 65 random SNPs, ID: "rs[number]" 
c_cgID = '^cg[0-9]{8}$|^ch\.([0-9]*|X)\.|^rs[0-9]*';

% regular expression to search for Infinium design type column
c_type = 'infinium.?design.?type';

if (isempty(annot_file)) % use default annotation file
    if platform == 1        
        annot_file = a_27k;
    elseif platform == 2
        annot_file = a_450k;
    else
        error('Please specify ''1'' or ''2'' to select an Infinium platform.')
    end
end


%% read data

fprintf(1, '\n# Annotation data:\n');

% only read file if file name is new or has changed
if ~strcmp(annot_file, INPUT_ANNOT_FILE)
     
    tic; 
    
    fprintf(1, '- Importing data from: %s ... ',annot_file);
    
    fid = fopen(annot_file);    
    HEADER = fgetl(fid);
    HEADER = regexp(HEADER, del, 'split');
    l = length(HEADER);
    
    format = repmat('%s ', 1, l);        
    A = textscan(fid, format, 'delimiter', del);
        
    fclose(fid);
    
    % one cell array   
    A = [A{:}];
        
    % column index for site identifier (mainly cgIDs and a few others)
    % check first row in annotation matrix
    CG_ID_IDX = find(not(cellfun(@isempty, regexpi(A(1,:), c_cgID))));

    if isempty(CG_ID_IDX)
        error('Could not find TargetID column (i.e. unique identifier of array sites) in annotation file.')
    end

    % if multiple hits for different columns - use first column
    if length(CG_ID_IDX) > 1
        CG_ID_IDX = CG_ID_IDX(1);
    end
    
    A = sortrows(A, CG_ID_IDX);
    
    fprintf(1, 'done\n');
    toc;
    
    % reset persistent variable with latest input annot file
    INPUT_ANNOT_FILE = annot_file;
    
else
    fprintf(1, '- Use dataset again from: %s\n',annot_file);
end

% persistent variable cannot be output argument, so copying necessary,
% which is not ideal
A2 = A;
header2 = HEADER;
cgID_idx2 = CG_ID_IDX;


%% column index for Infinium design type (I or II)

if platform == 2        
    design_type_idx = find(not(cellfun(@isempty, regexpi(header2, c_type))));
else
    design_type_idx = 0;
end


end